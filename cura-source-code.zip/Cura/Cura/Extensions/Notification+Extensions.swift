//
//  Notification+Extensions.swift
//  Cura
//
//  Created by Vivek Padaya on 15/02/25.
//

import UIKit

class Notification_Extensions: NSObject {

}

extension NSNotification.Name {
    static let newDataAdded = Notification.Name.init("NewDataAdded")
    static let pushReceived = Notification.Name.init("pushReceived")

}



