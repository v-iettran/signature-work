import SwiftUI
import CoreML
import Foundation

class PredictionTester {
    private let model: CancerRiskPredictor
    private var means: [Double]?
    private var stds: [Double]?
    
    init() throws {
        let config = MLModelConfiguration()
        self.model = try CancerRiskPredictor(configuration: config)
        
        // Load scaler parameters
        if let scalerURL = Bundle.main.url(forResource: "scaler_params", withExtension: "json"),
           let scalerData = try? Data(contentsOf: scalerURL),
           let params = try? JSONDecoder().decode([String: [Double]].self, from: scalerData) {
            self.means = params["means"]
            self.stds = params["stds"]
            print("Loaded scaler parameters:")
            print("Means:", self.means ?? [])
            print("STDs:", self.stds ?? [])
        } else {
            print("Failed to load scaler parameters")
        }
    }
    
    private func standardize(_ value: Double, featureIndex: Int) -> Double {
        guard let means = means,
              let stds = stds,
              featureIndex < means.count,
              featureIndex < stds.count else {
            return value
        }
        
        return (value - means[featureIndex]) / stds[featureIndex]
    }
    
    func testPrediction(
        avgScore: Double,
        redMeatWeekly: Double,
        bmi: Double,
        age: Double,
        haveCancerBefore: Double, // Categorical: 0 or 1
        neighborHours: Double,
        gender: Double  // Categorical: 0 or 1
    ) {
        do {
            // Scale continuous features only
            let scaledInput = CancerRiskPredictorInput(
                avg_score: standardize(avgScore, featureIndex: 0),
                red_meat_weekly: standardize(redMeatWeekly, featureIndex: 1),
                bmi: standardize(bmi, featureIndex: 2),
                age: standardize(age, featureIndex: 3),
                have_cancer_before: haveCancerBefore,  // No scaling for categorical
                neighbor_hr: standardize(neighborHours, featureIndex: 4),
                gender: gender  // No scaling for categorical
            )
            
            // Get prediction
            let prediction = try model.prediction(input: scaledInput)
            
            // Print original input values
            print("\n=== Cancer Risk Prediction Test ===")
            print("Original Input values:")
            print("- Average Score: \(avgScore)")
            print("- Red Meat Weekly: \(redMeatWeekly)")
            print("- BMI: \(bmi)")
            print("- Age: \(age)")
            print("- Have Cancer Before: \(haveCancerBefore)")
            print("- Neighbor Hours: \(neighborHours)")
            print("- Gender: \(gender)")
            
            // Print scaled values
            print("\nScaled Input values:")
            print("- Average Score: \(scaledInput.avg_score)")
            print("- Red Meat Weekly: \(scaledInput.red_meat_weekly)")
            print("- BMI: \(scaledInput.bmi)")
            print("- Age: \(scaledInput.age)")
            print("- Neighbor Hours: \(scaledInput.neighbor_hr)")
            print("- Have Cancer Before: \(scaledInput.have_cancer_before) (categorical)")
            print("- Gender: \(scaledInput.gender) (categorical)")
            
            print("\nPrediction:")
            print("- Current Cancer: \(prediction.current_cancer)")
            
            // Get probability scores
            let probs = prediction.classProbability
            print("- Probability Scores:")
            for (label, probability) in probs {
                print("  Class \(label): \(probability * 100)%")
            }
            
            // Calculate risk score
            if let riskProbability = probs[1] {
                let riskScore = riskProbability * 100
                print("\nRisk Assessment:")
                print("- Risk Score: \(riskScore)%")
                print("- Risk Level: \(getRiskLevel(score: riskScore))")
            }
            
        } catch {
            print("Prediction error: \(error.localizedDescription)")
        }
    }
    
    private func getRiskLevel(score: Double) -> String {
        switch score {
        case 70...:
            return "High Risk"
        case 40...:
            return "Medium Risk"
        default:
            return "Low Risk"
        }
    }
}

// Wrap test code in a SwiftUI view
struct PredictionTestView: View {
    var body: some View {
        Text("Prediction Test View")
            .onAppear {
                runTests()
            }
    }
    
    private func runTests() {
        do {
            let tester = try PredictionTester()
            
            // Test case 1: Low risk
            tester.testPrediction(
                avgScore: 5,
                redMeatWeekly: 10,
                bmi: 30,
                age: 60,
                haveCancerBefore: 1.0,
                neighborHours: 5.0,
                gender: 1.0
            )
            
            // Test case 2: High risk
            tester.testPrediction(
                avgScore: 2.5,
                redMeatWeekly: 3.0,
                bmi: 22.04,
                age: 22.0,
                haveCancerBefore: 0.0,
                neighborHours: 2.0,
                gender: 0.0
            )
        } catch {
            print("Failed to initialize model: \(error)")
        }
    }
}

// Preview provider
struct PredictionTestView_Previews: PreviewProvider {
    static var previews: some View {
        PredictionTestView()
    }
}
