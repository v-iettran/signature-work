import Foundation
import FirebaseFirestore
import FirebaseAuth
import Combine

class FirestoreManager: ObservableObject {
    private let db = Firestore.firestore()
    @Published var currentUser: UserData?
    @Published var connectionError: String?
    
    // Save or update user data
    func saveUserData(_ userData: UserData) async throws {
        // Convert dates to Timestamps for Firestore
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        
        var dict: [String: Any] = [
            "id": userData.id,
            "name": userData.name,
            "email": userData.email.lowercased(),
            "dateOfBirth": Timestamp(date: userData.dateOfBirth),
            "height": userData.height,
            "weight": userData.weight,
            "sex": userData.sex,
            "connections": userData.connections,
            "riskScores": [],
            "symptoms": []
        ]
        
        // Add optional fields if they exist
        if let lastQuestionnaireDate = userData.lastQuestionnaireDate {
            dict["lastQuestionnaireDate"] = Timestamp(date: lastQuestionnaireDate)
        }
        
        if let lastSymptomCheck = userData.lastSymptomCheck {
            dict["lastSymptomCheck"] = Timestamp(date: lastSymptomCheck)
        }
        
        if let preferredTime = userData.preferredAssessmentTime {
            dict["preferredAssessmentTime"] = Timestamp(date: preferredTime)
        }
        
        try await db.collection("users").document(userData.id).setData(dict, merge: true)
        
        // Schedule notification with the new preferred time
        if let preferredTime = userData.preferredAssessmentTime {
            NotificationManager.shared.scheduleDailyQuestionnaire(at: preferredTime)
        }
        
        // Update the current user
        DispatchQueue.main.async {
            self.currentUser = userData
        }
    }
    
    // Save new risk assessment
    func saveRiskAssessment(score: Int, factors: [String: Int]) async throws {
        guard let userId = Auth.auth().currentUser?.uid else { return }
        
        let riskScore = RiskScore(
            date: Date(),
            score: score,
            factors: factors
        )
        
        var userData = currentUser ?? UserData.from(Auth.auth().currentUser!)
        userData.riskScores.append(riskScore)
        
        try await saveUserData(userData)
    }
    
    // Save new symptom
    func saveSymptom(_ symptom: Symptom) async throws {
        guard let userId = Auth.auth().currentUser?.uid else { return }
        
        var userData = currentUser ?? UserData.from(Auth.auth().currentUser!)
        userData.symptoms.append(symptom)
        userData.lastSymptomCheck = Date()
        
        try await saveUserData(userData)
    }
    
    // Add connection
    func addConnection(withUserId connectionId: String) async throws {
        guard let userId = Auth.auth().currentUser?.uid else { return }
        
        var userData = currentUser ?? UserData.from(Auth.auth().currentUser!)
        userData.connections.append(connectionId)
        
        try await saveUserData(userData)
    }
    
    // Listen to user data changes
    func listenToUserData() {
        guard let userId = Auth.auth().currentUser?.uid else { return }
        
        db.collection("users").document(userId)
            .addSnapshotListener { [weak self] snapshot, error in
                guard let data = snapshot?.data(),
                      let jsonData = try? JSONSerialization.data(withJSONObject: data),
                      let userData = try? JSONDecoder().decode(UserData.self, from: jsonData)
                else { return }
                
                DispatchQueue.main.async {
                    self?.currentUser = userData
                }
            }
    }
    
    // Check if user exists and add connection
    func connectWithUser(email: String) async throws {
        // First check if the user exists - case insensitive search
        let querySnapshot = try await db.collection("users")
            .whereField("email", isEqualTo: email.lowercased())  // Convert to lowercase
            .getDocuments()
        
        guard let targetUser = querySnapshot.documents.first else {
            throw NSError(domain: "FirestoreManager",
                         code: 404,
                         userInfo: [NSLocalizedDescriptionKey: "User with this email does not exist"])
        }
        
        guard let targetUserId = targetUser.data()["id"] as? String else {
            throw NSError(domain: "FirestoreManager",
                         code: 400,
                         userInfo: [NSLocalizedDescriptionKey: "Invalid user data"])
        }
        
        // Don't allow self-connection
        guard targetUserId != Auth.auth().currentUser?.uid else {
            throw NSError(domain: "FirestoreManager",
                         code: 400,
                         userInfo: [NSLocalizedDescriptionKey: "Cannot connect with yourself"])
        }
        
        // Check if already connected
        if let currentUser = currentUser,
           currentUser.connections.contains(targetUserId) {
            throw NSError(domain: "FirestoreManager",
                         code: 400,
                         userInfo: [NSLocalizedDescriptionKey: "Already connected with this user"])
        }
        
        // Add connection for current user
        try await addConnection(withUserId: targetUserId)
        
        // Add reverse connection for target user
        if let currentUserId = Auth.auth().currentUser?.uid {
            let targetUserRef = db.collection("users").document(targetUserId)
            try await targetUserRef.updateData([
                "connections": FieldValue.arrayUnion([currentUserId])
            ])
        }
    }
    
    // Get user's connections
    func fetchConnections() async throws -> [UserData] {
        guard let currentUser = currentUser else { return [] }
        
        var connections: [UserData] = []
        for connectionId in currentUser.connections {
            let documentSnapshot = try await db.collection("users")
                .document(connectionId)
                .getDocument()
            
            if let data = documentSnapshot.data(),
               let jsonData = try? JSONSerialization.data(withJSONObject: data),
               let userData = try? JSONDecoder().decode(UserData.self, from: jsonData) {
                connections.append(userData)
            }
        }
        
        return connections
    }
} 