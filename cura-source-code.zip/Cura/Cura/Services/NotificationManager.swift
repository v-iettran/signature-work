import Foundation
import UIKit
import UserNotifications

class NotificationManager {
    static let shared = NotificationManager()
    private let center = UNUserNotificationCenter.current()

    func requestAuthorization() {
        print("Requesting notification authorization...")
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            if granted {
                print("✅ Notification authorization granted")
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications()
                }
            } else {
                print("❌ Notification authorization denied")
                if let error = error {
                    print("Error: \(error.localizedDescription)")
                }
            }
        }
        
        // Check current authorization status
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            print("📱 Notification settings: \(settings.authorizationStatus.rawValue)")
        }
    }
    
    func scheduleDailyQuestionnaire(at date: Date) {
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
        
        let content = UNMutableNotificationContent()
        content.title = "Daily Health Check"
        content.body = "Take a moment to assess your health today. Early detection makes a difference."
        content.sound = .default
        content.userInfo = ["destination": "questionnaire"]
        
        let calendar = Calendar.current
        let components = calendar.dateComponents([.hour, .minute], from: date)
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: true)
        
        let request = UNNotificationRequest(
            identifier: "daily-questionnaire",
            content: content,
            trigger: trigger
        )
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("❌ Error scheduling daily notification: \(error)")
            } else {
                print("✅ Daily notification scheduled successfully")
                
            }
        }
    }
    
    // Remove today's notification if the assessment is completed
    func removeTodayNotification() {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let todayString = dateFormatter.string(from: Date()) // Example: "2025-02-22"
        
        let identifier = "dailyAssessment-\(todayString)"
        center.removePendingNotificationRequests(withIdentifiers: [identifier])
        
        print("✅ Today's notification (\(identifier)) removed.")
    }

    
    func scheduleNotifications(for time: Date) {
        center.removeAllPendingNotificationRequests() // Clear previous notifications

        let content = UNMutableNotificationContent()
        content.title = "Daily Health Assessment Reminder"
        content.body = "It's time to complete your daily health assessment!"
        content.sound = .default
        content.userInfo = ["pushType": "assessment"]

        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: time)
        let minute = calendar.component(.minute, from: time)

        let currentDate = Date()
        for dayOffset in 0..<60 { // Schedule for 60 days
            guard let notificationDate = calendar.date(byAdding: .day, value: dayOffset, to: currentDate) else { continue }
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd" // Format: 2025-02-22
            let dateString = dateFormatter.string(from: notificationDate)

            var dateComponents = DateComponents()
            dateComponents.year = calendar.component(.year, from: notificationDate)
            dateComponents.month = calendar.component(.month, from: notificationDate)
            dateComponents.day = calendar.component(.day, from: notificationDate)
            dateComponents.hour = hour
            dateComponents.minute = minute

            let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
            let identifier = "dailyAssessment-\(dateString)" // Unique identifier with date

            let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)

            center.add(request) { error in
                if let error = error {
                    print("❌ Error scheduling notification: \(error.localizedDescription)")
                }
            }
            
        }

        print("✅ Notifications scheduled for the next 60 days.")
        
        NotificationCenter.default.post(name: .newDataAdded,
                                        object: nil, userInfo: [:])
    }

    
    // For testing purposes
    func scheduleTestNotification() {
        print("Scheduling test notification...")
        let content = UNMutableNotificationContent()
        content.title = "Daily Health Check"
        content.body = "Take a moment to assess your health today. Early detection makes a difference."
        content.sound = .default
        content.userInfo = ["destination": "questionnaire"]
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        
        let request = UNNotificationRequest(
            identifier: "testNotification",
            content: content,
            trigger: trigger
        )
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("❌ Error scheduling test notification: \(error)")
            } else {
                print("✅ Test notification scheduled successfully")
            }
        }
    }
    
    func checkPendingNotifications() {
        print("Checking pending notifications...")
        UNUserNotificationCenter.current().getPendingNotificationRequests { requests in
            print("📬 Pending Notifications: \(requests.count)")
            for request in requests {
                print("- Notification ID: \(request.identifier)")
                if let trigger = request.trigger as? UNCalendarNotificationTrigger {
                    print("  Next trigger date: \(trigger.nextTriggerDate() ?? Date())")
                } else if let trigger = request.trigger as? UNTimeIntervalNotificationTrigger {
                    print("  Time interval: \(trigger.timeInterval) seconds")
                }
            }
        }
    }
} 


import Foundation
import SwiftJWT

enum NotificationType: String {
    case screening = "screening"
    case connectionRequest = "connection_request"
    case riskStatus = "risk_status"
    case assessment = "assessment"
    case empty = "None"

}

func fetchOAuthToken(completion: @escaping (String?) -> Void) {
    guard let jwt = generateJWT() else {
        print("❌ Failed to generate JWT")
        completion(nil)
        return
    }

    let url = URL(string: "https://oauth2.googleapis.com/token")!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

    let body = "grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=\(jwt)"
    request.httpBody = body.data(using: .utf8)

    let task = URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            print("❌ Network error: \(error.localizedDescription)")
            completion(nil)
            return
        }

        if let httpResponse = response as? HTTPURLResponse {
            print("📡 HTTP Status: \(httpResponse.statusCode)")
        }

        if let data = data, let responseString = String(data: data, encoding: .utf8) {
            print("📩 Response Data: \(responseString)")
        }

        guard let data = data,
              let responseJSON = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let accessToken = responseJSON["access_token"] as? String else {
            print("❌ Failed to parse token from response")
            completion(nil)
            return
        }

        print("✅ OAuth Token: \(accessToken)")
        completion(accessToken)
    }

    task.resume()
}


struct GoogleJWTClaims: Claims {
    let iss: String  // Client Email
    let scope: String
    let aud: String
    let exp: Int
    let iat: Int
}



func generateJWT() -> String? {
    guard let serviceAccountPath = Bundle.main.path(forResource: "service-account", ofType: "json"),
          let credentialsData = try? Data(contentsOf: URL(fileURLWithPath: serviceAccountPath)),
          let credentials = try? JSONSerialization.jsonObject(with: credentialsData) as? [String: Any],
          let clientEmail = credentials["client_email"] as? String,
          let privateKey = credentials["private_key"] as? String else {
        print("❌ Failed to load service account JSON")
        return nil
    }

    let cleanedPrivateKey = privateKey.replacingOccurrences(of: "\\n", with: "\n")

    let currentTime = Int(Date().timeIntervalSince1970)
    let claims = GoogleJWTClaims(
        iss: clientEmail,
        scope: "https://www.googleapis.com/auth/firebase.messaging",
        aud: "https://oauth2.googleapis.com/token",
        exp: currentTime + 3600,
        iat: currentTime
    )

    var jwt = JWT(claims: claims)
    let privateKeyData = Data(cleanedPrivateKey.utf8)

    do {
        let jwtSigner = JWTSigner.rs256(privateKey: privateKeyData)
        let signedJWT = try jwt.sign(using: jwtSigner)
        print("✅ Generated JWT: \(signedJWT)")
        return signedJWT
    } catch {
        print("❌ JWT Generation Error: \(error.localizedDescription)")
        return nil
    }
}


func sendPushNotification(to deviceToken: String, title: String, body: String, type: NotificationType) {
    fetchOAuthToken { accessToken in
        guard let accessToken = accessToken else {
            print("❌ Failed to get OAuth token")
            return
        }

        let url = URL(string: "https://fcm.googleapis.com/v1/projects/cura-15cbd/messages:send")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Any] = [
            "message": [
                "token": deviceToken,
                "notification": [
                    "title": title,
                    "body": body
                ],
                "data": [
                    "pushType": type.rawValue  // Add the pushType key here
                ]
            ]
        ]

        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: payload, options: [])
        } catch {
            print("❌ JSON Encoding Error: \(error.localizedDescription)")
            return
        }

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ Network error: \(error.localizedDescription)")
                return
            }

            if let httpResponse = response as? HTTPURLResponse {
                print("📡 HTTP Status: \(httpResponse.statusCode)")
            }

            if let data = data, let responseString = String(data: data, encoding: .utf8) {
                print("📩 Response Data: \(responseString)")
            }
        }

        task.resume()
    }
}
