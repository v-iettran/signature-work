//
//  AppManager.swift
//  Cura
//
//  Created by Vivek Padaya on 11/02/25.
//

import UIKit
import SwiftUI


fileprivate let kOnBoarding = "isOnBoardingCompleted"
fileprivate let kCurrentUser = "CurrentUser"
fileprivate let kFirstAssessmentDate = "FirstAssessmentDate"

class AppManager : ObservableObject{
    
    static let shared = AppManager()
    
    private init() {
        loadUserFromDefaults()
    }
    
    /// Load user profile from UserDefaults
    private func loadUserFromDefaults() {
        guard let userData = UserDefaults.standard.data(forKey: kCurrentUser) else {
            return
        }
        currentUser = try? JSONDecoder().decode(UserProfile.self, from: userData)
    }
    
    var isOnboardingCompleted : Bool {
        set{
            UserDefaults.standard.set(newValue, forKey: kOnBoarding)
        }
        get{
            return UserDefaults.standard.bool(forKey: kOnBoarding)
        }
    }
    
    var firstAssessmentDate: Date? {
        set {
            let timeInterval = newValue?.timeIntervalSince1970
            UserDefaults.standard.set(timeInterval, forKey: kFirstAssessmentDate)
        }
        get {
            let timeInterval = UserDefaults.standard.double(forKey: kFirstAssessmentDate)
            return timeInterval > 0 ? Date(timeIntervalSince1970: timeInterval) : nil
        }
    }

    @Published var currentUser : UserProfile?{
        didSet {
            if let encodedUser = try? JSONEncoder().encode(currentUser) {
                UserDefaults.standard.set(encodedUser, forKey: kCurrentUser)
            } else {
                UserDefaults.standard.removeObject(forKey: kCurrentUser)
            }
            objectWillChange.send() // Manually notify UI of changes
        }
       
    }

}
