import SwiftUI
import FirebaseFirestore
import UserNotifications

func requestNotificationPermission() {
    let center = UNUserNotificationCenter.current()
    center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
        if granted {
            print("✅ Notification permission granted")
        } else {
            print("❌ Notification permission denied")
        }
    }
}



struct AssessmentTimeSettingView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var firestoreManager: FirestoreManager
    @State private var selectedTime = Date()
    @State private var showingAlert = false
    @State private var alertMessage = ""
    @State private var isSaving = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                Text("Khi nào bạn muốn nhận thông báo nhắc nhở về cập nhật sức khỏe hàng ngày?")
                    .font(
                    Font.custom("Crimson Pro", size: 32)
                    .weight(.bold)
                    )
                    .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                    .padding(.horizontal, 23.5)
                
                DatePicker("Select Time",
                          selection: $selectedTime,
                          displayedComponents: .hourAndMinute)
                    .datePickerStyle(.wheel)
                    .labelsHidden()
                
                Button(action: savePreferredTime) {
                    if isSaving {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                    } else {
                        Text("Lưu")
                            .font(
                            Font.custom("Source Sans Pro", size: 16)
                            .weight(.bold)
                            )
                            .foregroundColor(.white)
                    }
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 56)
                .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                .cornerRadius(12)
                .disabled(isSaving)
                .padding(.horizontal)
                
                Text("Bạn sẽ nhận được thông báo hàng ngày vào thời gian này để hoàn thành cập nhật sức khỏe của mình.")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            .padding(.vertical)
            .navigationTitle("Assessment Time")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Quay lại") { dismiss() }
                        .disabled(isSaving)
                }
            }
        }
        .alert("Cài đặt thông báo", isPresented: $showingAlert) {
            Button("OK") {
                if alertMessage.contains("Success") {
                    dismiss()
                }
            }
        } message: {
            Text(alertMessage)
        }
    }
    
//    private func savePreferredTime() {
//        guard var userData = firestoreManager.currentUser else {
//            alertMessage = "Error: User data not found"
//            showingAlert = true
//            return
//        }
//        
//        isSaving = true
//        userData.preferredAssessmentTime = selectedTime
//        
//        Task {
//            do {
//                try await firestoreManager.saveUserData(userData)
//                alertMessage = "Success! Your daily assessment time has been set."
//            } catch {
//                alertMessage = "Failed to save your preferred time: \(error.localizedDescription)"
//            }
//            
//            DispatchQueue.main.async {
//                isSaving = false
//                showingAlert = true
//            }
//        }
//    }
    
    private func savePreferredTime() {
        isSaving = true
        
        // Save time in UserDefaults
        UserDefaults.standard.set(selectedTime, forKey: "assessmentTime")
        
        // Schedule notifications for 3 months
        NotificationManager.shared.scheduleNotifications(for: selectedTime)

        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            isSaving = false
            alertMessage = "Thành công! Cài đặt thông báo đã được cập nhật."
            showingAlert = true
        }
    }
    
    

}

// Preview provider with mock data
struct AssessmentTimeSettingView_Previews: PreviewProvider {
    static var previews: some View {
        AssessmentTimeSettingView()
            .environmentObject(AuthManager())
            .environmentObject(FirestoreManager())
    }
} 
