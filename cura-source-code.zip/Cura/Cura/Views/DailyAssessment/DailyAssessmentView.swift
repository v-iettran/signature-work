//
//  DailyAssessmentView.swift
//  Cura
//
//  Created by Vivek Padaya on 14/02/25.
//

import SwiftUI

struct DailyAssessmentView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel = DailyQuestionnaireViewModel()
    @State var assessments: [Assessment]
    
    var body: some View {
        
        ZStack {
            ScrollView {
                VStack(spacing: 24) {
                    // Header
                    HStack {
                        Button(action: { dismiss() }) {
                            Image(systemName: "arrow.left")
                                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                                .imageScale(.large)
                                .frame(width: 44, height: 44) // Following minimum touch target size
                        }
                        
                        Text("Cập nhật sức khoẻ hằng ngày")
                            .font(Font.custom("Source Sans Pro", size: 20))
                            .fontWeight(.bold)
                        
                        Spacer()
                    }
                    .padding(.top, 16)
                    
                    // Progress indicator
                    ProgressView(value: viewModel.progress)
                        .tint(Color(red: 0.14, green: 0.18, blue: 0.29))
                        .frame(height: 8)
                    
                    // Questions
                    ForEach(viewModel.questions.indices, id: \.self) { index in
                        if index == viewModel.currentQuestionIndex {
                            if viewModel.questions[index].type == .stepper {
                                TimeQuestionCard(
                                    question: viewModel.questions[index],
                                    selectedHours: $viewModel.answers[index])
                                    .transition(.opacity)

                            }else{
                                QuestionCard(
                                    question: viewModel.questions[index],
                                    selection: $viewModel.answers[index]
                                )
                                .transition(.opacity)
                            }
                           
                        }
                    }
                    
                    // Navigation buttons
                    HStack(spacing: 16) {
                        if viewModel.currentQuestionIndex > 0 {
                            Button(action: viewModel.previousQuestion) {
                                Text("Quay lại")
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 56) // Comfortable touch target
                                    .background(Color(red: 0.36, green: 0.41, blue: 0.52))
                                    .cornerRadius(12)
                            }
                        }
                        
                        Button(action: viewModel.isLastQuestion ? viewModel.submitQuestionnaire : viewModel.nextQuestion) {
                            Text(viewModel.isLastQuestion ? "Hoàn tất" : "Tiếp tục")
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .frame(height: 56)
                                .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                                .cornerRadius(12)
                        }
                        .disabled(!viewModel.isAnswerProvided) // Disable when no answer is given
                        .opacity(!viewModel.isAnswerProvided ? 0.5 : 1.0) // Reduce opacity when disabled
                    }
                    .padding(.vertical, 24)
                }
                .padding(.horizontal, 24)
            }
            if viewModel.showingSubmissionAlert{
                VStack{
                    Spacer()
                    
                    KobiScoreCardView(onClickHome: {
                        dismiss()
                    })
                    .frame(height: 380)
                    .padding()
                    
                    Spacer()
                }
                .background(.ultraThinMaterial)
                
            }
        }
        .onAppear(perform: {
            viewModel.assessments = assessments
        })
        .background(Color(red: 0.95, green: 0.96, blue: 0.98))
//        .alert("Success", isPresented: $viewModel.showingSubmissionAlert) {
//            Button("OK") { dismiss() }
//        } message: {
//            Text("Thank you for completing your daily assessment.")
//        }
        
    }
}

struct QuestionCard: View {
    let question: Question
    @Binding var selection: String?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(question.text)
                .font(Font.custom("Source Sans Pro", size: 24))
                .fontWeight(.bold)
            
            VStack(spacing: 12) {
                ForEach(question.options, id: \.self) { option in
                    Button(action: { selection = option }) {
                        HStack {
                            Text(option)
                                .font(.system(size: 16))
                                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                            Spacer()
                            if selection == option {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.blue)
                            }
                        }
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.white)
                                .shadow(color: .black.opacity(0.05), radius: 4)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(selection == option ? .blue : .clear, lineWidth: 2)
                        )
                    }
                    .frame(minHeight: 44) // Minimum touch target size
                }
            }
        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(16)
    }
}

struct TimeQuestionCard: View {
    let question: Question
    @Binding var selectedHours: String?
    @State private var internalHours: Int = 1  // Internal integer storage
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Question Title
            Text(question.text)
                .font(Font.custom("Source Sans Pro", size: 24))
                .fontWeight(.bold)
            
            
            HStack(alignment: .center, content: {
                // Value Display
                Spacer()
                
                Text("\(internalHours)")
                    .font(Font.custom("Source Sans Pro", size: 22))
                    .fontWeight(.bold)
                
                Text("\(question.stepperName)\(internalHours > 1 ? "s" : "")")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                
                Spacer()
            })
            
            
            // Custom Stepper
            HStack(spacing: 16) {
                // Minus Button
                Button(action: {
                    if internalHours > 0 {
                        internalHours -= 1
                        selectedHours = "\(internalHours)"
                    }
                }) {
                    Text("-")
                        .frame(maxWidth: .infinity)
                        .font(.system(size: 40, weight: .bold, design: .default))
                }
                .frame(maxWidth: .infinity)
                .frame(minHeight: 50) // Minimum touch target size
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.white)
                        .shadow(color: .black.opacity(0.05), radius: 4)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(.clear, lineWidth: 2)
                )
                
                            
                // Plus Button
                Button(action: {
                    if internalHours < 20 {
                        internalHours += 1
                        selectedHours = "\(internalHours)"
                    }
                }) {
                    Text("+")
                        .frame(maxWidth: .infinity)
                        .font(.system(size: 40, weight: .bold, design: .default))
                }
                .frame(maxWidth: .infinity)
                .frame(minHeight: 50) // Minimum touch target size
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.white)
                        .shadow(color: .black.opacity(0.05), radius: 4)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(.clear, lineWidth: 2)
                )
                .frame(minHeight: 70) // Minimum touch target size

            }
            .frame(maxWidth: .infinity)

        }
        .padding(24)
        .background(Color.white)
        .cornerRadius(16)
        .onAppear {
            if let hours = Int(selectedHours ?? "0") {
                internalHours = hours
            }
        }
    }
}

