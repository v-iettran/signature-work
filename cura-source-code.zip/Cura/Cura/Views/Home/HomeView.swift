//
//  HomeView.swift
//  Cura
//
//  Created by Vivek Padaya on 19/02/25.
//

import SwiftUI
import Charts



// Main HomeView
struct HomeView: View {
    @EnvironmentObject var firestoreManager: FirestoreManager
    @State private var showingTimeSettings = false
    @State private var isFlipped = false
    
    let cancerRiskData: [DailyRisk] = [
        DailyRisk(date: Date().addingTimeInterval(-6 * 86400), score: 10),
        DailyRisk(date: Date().addingTimeInterval(-5 * 86400), score: 20),
        DailyRisk(date: Date().addingTimeInterval(-4 * 86400), score: 15),
        DailyRisk(date: Date().addingTimeInterval(-3 * 86400), score: 13),
        DailyRisk(date: Date().addingTimeInterval(-2 * 86400), score: 23),
        DailyRisk(date: Date().addingTimeInterval(-1 * 86400), score: 30),
        DailyRisk(date: Date(), score: 5)
    ]
    
    @State var cancerRiskDataNew: [DailyRisk] = []
    
    @State private var showAssessmentQue = false
    
    
    @State private var assessments : [Assessment] = []
    
    @State private var showSetup: Bool = false
    @StateObject private var appManager = AppManager.shared

    @State private var showAssessmentBanner = false
    @State private var showDailyAssessment = false
    @State private var pendingConnections: [Connections] = []
    @State private var showConnectionRequestPopUp = false
    @State private var allConnections: [Connections] = []
    @State private var lowRiskConnections: [Connections] = []
    @State private var pushType: String?
    
    @State private var screeningRequest: [Connections] = []
    @State private var showScreeningRequestView = false

    var body: some View {
        
        ZStack {
           
            
            ScrollView {
                VStack(spacing: 20) {
                    
                    if showSetup {
                        HStack{
                            Text("Profile Setup")
                                .font(Font.custom("Source Sans Pro", size: 20))
                                .fontWeight(.bold)
                            Spacer()
                        }
                        
                        FinishSetup(showFinishSetup: $showAssessmentQue)
                    }else{
                        
                        if !screeningRequest.isEmpty{
                            if screeningRequest.count == 1{
                                VStack {
                                    HStack{
                                        Image("kobi-happy-icon")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 30, height: 20)
                                            .foregroundStyle(.white)
                                            .padding(10)
                                        
                                        Text("\(screeningRequest[0].name)'s Has requested you for screening.")
                                            .font(Font.custom("Source Sans Pro", size: 18))
                                            .fontWeight(.bold)
                                            .foregroundStyle(.white)
                                        Spacer()
                                        
                                    }
                                   
                                }
                                .padding(6)
                                .background(Color.accentColor)
                                .cornerRadius(12)
                                .onTapGesture {
                                    showScreeningRequestView = true
                                }
                                
                            }else{
                                VStack {
                                    HStack{
                                        Image("kobi-happy-icon")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 30, height: 20)
                                            .foregroundStyle(.white)
                                            .padding(10)
                                        
                                        Text("You \(screeningRequest.count) connections have requested you for screening.")
                                            .font(Font.custom("Source Sans Pro", size: 18))
                                            .fontWeight(.bold)
                                            .foregroundStyle(.white)
                                        Spacer()
                                        
                                    }
                                   
                                }
                                .padding(6)
                                .background(Color.accentColor)
                                .cornerRadius(12)
                                .onTapGesture {
                                    showScreeningRequestView = true
                                }
                            }
                           
                        }
                        
                        
                        if !lowRiskConnections.isEmpty{
                            if lowRiskConnections.count == 1{
                                VStack {
                                    HStack{
                                        Image("kobi-happy-icon")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 30, height: 20)
                                            .foregroundStyle(.white)
                                            .padding(10)
                                        
                                        Text("\(lowRiskConnections[0].name)'s Kobi Score is low.")
                                            .font(Font.custom("Source Sans Pro", size: 18))
                                            .fontWeight(.bold)
                                            .foregroundStyle(.white)
                                        Spacer()
                                        
                                    }
                                   
                                }
                                .padding(6)
                                .background(Color.accentColor)
                                .cornerRadius(12)
                                
                                
                            }else{
                                VStack {
                                    HStack{
                                        Image("kobi-happy-icon")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 30, height: 20)
                                            .foregroundStyle(.white)
                                            .padding(10)
                                        
                                        Text("You \(lowRiskConnections.count) connections have low Kobi score.")
                                            .font(Font.custom("Source Sans Pro", size: 18))
                                            .fontWeight(.bold)
                                            .foregroundStyle(.white)
                                        Spacer()
                                        
                                    }
                                   
                                }
                                .padding(6)
                                .background(Color.accentColor)
                                .cornerRadius(12)
                            }
                           
                        }
                        if !pendingConnections.isEmpty{
                            VStack {
                                HStack{
                                    Image("connection-icon-noti")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 30, height: 30)
                                        .foregroundStyle(.white)
                                        .padding(10)
                                    
                                    Text("Bạn có \(pendingConnections.count) lời mời kết nối.")
                                        .font(Font.custom("Source Sans Pro", size: 18))
                                        .fontWeight(.bold)
                                        .foregroundStyle(.white)
                                    Spacer()
                                    Image(systemName: "arrow.forward")
                                }
                               
                            }
                            .padding(6)
                            .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                            .cornerRadius(12)
                            .onTapGesture {
                                showConnectionRequestPopUp = true
                            }
                        }
                        
                        if showAssessmentBanner{
                            VStack {
                                HStack{
                                    Image(systemName: "doc.text") // "doc.text" provides a better document-like icon
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 30, height: 30)
                                        .foregroundStyle(.white)
                                        .padding(10)
                                    
                                    Text("Cập nhật sức khoẻ ngay")
                                        .font(Font.custom("Source Sans Pro", size: 16))
                                        .fontWeight(.bold)
                                        .foregroundStyle(.white)
                                    Spacer()
                                    Image(systemName: "arrow.forward")
                                        .foregroundStyle(.white)
                                        .padding(10)
                                }
                               
                            }
                            .padding(6)
                            .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                            .cornerRadius(12)
                            .onTapGesture {
                                showDailyAssessment = true
                            }
                        }
                                            
                        VStack(alignment: .leading, spacing: 16) {
                            ZStack {
                                // Front of card
                                VStack(alignment: .leading, spacing: 16) {
                                    ChartHeaderView(
                                        score: Int(cancerRiskDataNew.last?.score ?? 0),
                                        onQuestionMarkTapped: { withAnimation(.easeInOut(duration: 0.3)) { isFlipped.toggle() } }
                                    )
                                    RiskScoreChart(data: cancerRiskDataNew)
                                }
                                .opacity(isFlipped ? 0 : 1)
                                
                                // Back of card
                                ChartInfoView(onQuestionMarkTapped: { withAnimation(.easeInOut(duration: 0.3)) { isFlipped.toggle() } })
                                    .opacity(isFlipped ? 1 : 0)
                            }
                        }
                        .padding(24)
                        .background(backgroundColor)
                        .cornerRadius(25)
                        
//                        Button(action: { showingTimeSettings = true }) {
//                            HStack {
//                                Image(systemName: "clock")
//                                Text("Set Assessment Time")
//                            }
//                            .foregroundColor(.white)
//                            .frame(maxWidth: .infinity)
//                            .frame(height: 44)
//                            .background(Color(red: 0.14, green: 0.18, blue: 0.29))
//                            .cornerRadius(12)
//                        }
//                        .padding(.horizontal)
                    }
                  
                }
                .padding()
            }
            
            if showConnectionRequestPopUp{
                            
                
                ConnectionRequestPopup(isPresented: $showConnectionRequestPopUp, requests: pendingConnections) { acceptedConnection in
                    print("Accepted: \(acceptedConnection.name)")
                    guard let userdata = appManager.currentUser else { return }

                    FirestoreManagerAdvance.shared.updateConnectionStatus(for: userdata.userId, connectionId: acceptedConnection.userId, accepted: true) { isAccepted in
                        self.loadData()
                    }
                } onReject: { rejectedConnection in
                    print("Rejected: \(rejectedConnection.name)")
                    guard let userdata = appManager.currentUser else { return }

                    FirestoreManagerAdvance.shared.updateConnectionStatus(for: userdata.userId, connectionId: rejectedConnection.userId, accepted: false) { isAccepted in
                        self.loadData()
                    }
                }
            }
        }
        .sheet(isPresented: $showingTimeSettings) {
            AssessmentTimeSettingView()
                .environmentObject(firestoreManager)
        }
        .fullScreenCover(isPresented: $showAssessmentQue, content: {
            FirstAssessmentView()
        })
        .fullScreenCover(isPresented: $showDailyAssessment, content: {
        
            DailyAssessmentView(assessments: assessments)
        })
        .fullScreenCover(isPresented: $showScreeningRequestView, content: {
            ScreeningHomeView(screeningConnections: screeningRequest)
        })
        .onAppear {
            self.loadData()
        }.onReceive(NotificationCenter.default.publisher(for: .newDataAdded)) { (output) in
            self.loadData()
        }
        .onReceive(NotificationCenter.default.publisher(for: .pushReceived)) { notification in
            if let userInfo = notification.userInfo, let type = userInfo["pushType"] as? String {
                self.pushType = type
                
                let notificationType = NotificationType(rawValue: type)
                
                switch notificationType {
                case .screening:
                    showScreeningRequestView = true
                case .connectionRequest:
                    showConnectionRequestPopUp = true
                case .riskStatus:
                    print("risk status")
                case .empty:
                    print("Nothing to show")
                case .none:
                    print("Nothing to show")
                case .assessment:
                    showDailyAssessment = true
                }
            }
        }
    }

    func loadData(){
        guard let userdata = appManager.currentUser else { return }
        
        if userdata.questionnaireAnswers == nil{
            showSetup = true
        }else{
            showSetup = false
        }
        fetchConnectionRequest(userId: userdata.userId)

        FirestoreManagerAdvance.shared.fetchCurrentWeekAssessments(for: userdata.userId) { assessmentData in
            assessments = assessmentData
            self.cancerRiskDataNew = []

            self.loadConnections()
            if assessmentData.isEmpty {
//                    showAssessmentBanner = true
                
                let kobiScore = userdata.kobiScore
                
                let riskData = DailyRisk(date: Date(), score: Double(kobiScore ?? 0))
                self.cancerRiskDataNew.append(riskData)
                showAssessmentBanner = true
                
                if let firstAssessmentDate = appManager.firstAssessmentDate {
                    if Calendar.current.isDateInToday(firstAssessmentDate){
                        showAssessmentBanner = false
                    }
                }

            }else{
                self.cancerRiskDataNew = assessments.compactMap { assessment in
                    guard let date = assessment.date.getDateFromString() else { return nil }
                    return DailyRisk(date: date, score: Double(assessment.kobiScore ?? 0))
                }
                
//                let filter = assessments.filter({$0.date.contains(Date().toString())})
                
                let today = Calendar.current.startOfDay(for: Date())

                let hasTodayAssessment = assessments.contains { assessment in
                    if let timestamp = assessment.dateTimestamp {
                        let assessmentDate = timestamp.dateValue()
                        return Calendar.current.isDate(assessmentDate, inSameDayAs: today)
                    }
                    return false
                }
                
                if hasTodayAssessment {
                    showAssessmentBanner = false
                    NotificationManager.shared.removeTodayNotification()
                }else{
                    showAssessmentBanner = true
                }
            }
        }
    }
    
    func fetchConnectionRequest(userId: String){
        
        FirestoreManagerAdvance.shared.fetchPendingRequests(for: userId) { connections in
            pendingConnections = connections
        }
    }
    
    private func loadConnections() {
        guard let userData = AppManager.shared.currentUser else {
            return
        }
        FirestoreManagerAdvance.shared.fetchConnections(for: userData.userId) { allconnection in
            self.allConnections = allconnection.filter({$0.accepted ?? false})
            self.screeningRequest = allconnection.filter({$0.showScreeingRequested ?? false})
            self.loadRiskStatus()
        }
    }
    
    private func loadRiskStatus() {
        for connection in allConnections {
            FirestoreManagerAdvance.shared.fetchUserProfile(userId: connection.userId) { profile in
                DispatchQueue.main.async {
                    if profile?.riskStatus == "Low" {
                        self.lowRiskConnections.append(connection)
                    }
                }
            }
        }
    }

    var backgroundColor: Color {
        let currentScore = cancerRiskDataNew.last?.score ?? 0
        switch currentScore {
        case ..<25:
            return Color(red: 0.25, green: 0.45, blue: 0.25)
        case 25...75:
            return Color(red: 0.9, green: 0.7, blue: 0.37)
        default:
            return Color(red: 0.47, green: 0, blue: 0)
        }
    }
        
}

