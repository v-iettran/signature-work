//
//  ConnectionRequestPopup.swift
//  Cura
//
//  Created by Vivek Padaya on 19/02/25.
//


import SwiftUI

struct ConnectionRequestPopup: View {
    @Binding var isPresented: Bool
    var requests: [Connections]
    var onAccept: (Connections) -> Void
    var onReject: (Connections) -> Void
    
    @State private var selectedIndex: Int = 0

    var body: some View {
        ZStack {
        
            // Centered Popup
            VStack {
                Spacer()
            

                if requests.isEmpty {
                    Text("No Pending Requests")
                        .font(.subheadline)
                        .padding()
                } else {
                    TabView(selection: $selectedIndex) {
                        ForEach(requests.indices, id: \.self) { index in
                            RequestCardView(
                                request: requests[index],
                                onAccept: {
                                    onAccept(requests[index])
                                    moveToNextRequest()
                                },
                                onReject: {
                                    onReject(requests[index])
                                    moveToNextRequest()
                                }
                            )
                            .padding()
                        }
                    }
                    .tabViewStyle(PageTabViewStyle())
                    .frame(height: 380)
                }

            
                Spacer()

            }
            .background(.ultraThinMaterial)
            .onTapGesture {
                isPresented = false
            }
//            .cornerRadius(20)
//            .shadow(radius: 10)
//            .frame(maxWidth: 350)
        }
    }
    
    private func moveToNextRequest() {
        if selectedIndex < requests.count - 1 {
            selectedIndex += 1
        } else {
            isPresented = false
        }
    }
}


struct RequestCardView: View {
    let request: Connections
    var onAccept: () -> Void
    var onReject: () -> Void
    
    var body: some View {
        VStack {
            
            Text("\(request.name) muốn kết nối với bạn.")
                .font(
                    Font.custom("Crimson Pro", size: 32)
                        .weight(.bold)
                )
                .multilineTextAlignment(.leading)

            Spacer()
                .frame(height: 20)
            
            Text("Lưu ý, người này có thể xem Điểm rủi ro của bạn và những thông tin về sức khoẻ khác.")
                .font(Font.custom("Source Sans Pro", size: 16))
                .multilineTextAlignment(.leading)
                .foregroundColor(Color(red: 0.36, green: 0.41, blue: 0.52))
                .frame(maxWidth: .infinity, alignment: .leading) // Allow full width


            HStack {
                Button(action: onReject) {
                  
                    
                    Text("Từ chối")
                        .font(Font.custom("Source Sans Pro", size: 16).weight(.bold))
                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(Color.white)
                        .cornerRadius(12)
                        .shadow(radius: 5)

                }

                Button(action: onAccept) {
                    
                    Text("Chấp nhận")
                        .font(Font.custom("Source Sans Pro", size: 16).weight(.bold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                        .cornerRadius(12)
                }
            }
            .padding(.top)
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(radius: 5)
    }
}
