//
//  SettingsView.swift
//  Cura
//
//  Created by Vivek Padaya on 20/02/25.
//

import SwiftUI

struct SettingsView: View {
    
    @EnvironmentObject var authManager: AuthManager

    @Binding var isDissmis: Bool
    @State private var showingTimeSettings = false
    
    // Add state variables for alerts
    @State private var showAccountAlert = false
    @State private var showPrivacyAlert = false

    
    var body: some View {
        VStack(spacing: 20) {
            
            HStack {
                Spacer()
                Button(action: {
                    isDissmis = false
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .resizable()
                        .frame(width: 24, height: 24)
                        .foregroundColor(.gray)
                }
                .padding()
            }
            // Profile Section
            profileSection
            
            // Settings List
            VStack(spacing: 10) {
                settingsRow(title: "Tài khoản", icon: "person.crop.circle", action: {
                    showAccountAlert = true
                })
                
                settingsRow(title: "Thời gian cập nhật sức khoẻ", icon: "bell", action: {
                    showingTimeSettings = true
                })
                
                settingsRow(title: "Riêng tư & Bảo mật", icon: "lock.shield", action: {
                    showPrivacyAlert = true
                })
            }
            .padding()
            .background(Color.white)
            .cornerRadius(15)
            .shadow(radius: 5)
            
            Spacer()
            
            // Logout Button
            Button(action: {
                print("Logout tapped")
                authManager.signOut { error in
                    if let error = error {
                        // Handle the error here
                        print("Error signing out: \(error.localizedDescription)")
                    } else {
                        // Handle successful sign out
                        print("Successfully signed out")
                        AppManager.shared.currentUser = nil
                    }
                }
                
            }) {
                HStack {
                    Image(systemName: "arrow.right.square")
                        .foregroundColor(.red)
                    Text("Đăng xuất")
                        .foregroundColor(.red)
                        .font(.headline)
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.white)
                .cornerRadius(10)
                .shadow(radius: 5)
            }
            .padding()
        }
        .padding()
        .background(Color(.systemGray6).ignoresSafeArea())
        .alert("Thông tin tài khoản", isPresented: $showAccountAlert) {
            Button("Đóng", role: .cancel) { }
        } message: {
            Text("Tính năng này sẽ sớm được cập nhật trong phiên bản tiếp theo.")
        }
        .alert("Riêng tư & Bảo mật", isPresented: $showPrivacyAlert) {
            Button("Đóng", role: .cancel) { }
        } message: {
            Text("Chúng tôi cam kết bảo vệ thông tin cá nhân của bạn theo quy định của pháp luật hiện hành.")
        }
        .sheet(isPresented: $showingTimeSettings) {
            AssessmentTimeSettingView()
        }
    }
    
    // MARK: - Profile Section
    private var profileSection: some View {
        HStack {
            Image("profile-icon")
                .padding(12)
                .frame(width: 49, height: 49, alignment: .center)
                .background(
                    AngularGradient(
                        stops: [
                            Gradient.Stop(color: Color(red: 0, green: 0.8, blue: 0.96), location: 0.00),
                            Gradient.Stop(color: Color(red: 1, green: 0.37, blue: 0.64), location: 0.45),
                            Gradient.Stop(color: Color(red: 0.38, green: 0.46, blue: 0.68), location: 0.67),
                            Gradient.Stop(color: Color(red: 1, green: 0.13, blue: 0), location: 0.89),
                        ],
                        center: UnitPoint(x: 0.5, y: 0.5),
                        angle: Angle(degrees: 90)
                    )
                )
                .cornerRadius(24.5)
            
            VStack{
                Text(AppManager.shared.currentUser?.name ?? "John Doe")
                    .font(.title2)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity, alignment: .leading)
                
                Text(AppManager.shared.currentUser?.email ?? "johndoe@example.com")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            Spacer()
            
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
    }
    
    // MARK: - Settings Row
    private func settingsRow(title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(.blue)
                Text(title)
                    .foregroundColor(.black)
                    .font(.headline)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10)
            .shadow(radius: 5)
        }
    }
}


#Preview {
    SettingsView(isDissmis: .constant(true))
        .environmentObject(AuthManager())
}
