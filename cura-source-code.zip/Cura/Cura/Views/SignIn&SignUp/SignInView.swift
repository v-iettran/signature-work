//
//  SignInView.swift
//  Cura
//
//  Created by Viet Tran on 20/10/24.
//

import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct SignInView: View {
    @EnvironmentObject var authManager: AuthManager
    @Environment(\.presentationMode) var presentationMode
    let email: String
    @State private var password = ""
    @State private var isSigningIn = false
    @State private var showError = false
    @State private var errorMessage = ""
    
    var body: some View {
        VStack(alignment: .leading, spacing: 24) {
            // Back button and logo
            HStack {
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.black)
                }
                
                Spacer()
                
                Image("logo")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 24)
                
                Spacer()
            }
            .padding(.horizontal)
            Spacer()
            VStack(alignment: .leading, spacing: 32) {
                Text("Chào mừng bạn đã quay lại!")
                    .font(Font.custom("Crimson Pro", size: 32))
                    .fontWeight(.bold)
                    .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                
                // Password field
                VStack(alignment: .leading, spacing: 8) {
                    Text("Mật khẩu")
                        .font(Font.custom("Source Sans Pro", size: 16)
                            .weight(.bold)
                            )
                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                    SecureField("Điền mật khẩu của bạn", text: $password)
                        .textFieldStyle(RoundedTextFieldStyle())
                }
                
                // Sign In Button
                Button(action: {
                    isSigningIn = true
                    authManager.signInWithEmail(withEmail: email, password: password) { error in
                        if let error = error {
                            errorMessage = error.localizedDescription
                            showError = true
                        }
                       
                        isSigningIn = false
                    }
                }) {
                    ZStack {
                        if isSigningIn {
                            HStack(spacing: 8) {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            }
                        } else {
                            HStack(spacing: 8) {
                                Text("Đăng nhập")
                                    .font(Font.custom("SourceSansPro-Bold", size: 16))
                                    .foregroundColor(.white)
                                Image(systemName: "arrow.right")
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundColor(.white)
                            }
                        }
                    }
                    .padding(15)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                    .cornerRadius(10)
                }
                .disabled(password.isEmpty || isSigningIn)
            }
            .padding(.horizontal, 24)
            .padding(.top, 40)
            
            Spacer()
            Spacer()
        }
        .navigationBarHidden(true)
        .alert(isPresented: $showError) {
            Alert(
                title: Text("Error"),
                message: Text(errorMessage),
                dismissButton: .default(Text("OK"))
            )
        }
        .navigationTransition()
        .animation(.easeInOut(duration: 0.3), value: true)
    }
}

struct SignInView_Previews: PreviewProvider {
    static var previews: some View {
        SignInView(email: "test@example.com")
            .environmentObject(AuthManager())
    }
}
