//
//  SignUpView.swift
//  Cura
//
//  Created by Viet Tran on 20/10/24.
//

import SwiftUI
import Firebase
import FirebaseCore
import FirebaseAuth

struct SignUpView: View {
    
    // MARK: - Properties
    
    @EnvironmentObject var authManager: AuthManager
    @Environment(\.presentationMode) var presentationMode
    let email: String
    @State private var fullName = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var phoneNumber = ""
    @State private var isSigningUp = false
    @State private var showError = false
    @State private var errorMessage = ""
    
    // MARK: - Body
    
    var body: some View {
        VStack(alignment: .leading, spacing: 24) {
            // Back button and logo
            HStack {
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.black)
                }
                
                Spacer()
                
                Image("logo")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 24)
                
                Spacer()
            }
            .padding(.horizontal)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 32) {
                    // Title
                    Text("Hãy thiết lập tài khoản của bạn.")
                        .font(
                        Font.custom("Crimson Pro", size: 32)
                        .weight(.bold)
                        )
                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                    
                    // Form fields
                    VStack(alignment: .leading, spacing: 20) {
                        // Full Name
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Họ và tên đầy đủ")
                                .font(
                                Font.custom("Source Sans Pro", size: 16)
                                .weight(.bold))
                            HStack {
                                Image(systemName: "person")
                                    .foregroundColor(.gray)
                                TextField("Điền đẩy đủ họ, tên lót, và tên", text: $fullName)
                            }
                            .padding()
                            .background(.white)
                            .cornerRadius(10)
                            .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 4)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .inset(by: 0.1)
                                    .stroke(Color(red: 0.51, green: 0.55, blue: 0.63), lineWidth: 0.2))
                        }
                        
                        // Password
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Mật khẩu")
                                .font(
                                Font.custom("Source Sans Pro", size: 16)
                                .weight(.bold))
                            HStack {
                                Image(systemName: "lock")
                                    .foregroundColor(.gray)
                                SecureField("Hãy chọn mật khẩu", text: $password)
                            }
                            .padding()
                            .background(.white)
                            .cornerRadius(10)
                            .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 4)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .inset(by: 0.1)
                                    .stroke(Color(red: 0.51, green: 0.55, blue: 0.63), lineWidth: 0.2))
                        }
                        
                        // Confirm Password
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Xác nhận mật khẩu")
                                .font(
                                Font.custom("Source Sans Pro", size: 16)
                                .weight(.bold))
                            HStack {
                                Image(systemName: "lock")
                                    .foregroundColor(.gray)
                                SecureField("Hãy xác nhận lại mật khẩu của bạn", text: $confirmPassword)
                            }
                            .padding()
                            .background(.white)
                            .cornerRadius(10)
                            .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 4)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .inset(by: 0.1)
                                    .stroke(Color(red: 0.51, green: 0.55, blue: 0.63), lineWidth: 0.2))
                        }
                        
                        // Phone (Optional)
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Số điện thoại - không bắt buộc")
                                .font(
                                Font.custom("Source Sans Pro", size: 16)
                                .weight(.bold))
                            HStack {
                                Image(systemName: "phone")
                                    .foregroundColor(.gray)
                                TextField("Điền số điện thoại của bạn", text: $phoneNumber)
                                    .keyboardType(.phonePad)
                            }
                            .padding()
                            .background(.white)
                            .cornerRadius(10)
                            .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 4)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .inset(by: 0.1)
                                    .stroke(Color(red: 0.51, green: 0.55, blue: 0.63), lineWidth: 0.2))
                        }
                    }
                    
                    // Sign Up Button
                    Button(action: {
                        guard password == confirmPassword else {
                            showError = true
                            errorMessage = "Mật khẩu không trùng khớp."
                            return
                        }
                        
                        isSigningUp = true
                        AppManager.shared.isOnboardingCompleted = false

                        FirestoreManagerAdvance.shared.createAccount(withEmail: email, password: password, fullName: fullName, phoneNumber: phoneNumber) { result in
                            DispatchQueue.main.async {
                                switch result {
                                case .success:
                                    print("Đăng nhập thành công!")
                                case .failure(let error):
                                    showError = true
                                    errorMessage = error.localizedDescription
                                }
                                isSigningUp = false
                            }
                        }
//                        authManager.createAccount(
//                            withEmail: email,
//                            password: password,
//                            fullName: fullName,
//                            phoneNumber: phoneNumber
//                        ) { result in
//                            DispatchQueue.main.async {
//                                switch result {
//                                case .success:
//                                    print("Signed up successfully!")
//                                case .failure(let error):
//                                    showError = true
//                                    errorMessage = error.localizedDescription
//                                }
//                                isSigningUp = false
//                            }
//                        }
                    }) {
                        ZStack {
                            if isSigningUp {
                                HStack(spacing: 8) {
                                    Text("Đăng nhập")
                                        .font(Font.custom("Source Sans Pro", size: 16))
                                        .fontWeight(.bold)
                                    ProgressView()
                                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                }
                            } else {
                                HStack(spacing: 8) {
                                    Text("Đăng nhập")
                                        .font(Font.custom("Source Sans Pro", size: 16))
                                        .fontWeight(.bold)
                                    Image(systemName: "arrow.right")
                                        .font(.system(size: 16, weight: .semibold))
                                }
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 15)
                        .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .disabled(fullName.isEmpty || password.isEmpty || confirmPassword.isEmpty || isSigningUp)
                }
                .padding(.horizontal, 24)
                .padding(.top, 20)
            }
        }
        .navigationBarHidden(true)
        .alert(isPresented: $showError) {
            Alert(
                title: Text("Error"),
                message: Text(errorMessage),
                dismissButton: .default(Text("OK"))
            )
        }
        .navigationTransition()
        .animation(.easeInOut(duration: 0.3), value: true)
    }
}

// MARK: - Preview

struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView(email: "test@example.com")
            .environmentObject(AuthManager())
    }
}
