//
//  ScreeningHomeView.swift
//  Cura
//
//  Created by Vivek Padaya on 23/02/25.
//

import SwiftUI

struct ScreeningHomeView: View {
    @State var screeningConnections : [Connections]
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack {
            ZStack {
                // Centered Title
                Text("Screening Reminder")
                    .font(
                    Font.custom("Crimson Pro", size: 26)
                    .weight(.bold)
                    )
                    .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                    .frame(maxWidth: .infinity)
                
                // Back Button overlay
                HStack {
                    Button {
                        dismiss()
                    } label: {
                        Image("back-button")
                            .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                            .imageScale(.large)
                            .frame(width: 44, height: 44)
                            .background(Circle().fill(Color.white))
                            .overlay(
                                Circle()
                                    .stroke(Color(red: 0.14, green: 0.18, blue: 0.29), lineWidth: 1)
                            )
                            .shadow(color: .black.opacity(0.05), radius: 8, y: 4)
                    }
                    Spacer()
                }
            }
            .padding([.horizontal], 23.5)

            Spacer()
            Text("You've successfully scheduled!\n We'll contact you by the end of the research.")
                .font(.custom("Source Sans Pro", size: 24, relativeTo: .body))
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                .frame(maxWidth: .infinity)
                .multilineTextAlignment(.center)
                .padding([.horizontal], 20)
                
            Spacer()
        }.onAppear(perform: updateScreeningConnections)
        
    }
    
    func updateScreeningConnections() {
        guard let user = AppManager.shared.currentUser else {
            return
        }
        for screeningConnection in screeningConnections {
            FirestoreManagerAdvance.shared.seenScreeingRequest(for: user.userId, connectionId: screeningConnection.userId) { isSeen in
                print("\(screeningConnection.name) is seen")
            }
        }
        NotificationCenter.default.post(name: .newDataAdded,
                                        object: nil, userInfo: [:])
    }
}
