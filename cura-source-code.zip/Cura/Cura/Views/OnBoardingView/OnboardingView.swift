//
//  OnboardingView.swift
//  Cura
//
//  Created by Viet Tran on 28/11/24.
//
import SwiftUI

struct OnboardingView: View {
    @EnvironmentObject var authManager: AuthManager
    @EnvironmentObject var firestoreManager: FirestoreManager
    
    @State private var shouldNavigateToHome = false

    @State private var currentStep = 0
    @State private var birthday = Date()
    @State private var height = ""
    @State private var weight = ""
    @State private var selectedSex: String?
    @State private var dailyAssessmentTime = Date()

    @Environment(\.dismiss) var dismiss

    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Fixed header with logo and back button
                HStack {
                    // Back button taking fixed space
                    if currentStep > 0 {
                        Button(action: {
                            currentStep -= 1
                        }) {
                            Image("back-button")
                                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                                .imageScale(.large)
                                .frame(width: 44, height: 44)
                                .background(Circle().fill(Color.white))
                                .overlay(
                                    Circle()
                                        .stroke(Color(red: 0.14, green: 0.18, blue: 0.29), lineWidth: 1)
                                )
                                .shadow(color: .black.opacity(0.05), radius: 8, y: 4)
                        }
                    } else {
                        // Invisible placeholder to maintain spacing
                        Color.clear.frame(width: 44, height: 44)
                    }
                    
                    // Centered logo container
                    HStack {
                        Spacer()
                        Image("onboarding-logo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 140)
                        Spacer()
                    }
                    
                    // Right side spacing to match left side
                    Color.clear.frame(width: 44, height: 44)
                }
                .padding(.top, 40)
                
                // Content in ZStack for vertical centering
                ZStack {
                    // Content based on current step
                    switch currentStep {
                    case 0:
                        WelcomeStep(nextStep: { currentStep += 1 })
                    case 1:
                        BirthdayStep(birthday: $birthday, nextStep: { currentStep += 1 })
                    case 2:
                        HeightWeightStep(height: $height, weight: $weight, nextStep: { currentStep += 1 })
                    case 3:
                        BiologicalSexStep(selectedSex: $selectedSex, nextStep: { currentStep += 1 })
                    case 4:
                        AssessmentTimeStep(selectedTime: $dailyAssessmentTime, nextStep: { currentStep += 1 })
                    case 5:
                        CompletionStep(shouldNavigateToHome: $shouldNavigateToHome)
                    default:
                        EmptyView()
                    }
                }
                .padding(.bottom, 50)
                .frame(maxHeight: .infinity)
            }
            .padding(.horizontal, 23.5)
            .frame(width: 390, height: 844, alignment: .top)
            .background(.white)
//            .navigationDestination(isPresented: $shouldNavigateToHome) {
//                HomePage()
//            }
            .onChange(of: shouldNavigateToHome, { oldValue, newValue in
                if newValue {
                    AppManager.shared.isOnboardingCompleted = true
                    dismiss()
                }
            })
            .onChange(of: currentStep) { oldValue, newValue in
                if newValue == 4{
                    if var user = AppManager.shared.currentUser {
                        user.dateOfBirth = birthday.saveDateTimeFormate()
                        user.height = Double(height)
                        user.weight = Double(weight)
                        user.sex = selectedSex
                        
                        FirestoreManagerAdvance.shared.updateUserProfile(user: user) { isSuccess in
                            print("Successfully added details")
                            AppManager.shared.currentUser = user
                        }
                    }
                    
                    NotificationManager.shared.scheduleNotifications(for: dailyAssessmentTime)
                }
            }
        }
    }
    
    
}

struct WelcomeStep: View {
    let nextStep: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Hãy bắt đầu bằng một số câu hỏi.")
                .font(
                Font.custom("Crimson Pro", size: 36)
                .weight(.bold)
                )
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                .frame(width: 343, alignment: .topLeading)
            
            Text("Điều này sẽ giúp Cura hiểu hơn về bạn.")
                .font(
                Font.custom("Source Sans Pro", size: 16)
                .weight(.bold)
                )
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                .frame(maxWidth: .infinity, alignment: .leading)
            
            NextStepButton(action: nextStep)
        }
    }
}

struct BirthdayStep: View {
    @Binding var birthday: Date
    let nextStep: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Sinh nhật của bạn là khi nào?")
                .font(
                Font.custom("Crimson Pro", size: 32)
                .weight(.bold)
                )
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                .frame(width: 343, alignment: .topLeading)
            
            BirthdayInputField(birthday: $birthday)
            
            NextStepButton(action: nextStep)
        }
    }
}

struct BirthdayInputField: View {
    @Binding var birthday: Date
    @State private var isDatePickerVisible = false
    
    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd 'tháng' M yyyy"
        return formatter
    }
    
    var body: some View {
        Button(action: {
            isDatePickerVisible.toggle()
        }) {
            HStack {
                Image(systemName: "calendar")
                    .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                
                Text(birthday, formatter: dateFormatter)
                    .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                
                Spacer()
            }
            .padding(16)
            .frame(maxWidth: .infinity)
            .background(Color.white)
            .cornerRadius(12)
            .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
            )
        }
        .sheet(isPresented: $isDatePickerVisible) {
            DatePicker("", selection: $birthday, displayedComponents: .date)
                .datePickerStyle(.wheel)
                .labelsHidden()
                .environment(\.locale, Locale(identifier: "vi_VN"))
                .presentationDetents([.height(250)])
        }
    }
}

struct HeightWeightStep: View {
    @Binding var height: String
    @Binding var weight: String
    let nextStep: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Chiều cao và cân nặng của bạn là bao nhiêu?")
                .font(
                Font.custom("Crimson Pro", size: 32)
                .weight(.bold)
                )
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                .frame(width: 343, alignment: .topLeading)
            
            HStack(spacing: 16) {
                VStack(alignment: .leading) {
                    Text("Chiều cao")
                        .font(
                        Font.custom("Source Sans Pro", size: 16)
                        .weight(.bold)
                        )
                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                        .frame(maxWidth: .infinity, minHeight: 20, maxHeight: 20, alignment: .leading)
                    HStack {
                        TextField("", text: $height)
                            .keyboardType(.numberPad)
                        Text("cm")
                            .font(
                            Font.custom("Source Sans Pro", size: 16)
                            .weight(.semibold)
                            )
                            .foregroundColor(Color(red: 0.36, green: 0.41, blue: 0.52))
                    }
                    .padding()
                    .background(.white)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                    )
                }
                
                VStack(alignment: .leading) {
                    Text("Cân nặng")
                        .font(
                        Font.custom("Source Sans Pro", size: 16)
                        .weight(.bold)
                        )
                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                        .frame(maxWidth: .infinity, minHeight: 20, maxHeight: 20, alignment: .leading)
                    HStack {
                        TextField("", text: $weight)
                            .keyboardType(.numberPad)
                        Text("kg")
                            .font(
                            Font.custom("Source Sans Pro", size: 16)
                            .weight(.semibold)
                            )
                            .foregroundColor(Color(red: 0.36, green: 0.41, blue: 0.52))
                    }
                    .padding()
                    .background(.white)
                    .cornerRadius(12)
                    .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                    )
                }
            }
                        
            NextStepButton(action: nextStep)
                .disabled(height.isEmpty || weight.isEmpty)
                .opacity(height.isEmpty || weight.isEmpty ? 0.5 : 1.0)
        }
    }
}

struct BiologicalSexStep: View {
    @Binding var selectedSex: String?
    let nextStep: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Giới tính của bạn là gì?")
                .font(
                Font.custom("Crimson Pro", size: 32)
                .weight(.bold)
                )
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                .frame(width: 343, alignment: .topLeading)
            
            HStack(spacing: 16) {
                SexSelectionButton(title: "Nam", isSelected: selectedSex == "Male") {
                    selectedSex = "Male"
                }
                
                
                SexSelectionButton(title: "Nữ", isSelected: selectedSex == "Female") {
                    selectedSex = "Female"
                }
            }
                        
            NextStepButton(action: nextStep)
                .disabled(selectedSex == nil)
                .opacity(selectedSex == nil ? 0.5 : 1.0) // Reduce opacity when disabled
        }
    }
}

struct AssessmentTimeStep: View {
    @Binding var selectedTime: Date
    let nextStep: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Khi nào bạn muốn nhận thông báo nhắc nhở về cập nhật sức khỏe hàng ngày?")
                .font(
                    Font.custom("Crimson Pro", size: 32)
                        .weight(.bold)
                )
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                .frame(width: 343, alignment: .topLeading)
            
            DatePicker("Select Time",
                       selection: $selectedTime,
                       displayedComponents: .hourAndMinute)
                .datePickerStyle(.wheel)
                .labelsHidden()
            
            NextStepButton(action: nextStep)
        }
    }
}



struct CompletionStep: View {
    @Binding var shouldNavigateToHome: Bool
    
    var body: some View {
        VStack(spacing: 24) {
            Image("kobi-happy-icon")
                .resizable()
                .scaledToFit()
                .frame(width: 60)
            
            Text("Bạn đã hoàn tất.")
                .font(Font.custom("Crimson Pro", size: 36).weight(.bold))
                .multilineTextAlignment(.center)
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                .frame(width: 343, alignment: .top)
            
            Button(action: {
                shouldNavigateToHome = true
            }) {
                HStack {
                    Text("Bắt đầu sử dụng Cura")
                        .font(
                        Font.custom("Source Sans Pro", size: 16)
                        .weight(.bold)
                        )
                        .foregroundColor(.white)
                    Image(systemName: "arrow.right")
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 56)
                .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                .cornerRadius(12)
            }
        }
    }
}
struct NextStepButton: View {
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Text("Tiếp tục")
                    .font(
                    Font.custom("Source Sans Pro", size: 16)
                    .weight(.bold)
                    )
                    .foregroundColor(.white)
                Image(systemName: "arrow.right")
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .background(Color(red: 0.14, green: 0.18, blue: 0.29))
            .cornerRadius(12)
        }
    }
}

struct SexSelectionButton: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Text(title)
                    .font(
                    Font.custom("Source Sans Pro", size: 16)
                    .weight(.semibold)
                    )
                    .foregroundColor(isSelected ? .white : Color(red: 0.14, green: 0.18, blue: 0.29))
                Spacer()
                Image(isSelected ? "chosen-box" : "check-box-icon")
                    .resizable()
                    .frame(width: 20, height: 20)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(isSelected ? Color.blue : .white)
            .cornerRadius(12)
            .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
            )
        }
    }
}

struct OnboardingView_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingView()
            .environmentObject(AuthManager())
            .environmentObject(FirestoreManager())
    }
}
