import Foundation

struct ChatMessage: Identifiable, Equatable {
    let id = UUID()
    let text: String
    let isUser: Bool
    let timestamp = Date()
    let followUp: FollowUp?
    
    static func == (lhs: ChatMessage, rhs: ChatMessage) -> Bool {
        return lhs.id == rhs.id &&
            lhs.text == rhs.text &&
            lhs.isUser == rhs.isUser &&
            lhs.timestamp == rhs.timestamp &&
            lhs.followUp == rhs.followUp
    }
}

struct KobiPrompt: Identifiable {
    let id = UUID()
    let text: String
    let response: String
    let followUp: FollowUp?
}

struct FollowUp: Equatable {
    let question: String
    let options: [FollowUpOption]
}

struct FollowUpOption: Identifiable, Equatable {
    let id = UUID()
    let text: String
    let response: String
}

struct PromptCategory: Identifiable {
    let id = UUID()
    let title: String
    let prompts: [KobiPrompt]
}

