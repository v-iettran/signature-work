//
//  SignUpView.swift
//  Cura
//
//  Created by Viet Tran on 20/10/24.
//

import SwiftUI
import Charts

struct HomePage: View {
    @Environment(\.colorScheme) var colorScheme
    @EnvironmentObject var authManager: AuthManager
    @EnvironmentObject var firestoreManager: FirestoreManager
    @State private var isHomeSelected = true
    @State private var selectedTab = "Home"
    @State private var showFirestoreTest = false
    @State private var showOnboarding: Bool = false
    
    @State private var showProfile = false
    @State private var showSettings = false


    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                switch selectedTab {
                case "Connection":
                    NavigationView {
                        ConnectionView()
                    }
                case "Report":
                    ReportView()
                default:
                    // Home/Kobi content
                    VStack(spacing: 0) {
                        TopNavBar(isHomeSelected: $isHomeSelected, isShowProfile: $showProfile, isShowSettings: $showSettings)
                        
                        TabView(selection: $isHomeSelected) {
                            HomeView()
                                .tag(true)
                            KobiView()
                                .tag(false)
                        }
                        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    }
                }
                
                // Add this button somewhere in your layout
//                NavigationLink(destination:
//                    FirestoreTestView()
//                        .environmentObject(authManager)
//                        .environmentObject(firestoreManager)
//                ) {
//                    HStack {
//                        Text("Firestore Testing")
//                    }
//                    .padding()
//                    .background(Color.blue.opacity(0.1))
//                    .cornerRadius(10)
//                }
//                .padding()
                
                // Bottom Navigation Bar
                HStack(alignment: .center, spacing: 0) {
                    ForEach(["Home", "Kobi", "Report", "Connection"], id: \.self) { tab in
                        Button(action: {
                            selectedTab = tab
                            if tab == "Home" || tab == "Kobi" {
                                isHomeSelected = (tab == "Home")
                            }
                        }) {
                            VStack(spacing: 4) {
                                Image("\(tab.lowercased())-icon-bot")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 80, height: 80)
                            }
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 20)
                .background(.white)
            }
            .padding(.top, 28)
            .frame(width: 390, height: 844, alignment: .topLeading)
            .background(.white)
        }.fullScreenCover(isPresented: $showOnboarding, content: {
            OnboardingView()
        })
        .fullScreenCover(isPresented: $showProfile) {
            UserProfileView(user: AppManager.shared.currentUser!)
        }
        .fullScreenCover(isPresented: $showSettings) {
            SettingsView(isDissmis: $showSettings)
        }
        .onAppear {
            guard let user = AppManager.shared.currentUser else {
                return
            }
            
            if user.height == nil {
                showOnboarding.toggle()
            }
            
            
        }
       
    }
    
    
}

struct TopNavBar: View {
    @EnvironmentObject var authManager: AuthManager
    
    @Binding var isHomeSelected: Bool
    
    @Binding var isShowProfile: Bool
    @Binding var isShowSettings: Bool

    
    var body: some View {
        HStack {
            // Profile button
            Button(action: {
                withAnimation {
                    isShowProfile.toggle()
                }
            }) {
                Image("profile-icon")
                    .padding(12)
                    .frame(width: 49, height: 49, alignment: .center)
                    .background(
                        AngularGradient(
                            stops: [
                                Gradient.Stop(color: Color(red: 0, green: 0.8, blue: 0.96), location: 0.00),
                                Gradient.Stop(color: Color(red: 1, green: 0.37, blue: 0.64), location: 0.45),
                                Gradient.Stop(color: Color(red: 0.38, green: 0.46, blue: 0.68), location: 0.67),
                                Gradient.Stop(color: Color(red: 1, green: 0.13, blue: 0), location: 0.89),
                            ],
                            center: UnitPoint(x: 0.5, y: 0.5),
                            angle: Angle(degrees: 90)
                        )
                    )
                    .cornerRadius(24.5)
            }
            Spacer()
            
            // Top navigation bar (Toggle)
            Button(action: {
                withAnimation {
                    isHomeSelected.toggle()
                }
            }) {
                ZStack(alignment: isHomeSelected ? .leading : .trailing) {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color(red: 0.95, green: 0.96, blue: 0.98))
                        .frame(width: 170, height: 50)
                    
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.white)
                        .frame(width: 120, height: 50)
                        .shadow(radius: 3)
                        .animation(.easeInOut(duration: 0.3), value: isHomeSelected)
                    
                    HStack {
                        HStack {
                            if isHomeSelected {
                                Image("home-icon")
                                Text("Nhà")
                                    .font(Font.custom("Crimson Pro", size: 20).weight(.semibold))
                                    .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                            } else {
                                Image("home-icon-deactivated")
                            }
                        }
                        .foregroundColor(isHomeSelected ? .primary : .gray)
                        .frame(width: isHomeSelected ? 120 : 30)
                        
                        HStack {
                            if !isHomeSelected {
                                Image("kobi-icon")
                                Text("Kobi")
                                    .font(Font.custom("Crimson Pro", size: 20).weight(.semibold))
                                    .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                            } else {
                                Image("kobi-icon-deactivated")
                            }
                        }
                        .foregroundColor(!isHomeSelected ? .primary : .gray)
                        .frame(width: isHomeSelected ? 30 : 120)
                    }
                }
                .frame(height: 50)
                .padding()
            }
            .buttonStyle(PlainButtonStyle())
            Spacer()
            
            // Setting button
            Button(action: {
                isShowSettings = true
            }) {
                Image("setting-icon")
            }
        }
        .padding(.horizontal, 23.5)
        .frame(maxWidth: .infinity, alignment: .center)
    }
}

struct ChartHeaderView: View {
    let score: Int
    var onQuestionMarkTapped: () -> Void
    
    var body: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Điểm rủi ro của bạn là \(score)%.")
                    .font(Font.custom("Source Sans Pro", size: 24).weight(.bold))
                    .foregroundColor(.white)
                Text(getScoreDescription())
                    .font(Font.custom("Source Sans Pro", size: 16).weight(.bold))
                    .foregroundColor(.white)
                    .padding([.bottom], 30)
            }
            Spacer()
            Button(action: onQuestionMarkTapped) {
                Image(systemName: "questionmark.circle")
                    .font(.system(size: 24))
                    .foregroundColor(.white)
            }
        }
    }
    
    func getScoreDescription() -> String {
        switch score {
        case 76...100:
            return "Hãy lên lịch tầm soát sớm nhé!\n Kobi đã thông báo cho người thân của bạn."
        case 25...75:
            return "Hãy theo dõi sức khỏe của bạn thật cẩn thận.\n Kobi đã thông báo cho người thân của bạn."
        default:
            return "Cứ tiếp tục nhé, bạn đang làm rất tốt!"
        }
    }
    
   
    
}

// Separate component for the chart
struct RiskScoreChart: View {
    let data: [DailyRisk]

    private func getVietnameseWeekday(from date: Date) -> String {
        let calendar = Calendar.current
        let weekday = calendar.component(.weekday, from: date)
        
        switch weekday {
        case 1: return "CN"
        case 2: return "T2"
        case 3: return "T3"
        case 4: return "T4"
        case 5: return "T5"
        case 6: return "T6"
        case 7: return "T7"
        default: return ""
        }
    }

    var body: some View {
        let calendar = Calendar.current
        let startOfWeek = Date.startOfWeek()
        let allDays = (0...7).compactMap { calendar.date(byAdding: .day, value: $0, to: startOfWeek) }

        Chart {
            ForEach(data) { dataPoint in
                LineMark(
                    x: .value("Date", setTimeToHourMinuteSecond(dataPoint.date, hour: 6) ?? dataPoint.date),
                    y: .value("Risk Score", dataPoint.score)
                )
                .lineStyle(StrokeStyle(lineWidth: 2))
                .foregroundStyle(.white)
                .interpolationMethod(.catmullRom)
                .interpolationMethod(.catmullRom)
                
                PointMark(
                    x: .value("Date", setTimeToHourMinuteSecond(dataPoint.date, hour: 6) ?? dataPoint.date),
                    y: .value("Risk Score", dataPoint.score)
                )
                .foregroundStyle(.white)
                .symbolSize(50)
            }
            
            RuleMark(y: .value("Low Risk", 25))
                .lineStyle(StrokeStyle(lineWidth: 1))
                .foregroundStyle(.white.opacity(0.3))
            
            RuleMark(y: .value("Medium Risk", 75))
                .lineStyle(StrokeStyle(lineWidth: 1))
                .foregroundStyle(.white.opacity(0.3))
            
            RuleMark(y: .value("High Risk", 100))
                .lineStyle(StrokeStyle(lineWidth: 1))
                .foregroundStyle(.white.opacity(0.3))
        }
        .frame(height: 150)
        .chartYScale(domain: 0...100)
        .chartXAxis {
            AxisMarks(values: allDays) { value in
                AxisGridLine()
                    .foregroundStyle(.white.opacity(0.1))
                AxisValueLabel {
                    if let date = value.as(Date.self) {
                        Text(getVietnameseWeekday(from: date))
                            .foregroundStyle(.white)
                    }
                }
            }
        }
        .chartYAxis {
            AxisMarks(position: .leading, values: [0, 25, 50, 75, 100]) { value in
                AxisGridLine()
                    .foregroundStyle(.white.opacity(0.3))
                AxisValueLabel {
                    Text("\(value.index * 25)%")
                        .foregroundStyle(.white)
                }
            }
        }
    }
    
    func setTimeToHourMinuteSecond(_ date: Date, hour: Int) -> Date? {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day], from: date)
        return calendar.date(from: DateComponents(year: components.year,
                                                  month: components.month,
                                                  day: components.day,
                                                  hour: hour,
                                                  minute: 0,
                                                  second: 0))
    }
}



// First, add this new view for the back of the chart
struct ChartInfoView: View {
    var onQuestionMarkTapped: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Điểm rủi ro là gì?")
                    .font(Font.custom("Source Sans Pro", size: 24).weight(.bold))
                    .foregroundColor(.white)
                Spacer()
                Button(action: onQuestionMarkTapped) {
                    Image(systemName: "questionmark.circle")
                        .font(.system(size: 24))
                        .foregroundColor(.white)
                }
            }
            
            VStack(alignment: .leading, spacing: 12) {
                riskLevelRow(range: "0 - 25%", description: "Rủi ro thấp", color: .green)
                riskLevelRow(range: "25 - 75%", description: "Rủi ro trung bình", color: .yellow)
                riskLevelRow(range: "75 - 100%", description: "Rủi ro cao", color: Color(red: 0.47, green: 0, blue: 0))
            }

            Text("Điểm rủi ro là xác suất mắc ung thư trong một khoảng thời gian nhất định, tương đương với khả năng phát triển với ung thư. Tuy nhiên, điểm rủi ro không đồng nghĩa với chẩn đoán ung thư, mà chỉ là một chỉ số hữu ích giúp bạn quyết định có nên tầm soát ung thư kịp thời hay không.")
                .font(Font.custom("Source Sans Pro", size: 16))
                .foregroundColor(.white)
        }

    }
    
    private func riskLevelRow(range: String, description: String, color: Color) -> some View {
        HStack(spacing: 12) {
            Circle()
                .fill(color)
                .frame(width: 12, height: 12)
            Text(range)
                .font(Font.custom("Source Sans Pro", size: 16)
                    .weight(.bold))
                .foregroundColor(.white)
            Text("-")
                .foregroundColor(.white)
            Text(description)
                .font(Font.custom("Source Sans Pro", size: 16))
                .foregroundColor(.white)
        }
    }
}

struct FinishSetup: View {
    @Binding var showFinishSetup: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Chào mừng bạn đến với Cura! Hãy hoàn tất việc thiết lập hồ sơ của bạn. Khi hoàn thành, chúng ta sẽ bắt đầu tạo ra điểm rủi ro cá nhân của bạn.")
                .font(Font.custom("Source Sans Pro", size: 16))
                .fontWeight(.bold)
            
            Text("Việc này chỉ mất khoảng 2 phút.")
                .font(Font.system(size: 14, weight: .light))
                .italic(true)
            
            Button {
                showFinishSetup.toggle()
            } label: {
                Text("Hoàn tất thiết lập")
                    .font(Font.custom("Source Sans Pro", size: 16))
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity) // Ensure button expands fully
                    .padding(.vertical, 15)
                    .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
        }
        .padding(24)
        .background(Color.lightBlue)
        .cornerRadius(25)
    }
}

struct DailyRisk: Identifiable {
    let id = UUID()
    let date: Date
    let score: Double
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        HomePage()
            .environmentObject(AuthManager())
            .environmentObject(FirestoreManager())
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
            .environmentObject(AuthManager())
            .environmentObject(FirestoreManager())
    }
}

struct KobiView_Previews: PreviewProvider {
    static var previews: some View {
        KobiView()
            .environmentObject(AuthManager())
            .environmentObject(FirestoreManager())
    }
}

struct TopNavBar_Previews: PreviewProvider {
    static var previews: some View {
        TopNavBar(isHomeSelected: .constant(true), isShowProfile: .constant(false), isShowSettings: .constant(false))
            .environmentObject(AuthManager())
            .environmentObject(FirestoreManager())
    }
}
