//
//  KobiView.swift
//  Cura
//
//  Created by Viet Tran on 24/2/25.
//

import SwiftUI

// Main View
struct KobiView: View {
    @State private var chatMessages: [ChatMessage] = []
    @State private var isPromptExpanded = false
    @State private var isTyping = false
    
    let promptCategories = [
        PromptCategory(
            title: "Thông tin chung",
            prompts: [
                KobiPrompt(
                    text: "Điểm rủi ro là gì?",
                    response: "Điểm rủi ro là xác suất mắc ung thư trong một khoảng thời gian nhất định, tương đương với khả năng phát triển với ung thư. Điểm rủi ro có giá trị từ 0% đến 100%, trong đó 100% là nguy cơ cao nhất mắc ung thư. Tuy nhiên, điểm rủi ro không đồng nghĩa với chẩn đoán ung thư, mà chỉ là một chỉ số hữu ích giúp bạn quyết định có nên tầm soát ung thư kịp thời hay không.\n\nBạn có muốn tìm hiểu sự khác biệt giữa khả năng phát triển ung thư và chẩn đoán ung thư không?",
                    followUp: FollowUp(
                        question: "Bạn có muốn tìm hiểu sự khác biệt giữa khả năng phát triển ung thư và chẩn đoán ung thư không?",
                        options: [
                            FollowUpOption(
                                text: "Có",
                                response: "Khả năng phát triển ung thư (Cancer Susceptibility) là mức độ một người có nguy cơ cao hay thấp phát triển tế bào ung thư. Nguy cơ này có thể bị ảnh hưởng bởi yếu tố di truyền (gene) và yếu tố môi trường.\n\nVí dụ đơn giản:\n\nNếu trong gia đình có nhiều người mắc ung thư, bạn có thể có nguy cơ cao hơn do di truyền.\nNếu bạn hút thuốc lá hoặc thường xuyên tiếp xúc với hóa chất độc hại, bạn cũng có nguy cơ cao hơn dù không có yếu tố di truyền.\nNếu bạn có lối sống lành mạnh, ăn uống khoa học, tập thể dục thường xuyên, nguy cơ có thể thấp hơn.\n👉 Nói cách khác, cancer susceptibility là khả năng dễ bị ung thư, nhưng có nguy cơ cao không có nghĩa là chắc chắn sẽ mắc bệnh.\n\nChẩn đoán ung thư (Cancer Diagnostic) là quá trình xác định xem một người có bị ung thư hay không thông qua các phương pháp kiểm tra và xét nghiệm y khoa.\n\n🔹 Các phương pháp chẩn đoán ung thư phổ biến:\n\nSiêu âm/X-quang: Giúp phát hiện khối u bất thường trong cơ thể.\nXét nghiệm máu: Kiểm tra dấu ấn sinh học liên quan đến ung thư.\nSinh thiết: Lấy một mẫu tế bào để kiểm tra xem có tế bào ung thư hay không.\nChụp MRI/CT: Giúp quan sát kích thước và vị trí của khối u.\n👉 Nói cách khác, cancer diagnostic là quá trình bác sĩ tìm ra và xác nhận ung thư có tồn tại hay không trong cơ thể bạn.\n\n📌 Tóm lại:\n\nKhả năng phát triển ung thư là mức độ dễ mắc ung thư. Nó liên quan đến nguy cơ nhưng không đồng nghĩa với việc chắc chắn bị bệnh.\nChẩn đoán ung thư là quá trình kiểm tra và xác định xem một người có ung thư hay không.\nHy vọng bạn hiểu rõ hơn! 😊"
                            ),
                            FollowUpOption(
                                text: "Không",
                                response: "Được rồi! Hãy cho Kobi biết nếu bạn có câu hỏi nào khác nhé 😊"
                            )
                        ]
                    )
                ),
                KobiPrompt(
                    text: "Ung thư là gì?",
                    response: "Ung thư là một nhóm bệnh lý xảy ra khi các tế bào trong cơ thể phát triển mất kiểm soát, tạo thành khối u hoặc lan rộng ra khắp cơ thể.\u{2028}\u{2028} **Giải thích đơn giản:** \u{2028}• Cơ thể chúng ta có hàng nghìn tỷ tế bào\u{2028}• Mỗi ngày có những tế bào già chết đi và tế bào mới được tạo ra để thay thế\u{2028}• Khi quá trình này bị rối loạn, tế bào mới sinh ra liên tục mà không chết đi đúng lúc\u{2028}• Chúng sẽ tạo thành khối u (cục u bất thường)\u{2028}• Nếu khối u này ác tính, nó có thể phát triển và lan sang các bộ phận khác, gây ra ung thư",
                    followUp: nil
                ),
                KobiPrompt(
                    text: "Ung thư hoạt động như thế nào?",
                    response: "Ung thư xảy ra khi tế bào trong cơ thể bị đột biến (hỏng hóc) và phát triển mất kiểm soát.\u{2028}\u{2028} **Quá trình ung thư phát triển:** \u{2028}\u{2028}1. **Tế bào bị đột biến:** \u{2028}   • Do di truyền, hóa chất độc hại, bức xạ, virus\u{2028}   • Hoặc lối sống không lành mạnh\u{2028}\u{2028}2. **Tế bào ung thư sinh sôi mạnh:** \u{2028}   • Không tuân theo quy luật bình thường của cơ thể\u{2028}   • Phát triển nhanh chóng và tạo thành khối u\u{2028}\u{2028}3. **Khối u có thể xâm lấn:** \u{2028}   • Nếu không được kiểm soát, tế bào ung thư có thể di chuyển\u{2028}   • Lan đến các bộ phận khác trong cơ thể (gọi là di căn)\u{2028}\u{2028}4. **Gây tổn thương cơ thể:** \u{2028}   • Khi lan rộng, ung thư có thể làm tổn thương các cơ quan quan trọng\u{2028}   • Ảnh hưởng đến sức khỏe và sự sống",
                    followUp: nil
                ),
                KobiPrompt(
                    text: "Ung thư có chữa được không?",
                    response: "Ung thư có thể chữa khỏi hoặc kiểm soát được nếu phát hiện sớm và điều trị đúng cách.\u{2028}\u{2028} **Giai đoạn sớm:** \u{2028}• Nếu phát hiện sớm, một số loại ung thư có thể chữa khỏi hoàn toàn\u{2028}• Bằng phẫu thuật, hóa trị hoặc xạ trị\u{2028}\u{2028} **Giai đoạn muộn:** \u{2028}• Nếu ung thư đã lan rộng, việc chữa khỏi hoàn toàn rất khó\u{2028}• Nhưng có thể kéo dài tuổi thọ và cải thiện chất lượng sống bằng điều trị\u{2028}\u{2028} **Một số loại ung thư có thể kiểm soát lâu dài:** \u{2028}• Như ung thư tuyến giáp, ung thư vú giai đoạn đầu\u{2028}• Nếu được điều trị tốt, người bệnh có thể sống khỏe mạnh trong nhiều năm\u{2028}\u{2028} *👉 Tóm lại, ung thư không phải lúc nào cũng là \"án tử\". Nếu phát hiện sớm, cơ hội chữa khỏi rất cao!*",
                    followUp: nil
                )
            ]
        ),
        PromptCategory(
            title: "Tầm soát ung thư gan",
            prompts: [
                KobiPrompt(
                    text: "Bệnh viện nào tốt để tầm soát ung thư gan?",
                    response: "Để Kobi có thể gợi ý bệnh viện phù hợp nhất, xin cho biết khu vực bạn đang sinh sống:",
                    followUp: FollowUp(
                        question: "Bạn đang sống ở quận nào?",
                        options: [
                            FollowUpOption(
                                text: "Thủ Đức",
                                response: "Nếu bạn đang ở Thủ Đức và muốn tầm soát ung thư gan, bạn có thể tham khảo hai bệnh viện uy tín sau:\u{2028}\u{2028}1. **Bệnh viện Ung Bướu TP.HCM – Cơ sở 2**\u{2028}   Địa chỉ: Số 12 đường 400, Ấp Cây Dầu, Phường Tân Phú, TP. Thủ Đức, TP.HCM\u{2028}\u{2028}   Dịch vụ:\u{2028}   • Bệnh viện chuyên sâu về ung thư\u{2028}   • Tầm soát và điều trị ung thư gan với trang thiết bị hiện đại\u{2028}\u{2028}   *Lưu ý: Vì là bệnh viện công, chi phí thường thấp hơn so với bệnh viện tư, nhưng có thể mất thời gian chờ đợi.*\u{2028}\u{2028}2. **Bệnh viện Hoàn Mỹ Thủ Đức**\u{2028}   Địa chỉ: 241 Quốc lộ 1K, Phường Linh Xuân, TP. Thủ Đức, TP.HCM\u{2028}\u{2028}   Dịch vụ:\u{2028}   • Bệnh viện đa khoa tư nhân với hệ thống trang thiết bị tiên tiến\u{2028}   • Dịch vụ nhanh chóng và tiện lợi hơn so với bệnh viện công\u{2028}\u{2028} **Về giá trung bình tầm soát ung thư gan:** \u{2028}• Siêu âm gan + xét nghiệm máu (AFP, PIVKA-II): *500.000 - 1.500.000 VNĐ*\u{2028}• Chụp CT/MRI nếu cần kiểm tra kỹ hơn: *2.000.000 - 5.000.000 VNĐ*\u{2028}\u{2028}Bạn có thể liên hệ trực tiếp với bệnh viện để biết thông tin giá chính xác và đặt lịch khám. 😊"
                            ),
                            FollowUpOption(
                                text: "Quận 6",
                                response: "Nếu bạn ở Quận 6 và muốn tầm soát ung thư gan, bạn có thể tham khảo hai bệnh viện sau:\u{2028}\u{2028}1. **Bệnh viện Đại học Y Dược TP.HCM**\u{2028}   Địa chỉ: 215 Hồng Bàng, Phường 11, Quận 5, TP.HCM\u{2028}\u{2028}   Dịch vụ:\u{2028}   • Bệnh viện uy tín với các chuyên khoa về ung thư\u{2028}   • Đội ngũ bác sĩ giỏi và trang thiết bị hiện đại\u{2028}\u{2028}2. **Bệnh viện Nguyễn Tri Phương**\u{2028}   Địa chỉ: 468 Nguyễn Trãi, Phường 8, Quận 5, TP.HCM\u{2028}\u{2028}   Dịch vụ:\u{2028}   • Cung cấp các dịch vụ tầm soát ung thư gan chất lượng cao\u{2028}   • Chi phí hợp lý\u{2028}\u{2028} **Về giá trung bình tầm soát ung thư gan:** \u{2028}• Siêu âm gan + xét nghiệm máu (AFP, PIVKA-II): *500.000 - 1.500.000 VNĐ*\u{2028}• Chụp CT/MRI nếu cần kiểm tra kỹ hơn: *2.000.000 - 5.000.000 VNĐ*\u{2028}\u{2028}Bạn có thể liên hệ trực tiếp với bệnh viện để biết thông tin giá chính xác và đặt lịch khám. 😊"
                            ),
                            FollowUpOption(
                                text: "Quận 7",
                                response: "Nếu bạn ở Quận 7 và muốn tầm soát ung thư gan, bạn có thể tham khảo hai bệnh viện sau:\u{2028}\u{2028}1. **Bệnh viện Tâm Anh**\u{2028}   Địa chỉ: 5/5 đường 17, Phường 5, Quận Gò Vấp, TP.HCM\u{2028}   (cũng phục vụ khu vực Quận 7)\u{2028}\u{2028}   Dịch vụ:\u{2028}   • Dịch vụ khám chữa bệnh nhanh chóng và chất lượng\u{2028}   • Trang thiết bị hiện đại\u{2028}\u{2028}2. **Bệnh viện Đại học Y Dược TP.HCM**\u{2028}   Địa chỉ: 215 Hồng Bàng, Phường 11, Quận 5, TP.HCM\u{2028}\u{2028}   Dịch vụ:\u{2028}   • Đội ngũ bác sĩ chuyên khoa giàu kinh nghiệm\u{2028}   • Trang thiết bị tiên tiến\u{2028}\u{2028} **Về giá trung bình tầm soát ung thư gan:** \u{2028}• Siêu âm gan + xét nghiệm máu (AFP, PIVKA-II): *500.000 - 1.500.000 VNĐ*\u{2028}• Chụp CT/MRI nếu cần kiểm tra kỹ hơn: *2.000.000 - 5.000.000 VNĐ*\u{2028}\u{2028}Bạn có thể liên hệ trực tiếp với bệnh viện để biết thông tin giá chính xác và đặt lịch khám. 😊"
                            ),
                            FollowUpOption(
                                text: "Hà Nội",
                                response: "Nếu bạn ở Hà Nội và muốn tầm soát ung thư gan, bạn có thể đến:\u{2028}\u{2028}**Bệnh viện Trung ương Quân đội 108**\u{2028}Địa chỉ: 1A Quán Sứ, Hai Bà Trưng, Hà Nội\u{2028}\u{2028}Dịch vụ:\u{2028}• Bệnh viện chuyên sâu về ung thư và các bệnh lý liên quan\u{2028}• Trang thiết bị hiện đại và đội ngũ bác sĩ giỏi\u{2028}\u{2028}*Lưu ý: Đây là một bệnh viện uy tín và chất lượng, bạn sẽ nhận được dịch vụ chăm sóc sức khỏe chuyên nghiệp tại đây.*\u{2028}\u{2028} **Về giá trung bình tầm soát ung thư gan:** \u{2028}• Siêu âm gan + xét nghiệm máu (AFP, PIVKA-II): *500.000 - 1.500.000 VNĐ*\u{2028}• Chụp CT/MRI nếu cần kiểm tra kỹ hơn: *2.000.000 - 5.000.000 VNĐ*\u{2028}\u{2028}Bạn có thể liên hệ trực tiếp với bệnh viện để biết thông tin giá chính xác và đặt lịch khám. 😊"
                            ),
                            FollowUpOption(
                                text: "Khác",
                                response: "Với các khu vực ngoài các quận và thành phố đã liệt kê trên, mình hiện chưa có thông tin hỗ trợ cụ thể. Kobi sẽ được cập nhật trong tương lai, bạn vui lòng chờ nhé!"
                            )
                        ]
                    )
                ),
                KobiPrompt(
                    text: "Phương pháp nào được sử dụng để tầm soát ung thư gan?",
                    response: "Để tầm soát ung thư gan, bác sĩ thường sử dụng các phương pháp sau:\u{2028}\u{2028} **Siêu âm gan:** \u{2028}• Kiểm tra xem gan có xuất hiện khối u hay bất thường không\u{2028}\u{2028} **Xét nghiệm máu (AFP – Alpha-Fetoprotein):** \u{2028}• Đo nồng độ AFP, một chất có thể tăng cao khi có ung thư gan\u{2028}\u{2028} **Chụp CT hoặc MRI:** \u{2028}• Cung cấp hình ảnh chi tiết hơn về gan để xác định khối u nếu có nghi ngờ\u{2028}\u{2028} *👉 Tầm soát sớm giúp phát hiện ung thư gan ở giai đoạn đầu, tăng khả năng điều trị thành công.*",
                    followUp: nil
                )
            ]
        ),
        PromptCategory(
            title: "Tầm soát ung thư vú",
            prompts: [
                KobiPrompt(
                    text: "Bệnh viện nào tốt để tầm soát ung thư vú?",
                    response: "Để Kobi có thể gợi ý bệnh viện phù hợp nhất, xin cho biết khu vực bạn đang sinh sống:",
                    followUp: FollowUp(
                        question: "Bạn đang sống ở quận nào?",
                        options: [
                            FollowUpOption(
                                text: "Thủ Đức",
                                response: "Nếu bạn ở Thủ Đức và muốn tầm soát ung thư vú, bạn có thể tham khảo hai bệnh viện sau:\u{2028}\u{2028}1. **Bệnh viện Ung Bướu TP.HCM – Cơ sở 2**\u{2028}   Địa chỉ: 12 đường 400, Ấp Cây Dầu, Phường Tân Phú, TP. Thủ Đức, TP.HCM\u{2028}\u{2028}   Dịch vụ:\u{2028}   • Cung cấp các dịch vụ tầm soát ung thư vú với đội ngũ bác sĩ giỏi\u{2028}   • Trang thiết bị hiện đại\u{2028}\u{2028}   *Lưu ý: Đây là bệnh viện công, có chi phí hợp lý.*\u{2028}\u{2028}2. **Bệnh viện Hoàn Mỹ Thủ Đức**\u{2028}   Địa chỉ: 241 Quốc lộ 1K, Phường Linh Xuân, TP. Thủ Đức, TP.HCM\u{2028}\u{2028}   Dịch vụ:\u{2028}   • Bệnh viện tư nhân với dịch vụ nhanh chóng\u{2028}   • Chuyên nghiệp và tiện nghi\u{2028}\u{2028} **Về giá trung bình tầm soát ung thư vú:** \u{2028}• Siêu âm vú + xét nghiệm (nếu cần): *500.000 - 1.500.000 VNĐ*\u{2028}• Chụp X-quang vú (mammo): *1.000.000 - 2.000.000 VNĐ*\u{2028}\u{2028}Bạn có thể liên hệ trực tiếp với bệnh viện để biết thông tin giá chính xác và đặt lịch khám. 😊"
                            ),
                            FollowUpOption(
                                text: "Quận 6",
                                response: "Nếu bạn ở Quận 6 và muốn tầm soát ung thư vú, bạn có thể tham khảo hai bệnh viện sau:\u{2028}\u{2028}1. **Bệnh viện Đại học Y Dược TP.HCM**\u{2028}   Địa chỉ: 215 Hồng Bàng, Phường 11, Quận 5, TP.HCM\u{2028}\u{2028}   Dịch vụ:\u{2028}   • Bệnh viện có các chuyên khoa về ung thư vú\u{2028}   • Trang thiết bị và đội ngũ bác sĩ giỏi\u{2028}\u{2028}2. **Bệnh viện Hùng Vương**\u{2028}   Địa chỉ: 128 Hồng Bàng, Phường 12, Quận 5, TP.HCM\u{2028}\u{2028}   Dịch vụ:\u{2028}   • Cung cấp dịch vụ tầm soát ung thư vú\u{2028}   • Các bệnh lý phụ khoa khác\u{2028}\u{2028} **Về giá trung bình tầm soát ung thư vú:** \u{2028}• Siêu âm vú + xét nghiệm (nếu cần): *500.000 - 1.500.000 VNĐ*\u{2028}• Chụp X-quang vú (mammo): *1.000.000 - 2.000.000 VNĐ*\u{2028}\u{2028}Bạn có thể liên hệ trực tiếp với bệnh viện để biết thông tin giá chính xác và đặt lịch khám. 😊"
                            ),
                            FollowUpOption(
                                text: "Quận 7",
                                response: "Nếu bạn ở Quận 7 và muốn tầm soát ung thư vú, bạn có thể tham khảo hai bệnh viện sau:\u{2028}\u{2028}1. **Bệnh viện FV**\u{2028}   Địa chỉ: 6 Nguyễn Lương Bằng, Phường Tân Phú, Quận 7, TP.HCM\u{2028}\u{2028}   Dịch vụ:\u{2028}   • Bệnh viện chuyên cung cấp dịch vụ tầm soát ung thư vú\u{2028}   • Chất lượng cao và tiện nghi\u{2028}\u{2028}2. **Bệnh viện Tâm Anh**\u{2028}   Địa chỉ: 5/5 đường 17, Phường 5, Quận Gò Vấp (cũng phục vụ Quận 7)\u{2028}\u{2028}   Dịch vụ:\u{2028}   • Đội ngũ bác sĩ giỏi\u{2028}   • Trang thiết bị hiện đại\u{2028}\u{2028} **Về giá trung bình tầm soát ung thư vú:** \u{2028}• Siêu âm vú + xét nghiệm (nếu cần): *500.000 - 1.500.000 VNĐ*\u{2028}• Chụp X-quang vú (mammo): *1.000.000 - 2.000.000 VNĐ*\u{2028}\u{2028}Bạn có thể liên hệ trực tiếp với bệnh viện để biết thông tin giá chính xác và đặt lịch khám. 😊"
                            ),
                            FollowUpOption(
                                text: "Hà Nội",
                                response: "Nếu bạn ở Hà Nội và muốn tầm soát ung thư vú, bạn có thể đến:\u{2028}\u{2028}**Bệnh viện Trung ương Quân đội 108**\u{2028}Địa chỉ: 1A Quán Sứ, Hai Bà Trưng, Hà Nội\u{2028}\u{2028}Dịch vụ:\u{2028}• Đội ngũ bác sĩ chuyên khoa\u{2028}• Trang thiết bị hiện đại\u{2028}\u{2028} **Về giá trung bình tầm soát ung thư vú:** \u{2028}• Siêu âm vú + xét nghiệm (nếu cần): *500.000 - 1.500.000 VNĐ*\u{2028}• Chụp X-quang vú (mammo): *1.000.000 - 2.000.000 VNĐ*\u{2028}\u{2028}Bạn có thể liên hệ trực tiếp với bệnh viện để biết thông tin giá chính xác và đặt lịch khám. 😊"
                            ),
                            FollowUpOption(
                                text: "Khác",
                                response: "Với các khu vực ngoài các quận và thành phố đã liệt kê trên, mình hiện chưa có thông tin hỗ trợ cụ thể. Kobi sẽ được cập nhật trong tương lai, bạn vui lòng chờ nhé!"
                            )
                        ]
                    )
                ),
                KobiPrompt(
                    text: "Phương pháp nào được sử dụng để tầm soát ung thư vú?",
                    response: "Các phương pháp tầm soát ung thư vú phổ biến:\u{2028}\u{2028} **Tự khám vú:** \u{2028}• Kiểm tra xem có u cục, thay đổi bất thường ở vú không\u{2028}\u{2028} **Chụp nhũ ảnh (Mammogram):** \u{2028}• Phương pháp chính xác giúp phát hiện khối u nhỏ ngay cả khi chưa có triệu chứng\u{2028}\u{2028} **Siêu âm vú:** \u{2028}• Dùng cho người có mô vú dày hoặc khi cần kiểm tra thêm\u{2028}\u{2028} **MRI vú:** \u{2028}• Dành cho người có nguy cơ cao, giúp quan sát rõ hơn mô vú\u{2028}\u{2028} *👉 Tầm soát ung thư vú định kỳ giúp phát hiện sớm và tăng cơ hội điều trị thành công.*",
                    followUp: nil
                )
            ]
        )
    ]
    
    var body: some View {
        VStack(spacing: 0) {
            Text("Kobi Giải Đáp")
                .font(
                Font.custom("Crimson Pro", size: 30)
                .weight(.bold)
                )
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                .fontWeight(.bold)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 24)
                .padding([.top, .bottom], 16)
            
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(spacing: 16) {
                        ForEach(chatMessages) { message in
                            ChatMessageView(
                                message: message,
                                isTyping: message.isUser ? false : isTyping,
                                followUp: message.followUp,
                                onFollowUpSelected: { response in
                                    let optionText = message.followUp?.options.first(where: { $0.response == response })?.text ?? ""
                                    
                                    chatMessages.append(ChatMessage(
                                        text: optionText,
                                        isUser: true,
                                        followUp: nil
                                    ))
                                    
                                    isTyping = true
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                        chatMessages.append(ChatMessage(
                                            text: response,
                                            isUser: false,
                                            followUp: nil
                                        ))
                                        isTyping = false
                                    }
                                }
                            )
                            .id(message.id)
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 16)
                }
                .onChange(of: chatMessages) { _ in
                    if let lastMessage = chatMessages.last {
                        proxy.scrollTo(lastMessage.id)
                    }
                }
            }
            
            VStack(spacing: 0) {
                if isPromptExpanded {
                    Color.black.opacity(0.3)
                        .edgesIgnoringSafeArea(.all)
                        .onTapGesture {
                            withAnimation {
                                isPromptExpanded = false
                            }
                        }
                    
                    ScrollView {
                        VStack(spacing: 16) {
                            ForEach(promptCategories) { category in
                                PromptSection(category: category) { prompt in
                                    handlePromptSelection(prompt)
                                }
                            }
                        }
                        .padding(.horizontal, 24)
                        .padding(.vertical, 16)
                    }
                    .frame(height: UIScreen.main.bounds.height * 0.6)
                    .background(Color.white)
                }
                
                Button(action: {
                    withAnimation {
                        isPromptExpanded.toggle()
                    }
                }) {
                    HStack {
                        Image("kobi-happy-icon")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: 24)
                        Text("Bấm vào đây để hỏi Kobi")
                            .font(Font.custom("Source Sans Pro", size: 16).weight(.bold))
                        Spacer()
                        Image(systemName: isPromptExpanded ? "chevron.down" : "chevron.up")
                    }
                    .padding()
                    .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .padding()
                }
            }
        }
    }
    
    private func handlePromptSelection(_ prompt: KobiPrompt) {
        chatMessages.append(ChatMessage(
            text: prompt.text,
            isUser: true,
            followUp: nil
        ))
        
        isTyping = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            chatMessages.append(ChatMessage(
                text: prompt.response,
                isUser: false,
                followUp: prompt.followUp
            ))
            isTyping = false
        }
        
        withAnimation {
            isPromptExpanded = false
        }
    }
}

// Supporting Views
struct TypingIndicator: View {
    @State private var numberOfDots = 0
    let timer = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()
    
    var body: some View {
        HStack(spacing: 4) {
            ForEach(0..<3) { index in
                Circle()
                    .fill(Color.gray)
                    .frame(width: 6, height: 6)
                    .opacity(numberOfDots > index ? 1 : 0.3)
            }
        }
        .onReceive(timer) { _ in
            numberOfDots = (numberOfDots + 1) % 4
        }
    }
}

struct TypingTextView: View {
    let text: String
    @State private var displayedText = ""
    @State private var isTyping = true
    
    var body: some View {
        VStack(alignment: .leading) {
            if isTyping {
                TypingIndicator()
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
            } else {
                Text(displayedText)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
            }
        }
        .onAppear {
            startTyping()
        }
    }
    
    private func startTyping() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            var characters = Array(text)
            var currentIndex = 0
            
            Timer.scheduledTimer(withTimeInterval: 0.03, repeats: true) { timer in
                if currentIndex < characters.count {
                    displayedText += String(characters[currentIndex])
                    currentIndex += 1
                } else {
                    timer.invalidate()
                    isTyping = false
                }
            }
        }
    }
}

struct ChatMessageView: View {
    let message: ChatMessage
    let isTyping: Bool
    let followUp: FollowUp?
    let onFollowUpSelected: ((String) -> Void)?
    
    var body: some View {
        VStack(spacing: 8) {
            HStack {
                if message.isUser {
                    Spacer()
                }
                
                VStack(alignment: message.isUser ? .trailing : .leading) {
                    if message.isUser || !isTyping {
                        Text(try! AttributedString(markdown: message.text))
                            .font(.system(size: 14))
                            .multilineTextAlignment(.leading)
                            .lineSpacing(8)
                            .fixedSize(horizontal: false, vertical: true)
                            .frame(
                                maxWidth: message.isUser ? nil : UIScreen.main.bounds.width * 0.7,
                                alignment: .leading
                            )
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .textSelection(.enabled)
                    } else {
                        TypingTextView(text: message.text)
                    }
                }
                .background(message.isUser ?
                    Color(red: 0.14, green: 0.18, blue: 0.29) :
                    Color(red: 0.95, green: 0.95, blue: 0.95))
                .foregroundColor(message.isUser ? .white : Color(red: 0.14, green: 0.18, blue: 0.29))
                .cornerRadius(10)
                
                if !message.isUser {
                    Spacer()
                }
            }
            
            if !message.isUser && !isTyping, let followUp = followUp {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(followUp.options) { option in
                        Button(action: {
                            onFollowUpSelected?(option.response)
                        }) {
                            Text(option.text)
                                .padding(.horizontal, 10)
                                .font(Font.custom("Source Sans Pro", size: 14).weight(.bold))
                                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                                .padding(.vertical, 6)
                                .background(.clear) // Makes background transparent
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color(red: 0.14, green: 0.18, blue: 0.29), lineWidth: 1)
                                )
                        }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.leading, 8)
            }
        }
        .padding(.horizontal, 8)
    }
}

struct PromptSection: View {
    let category: PromptCategory
    let onPromptSelect: (KobiPrompt) -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(category.title)
                .font(Font.custom("Source Sans Pro", size: 18).weight(.bold))
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                .padding(.horizontal, 12)
            
            VStack(alignment: .leading, spacing: 4) {
                ForEach(category.prompts) { prompt in
                    Button(action: { onPromptSelect(prompt) }) {
                        Text(prompt.text)
                            .font(Font.custom("Source Sans Pro", size: 16))
                            .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                            .lineLimit(2)
                            .minimumScaleFactor(0.8)
                            .multilineTextAlignment(.leading) // Add this line
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.vertical, 6)
                            .padding(.horizontal, 10)
                            .background(Color(red: 0.95, green: 0.95, blue: 0.95))
                            .cornerRadius(6)
                    }
                }
            }
            .padding(.horizontal, 8)
        }
    }
}

