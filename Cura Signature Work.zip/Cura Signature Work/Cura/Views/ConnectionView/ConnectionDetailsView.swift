//
//  ConnectionDetailsView.swift
//  Cura
//
//  Created by Vivek Padaya on 21/02/25.
//

import SwiftUI
import Charts

struct ConnectionDetailsView: View {
    let connection : Connections
    @Environment(\.dismiss) private var dismiss

    @State var userProfile : UserProfile?
    @State var cancerRiskDataNew: [DailyRisk] = []
    @State private var assessments : [Assessment] = []

    @State private var sendNotification = false
    @State private var showError = false
    @State private var errorMessage = ""
    @State private var showRequestSent = false

    var body: some View {
        VStack{
            ZStack {
                // Back button aligned to the left
                HStack {
                    Button {
                        dismiss()
                    } label: {
                        Image("back-button")
                            .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                            .imageScale(.large)
                            .frame(width: 44, height: 44)
                            .background(Circle().fill(Color.white))
                            .overlay(
                                Circle()
                                    .stroke(Color(red: 0.14, green: 0.18, blue: 0.29), lineWidth: 1)
                            )
                            .shadow(color: .black.opacity(0.05), radius: 8, y: 4)
                    }
                    Spacer()
                }
                
                // Name centered in the screen
                Text(connection.name)
                    .font(Font.custom("Crimson Pro", size: 26).weight(.bold))
                    .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                    .frame(maxWidth: .infinity)
            }
            .padding()
            
            ScrollView {
                HStack{
                    Text("Điểm rủi ro")
                        .font(
                        Font.custom("Crimson Pro", size: 24)
                        .weight(.bold)
                        )
                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))

                    Spacer()
                }
                .padding([.horizontal], 23.5)

                
                VStack(alignment: .leading, spacing: 16) {
                    
                    
                    ChartConnectionHeaderView(score: Int(cancerRiskDataNew.last?.score ?? 0), connections: connection)
                    
                    RiskScoreConnectionChart(data: cancerRiskDataNew)
                }
                .padding(24)
                .background(backgroundColor)
                .cornerRadius(25)
                            
                Button {
                    sendNotification = true
                } label: {
                    Text("Nhắc \(connection.name) đi tầm soát.")
                        .font(Font.custom("Source Sans Pro", size: 16))
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity) // Ensure button expands fully
                        .padding(.vertical, 15)
                        .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()
            }
            
        }
        .padding()
        .navigationBarBackButtonHidden()
        .onAppear {
            FirestoreManagerAdvance.shared.fetchUserProfile(userId: connection.userId) { profile in
                self.userProfile = profile
                self.loadData()
            }
        }.onChange(of: sendNotification) { oldValue, newValue in
            if newValue == true{
                guard let connectionProfile = self.userProfile else {
                    return
                }
                
                guard let user = AppManager.shared.currentUser else {
                    return
                }
                
                FirestoreManagerAdvance.shared.sendScreeingRequest(for: user.userId, connectionId: connectionProfile.userId) { isSent in
                    if isSent {
                        sendPushNotification(to: connectionProfile.deviceToken ?? "fCEgvHxL3UDgvsQkCyixlF:APA91bE6TM_2ppnL86qZDojUWShQSHgX-e6-6wzwizlAszRTBU2BW78IbQ2TgYSbVntmXzJOBFvXxcuqo5r3ZyPOdASgHryzPBlPHJprc0BRP5ce4fNfqnY", title: "Screening Reminder.", body: "\(user.name ?? "Your connection") has reminded you to schedule your screening soon.", type: .screening)
                        showRequestSent = true
                    }else{
                        errorMessage = "Something went wrong please try again."
                        showError = true
                    }
                }
                
                
            }
        }
        .alert("Error", isPresented: $showError) {
            Button("OK") { }
        } message: {
            Text(errorMessage)
        }
        .alert("Success", isPresented: $showRequestSent) {
            Button("OK") { }
        } message: {
            Text("Screening request sent successfully.")
        }
    }
    
    func loadData() {
        FirestoreManagerAdvance.shared.fetchCurrentWeekAssessments(for: connection.userId) { assessmentData in
            assessments = assessmentData
            self.cancerRiskDataNew = []
            if assessmentData.isEmpty {
                let kobiScore = self.userProfile?.kobiScore
                let riskData = DailyRisk(date: Date(), score: Double(kobiScore ?? 0))
                self.cancerRiskDataNew.append(riskData)
            } else {
                // Sort the data by date in descending order to match chart's x-axis
                let sortedAssessments = assessments.sorted {
                    ($0.date.getDateFromString() ?? Date()) > ($1.date.getDateFromString() ?? Date())
                }
                print("Sorted Assessments:")
                sortedAssessments.forEach { assessment in
                    print("\(assessment.date): \(assessment.kobiScore ?? 0)")
                }
                
                self.cancerRiskDataNew = sortedAssessments.compactMap { assessment in
                    guard let date = assessment.date.getDateFromString() else { return nil }
                    return DailyRisk(date: date, score: Double(assessment.kobiScore ?? 0))
                }
            }
        }
    }

    
    var backgroundColor: Color {
        let currentScore = cancerRiskDataNew.last?.score ?? 0
        switch currentScore {
        case ..<25:
            return Color(red: 0.25, green: 0.45, blue: 0.25)
        case 25...75:
            return Color(red: 0.9, green: 0.7, blue: 0.37)
        default:
            return Color(red: 0.47, green: 0, blue: 0)
        }
    }
    
   
}



struct ChartConnectionHeaderView: View {
    let score: Int
    var connections: Connections
    
    var body: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Điểm rủi ro của \(connections.name) là \(score)%.")
                    .font(Font.custom("Source Sans Pro", size: 24).weight(.bold))
                    .foregroundColor(.white)
                Text(getScoreDescription())
                    .font(Font.custom("Source Sans Pro", size: 16).weight(.bold))
                    .foregroundColor(.white)
                    .padding([.bottom], 30)
            }
            Spacer()
        }
    }
    
    func getScoreDescription() -> String {
        switch score {
        case 76...100:
            return "Hãy nhắc nhở \(connections.name) đi tầm soát sớm."
        case 25...75:
            return "Cần theo dõi thêm sức khoẻ của \(connections.name)."
        default:
            return "\(connections.name) đang làm rất tốt!"
        }
    }
    
   
    
}

// Separate component for the chart
struct RiskScoreConnectionChart: View {
    let data: [DailyRisk]

    private func getVietnameseWeekday(from date: Date) -> String {
        let calendar = Calendar.current
        let weekday = calendar.component(.weekday, from: date)
        
        switch weekday {
        case 1: return "CN"
        case 2: return "T2"
        case 3: return "T3"
        case 4: return "T4"
        case 5: return "T5"
        case 6: return "T6"
        case 7: return "T7"
        default: return ""
        }
    }

    private func debugPrintDates(_ allDays: [Date]) {
        print("\n=== ConnectionDetailsView Debug ===")
        print("Start of Week:", Date.startOfWeek().formatted())
        print("All Days:")
        allDays.forEach { date in
            print("\(date.formatted()): \(getVietnameseWeekday(from: date))")
        }
        print("\nData Points:")
        data.forEach { point in
            print("\(point.date.formatted()): \(getVietnameseWeekday(from: point.date)) - Score: \(point.score)")
        }
        print("===========================\n")
    }

    var body: some View {
        let calendar = Calendar.current
        let startOfWeek = Date.startOfWeek()
        let allDays = (0...7).compactMap { calendar.date(byAdding: .day, value: $0, to: startOfWeek) }
        
        Chart {
            ForEach(data) { dataPoint in
                LineMark(
                    x: .value("Date", setTimeToHourMinuteSecond(dataPoint.date, hour: 6) ?? dataPoint.date),
                    y: .value("Risk Score", dataPoint.score)
                )
                .lineStyle(StrokeStyle(lineWidth: 2))
                .foregroundStyle(.white)
                .interpolationMethod(.catmullRom)
                
                PointMark(
                    x: .value("Date", setTimeToHourMinuteSecond(dataPoint.date, hour: 6) ?? dataPoint.date),
                    y: .value("Risk Score", dataPoint.score)
                )
                .foregroundStyle(.white)
                .symbolSize(50)
            }
            
            RuleMark(y: .value("Low Risk", 25))
                .lineStyle(StrokeStyle(lineWidth: 1))
                .foregroundStyle(.white.opacity(0.3))
            
            RuleMark(y: .value("Medium Risk", 75))
                .lineStyle(StrokeStyle(lineWidth: 1))
                .foregroundStyle(.white.opacity(0.3))
            
            RuleMark(y: .value("High Risk", 100))
                .lineStyle(StrokeStyle(lineWidth: 1))
                .foregroundStyle(.white.opacity(0.3))
        }
        .frame(height: 150)
        .chartYScale(domain: 0...100)
        .chartXAxis {
            AxisMarks(values: allDays) { value in
                AxisGridLine()
                    .foregroundStyle(.white.opacity(0.1))
                AxisValueLabel {
                    if let date = value.as(Date.self) {
                        Text(getVietnameseWeekday(from: date))
                            .foregroundStyle(.white)
                    }
                }
            }
        }
        .chartYAxis {
            AxisMarks(position: .leading, values: [0, 25, 50, 75, 100]) { value in
                AxisGridLine()
                    .foregroundStyle(.white.opacity(0.3))
                AxisValueLabel {
                    Text("\(value.index * 25)%")
                        .foregroundStyle(.white)
                }
            }
        }
        .onAppear {
            debugPrintDates(allDays)
        }
    }
    
    func setTimeToHourMinuteSecond(_ date: Date, hour: Int) -> Date? {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day], from: date)
        return calendar.date(from: DateComponents(year: components.year,
                                                  month: components.month,
                                                  day: components.day,
                                                  hour: hour,
                                                  minute: 0,
                                                  second: 0))
    }
}


#Preview {
    // Create sample data
    let sampleConnection = Connections(
        userId: "sample123",
        relationship: "Friend",
        name: "John Doe",
        email: "john@example.com",
        riskStatus: "Low",
        accepted: true,
        isSent: true,
        requestStatus: "Accepted"
    )
    
    // Create sample risk data
    let sampleRiskData = [
        DailyRisk(date: Date(), score: 65),
        DailyRisk(date: Date().addingTimeInterval(-86400), score: 70),  // Yesterday
        DailyRisk(date: Date().addingTimeInterval(-172800), score: 55), // Day before
        DailyRisk(date: Date().addingTimeInterval(-259200), score: 80), // 3 days ago
        DailyRisk(date: Date().addingTimeInterval(-345600), score: 45)  // 4 days ago
    ]
    
    NavigationStack {
        ConnectionDetailsView(connection: sampleConnection)
            .onAppear {
                // Simulate data loading
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    if let view = UIApplication.shared.windows.first?.rootViewController?.view as? UIHostingController<ConnectionDetailsView> {
                        (view.rootView as? ConnectionDetailsView)?.$cancerRiskDataNew.wrappedValue = sampleRiskData
                    }
                }
            }
    }
}
