//
//  RelationshipView.swift
//  Cura
//
//  Created by Vivek Padaya on 18/02/25.
//

import SwiftUI
import FirebaseAuth
import FirebaseCore
import FirebaseFirestore

struct RelationshipView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var selectedRelationship : String?
    let relationships = ["Chồng", "Vợ", "Con trai", "Con gái", "Mẹ", "Bố", "Khác"]
    
    // Add these properties to receive data
    let userData : UserProfile
    @State private var showInviteSent = false

    @State private var errorMessage: String?
    @State private var isShowingError = false
    @Binding var shareWithfamily: Bool

    
    var body : some View {
        VStack(alignment : .leading , spacing : 24) {
            HStack{
                Button(action : { dismiss() }) {
                    Image("back-button").foregroundColor(Color(red : 0.14 , green : 0.18 , blue : 0.29)).imageScale(.large).frame(width : 44 , height : 44).background(Circle().fill(Color.white)).overlay(Circle().stroke(Color(red : 0.14 , green : 0.18 , blue : 0.29), lineWidth : 1)).shadow(color : .black.opacity(0.05), radius : 8 , y : 4 )
                }

                HStack{
                    Spacer()
                    Text("Mối quan hệ").font(Font.custom("Crimson Pro" , size : 24).weight(.bold)).foregroundColor(Color(red : 0.14 , green : 0.18 , blue : 0.29))
                    Spacer()
                }

                 Color.clear.frame(width : 44 , height : 44 )
             }

             Text("Người này là gì của bạn?").font(.title).fontWeight(.bold)

            ScrollView {
                ForEach(relationships,id:\.self){relationship in
                    RelationshipButton(title : relationship,isSelected:selectedRelationship == relationship){
                        selectedRelationship = relationship
                    }
                    .padding(10)
                }
            }
             

//            NavigationLink(destination : InviteSentView()) {
//                 HStack {
//                     Text("Send invite").fontWeight(.semibold)
//                     Image(systemName:"arrow.right")
//                 }
//                 .foregroundColor(.white)
//                 .frame(maxWidth:.infinity)
//                 .frame(height :56)
//                 .background(Color(red :0.14 , green :0.18 , blue :0.29))
//                 .cornerRadius(12)
//             }
            
            Button {
                sendInvite()
            } label: {
                HStack {
                    Text("Gửi lời mời").fontWeight(.semibold)
                    Image(systemName:"arrow.right")
                }
                .foregroundColor(.white)
                .frame(maxWidth:.infinity)
                .frame(height :56)
                .background(Color(red :0.14 , green :0.18 , blue :0.29))
                .cornerRadius(12)
                .opacity(selectedRelationship == nil ? 0.5 : 1.0)
            }
            .disabled(selectedRelationship == nil)

         }
        .frame(maxHeight: .infinity, alignment: .top)
        .padding(.horizontal, 23.5)
        .background(.white)
        .navigationBarBackButtonHidden(true)
         .navigationDestination(isPresented: $showInviteSent) {
             InviteSentView(shareWithfamily: $shareWithfamily)
         }
         .alert("Có lỗi", isPresented: $isShowingError) {
             Button("OK", role: .cancel) { }
         } message: {
             Text(errorMessage ?? "Lỗi không xác định")
         }
     }
    
    func sendInvite(){
        guard let currentUser = AppManager.shared.currentUser else {
            return
        }
        var connection = Connections(userId: userData.userId, name: userData.name ?? "", email: userData.email ?? "")
        connection.accepted = false
        connection.isSent = true
        connection.relationship = selectedRelationship ?? ""
        connection.riskStatus = userData.riskStatus ?? ""
        connection.requestStatus = "Đang chờ phản hồi"
        
       
        FirestoreManagerAdvance.shared.sendConnectionRequest(from: currentUser.userId, to: userData.userId, connection: connection) { isSuccess in
            if isSuccess{
                showInviteSent = true
                sendPushNotification(to: userData.deviceToken ?? "", title: "Lời mời kết nối", body: "\(currentUser.name ?? "User") đã gửi bạn một lời mời kết nối.", type: .connectionRequest)
            }else{
                errorMessage = "Đã xảy ra lỗi. Vui lòng thử lại trong giây lát."
                isShowingError = true
            }
        }
        
        
    }
}
