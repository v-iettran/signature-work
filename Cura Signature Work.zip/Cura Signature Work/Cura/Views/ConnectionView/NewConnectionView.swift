//
//  NewConnectionView.swift
//  Cura
//
//  Created by Vivek Padaya on 18/02/25.
//

import SwiftUI
import FirebaseAuth
import FirebaseCore
import FirebaseFirestore

//After click share to family, we navigate to this page
struct NewConnectionView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var email = ""
    @State private var phoneNumber = ""
    @State private var fullName = ""
    @State private var showRelationshipView = false
    @State private var errorMessage: String?
    @State private var isShowingError = false
    @State private var userDataLoaded: UserProfile?

    @Binding var shareWithfamily: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 24) {
            // Navigation header
            HStack {
                Button(action: { dismiss() }) {
                    Image("back-button")
                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                        .imageScale(.large)
                        .frame(width: 44, height: 44)
                        .background(Circle().fill(Color.white))
                        .overlay(
                            Circle()
                                .stroke(Color(red: 0.14, green: 0.18, blue: 0.29), lineWidth: 1)
                        )
                        .shadow(color: .black.opacity(0.05), radius: 8, y: 4)
                }
                
                HStack {
                    Spacer()
                    Text("Kết nối mới!")
                        .font(Font.custom("Crimson Pro", size: 24).weight(.bold))
                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                    Spacer()
                }
                
                Color.clear.frame(width: 44, height: 44)
            }
            
            Text("Hãy tìm kiếm bằng tên hoặc địa chỉ email.")
                .font(Font.custom("Crimson Pro", size: 32).weight(.bold))
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                .frame(width: 343, alignment: .topLeading)
            
            VStack(alignment: .leading, spacing: 10) {
                VStack(spacing: 8) {
                    Text("Email")
                        .font(Font.custom("Source Sans Pro", size: 16).weight(.bold))
                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                        .frame(width: 343, height: 20, alignment: .leading)
                    TextField("Điền email của người thân bạn", text: $email)
                        .keyboardType(.emailAddress)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 11)
                        .frame(width: 343, height: 54, alignment: .center)
                        .background(.white)
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 4)
                        .overlay(RoundedRectangle(cornerRadius: 10)
                            .stroke(Color(red: 0.506, green: 0.545, blue: 0.627), lineWidth: 0.5))
                }
                
                Text("Hoặc")
                    .foregroundColor(.gray)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding([.vertical], 10)
                
//                VStack(spacing: 8) {
//                    Text("Phone number")
//                        .font(Font.custom("Source Sans Pro", size: 16).weight(.bold))
//                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
//                        .frame(width: 343, height: 20, alignment: .leading)
//                    TextField("Their phone number", text: $phoneNumber)
//                        .keyboardType(.phonePad)
//                        .padding(.horizontal, 12)
//                        .padding(.vertical, 11)
//                        .frame(width: 343, height: 54, alignment: .center)
//                        .background(.white)
//                        .cornerRadius(10)
//                        .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 4)
//                        .overlay(RoundedRectangle(cornerRadius: 10)
//                            .stroke(Color(red: 0.506, green: 0.545, blue: 0.627), lineWidth: 0.5))
//                }
                
                VStack(spacing: 8) {
                    Text("Họ và tên đầy đủ")
                        .font(Font.custom("Source Sans Pro", size: 16).weight(.bold))
                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                        .frame(width: 343, height: 20, alignment: .leading)
                    TextField("Đầy đủ họ tên và tên lót", text: $fullName)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 11)
                        .frame(width: 343, height: 54, alignment: .center)
                        .background(.white)
                        .cornerRadius(10)
                        .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 4)
                        .overlay(RoundedRectangle(cornerRadius: 10)
                            .stroke(Color(red: 0.506, green: 0.545, blue: 0.627), lineWidth: 0.5))
                }
                .padding(.top, 5)
            }
            
            Button(action: validateEmail) {
                HStack {
                    Text("Tiếp theo")
                        .fontWeight(.semibold)
                    Image(systemName: "arrow.right")
                }
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 56)
                .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                .cornerRadius(12)
            }
            
            VStack(alignment: .center) {
                Text("Để đảm bảo an toàn và quyền riêng tư của bạn, chúng tôi yêu cầu bạn nhập đầy đủ họ và tên hợp pháp của thành viên gia đình. Điều này giúp xác minh rằng bạn không gửi yêu cầu nhầm đến người khác.")
                    .font(Font.custom("Source Sans Pro", size: 12))
                    .multilineTextAlignment(.center)
                    .foregroundColor(Color(red: 0.36, green: 0.41, blue: 0.52))
                    .frame(width: 300, alignment: .center)
            }
            .frame(maxWidth: .infinity)
        }
        .frame(maxHeight: .infinity, alignment: .top)
        .padding(.horizontal, 23.5)
        .background(.white)
        .navigationBarBackButtonHidden(true)
        .alert("Có lỗi", isPresented: $isShowingError) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(errorMessage ?? "Lỗi không xác định")
        }
        .navigationDestination(isPresented: $showRelationshipView) {
            if let userData = userDataLoaded {
                RelationshipView(userData: userData, shareWithfamily: $shareWithfamily)
            } else {
                // Fallback UI or an empty view to prevent crashes
                Text("Đang tải...")
            }
        }
    }
    
//    func validateEmail() {
//        // Check if the email and full name fields are not empty
//        guard !email.isEmpty else {
//            errorMessage = "Please enter an email address"
//            isShowingError = true
//            return
//        }
//        
//        guard !fullName.isEmpty else {
//            errorMessage = "Please enter a full name"
//            isShowingError = true
//            return
//        }
//
//        let db = Firestore.firestore()
//        
//        // Normalize the email to lowercase for querying
//        db.collection("users")
//            .whereField("email", isEqualTo: email.lowercased()) // Ensure case insensitivity
//            .getDocuments { snapshot, error in
//                DispatchQueue.main.async {
//                    if let error = error {
//                        // Log and display an error message if the query fails
//                        print("Error querying email: \(error.localizedDescription)")
//                        errorMessage = "Unable to verify email. Please try again."
//                        isShowingError = true
//                        return
//                    }
//                    
//                    // Check if the snapshot has documents (i.e., email exists)
//                    if let snapshot = snapshot, !snapshot.isEmpty {
//                        print("Email exists in database.")
//                        showRelationshipView = true
//                    } else {
//                        print("No matching email found.")
//                        errorMessage = "Account does not exist"
//                        isShowingError = true
//                    }
//                }
//            }
//    }
    
    func validateEmail() {
        // Check if the email and full name fields are not empty
        
        
        if email.isEmpty && fullName.isEmpty {
            errorMessage = "Vui lòng điền địa chỉ email hoặc họ tên của người thân bạn."
            isShowingError = true
            return
        }
        
        if !email.isEmpty{
            if email == AppManager.shared.currentUser?.email ?? "" {
                errorMessage = "Bạn không thể gửi lời mời cho chính bạn."
                isShowingError = true
                return
            }
            FirestoreManagerAdvance.shared.fetchUserProfileByEmail(email: email.lowercased()) { userData in
                
                guard let user = userData else {
                    print("Không tìm thấy email.")
                    errorMessage = "Tài khoản không tồn tại."
                    isShowingError = true
                    return
                }
                guard let userData = AppManager.shared.currentUser else {
                    errorMessage = "Đã xảy ra lỗi. Vui lòng thử lại trong giây lát."
                    isShowingError = true
                    return
                }
                FirestoreManagerAdvance.shared.checkIfConnectionExists(for: userData.userId, email: email.lowercased(), name: "") { isExists in
                    if isExists{
                        errorMessage = "Bạn đã kết nối với người này."
                        isShowingError = true
                        return
                    }else{
                        userDataLoaded = user
                        showRelationshipView = true
                    }
                }
                
               
            }
        }else if !fullName.isEmpty{
            FirestoreManagerAdvance.shared.fetchUserProfileByUsername(username: fullName, completion: { userData in
                guard let user = userData else {
                    print("Không tìm thấy email tương thích.")
                    errorMessage = "Tài khoản không tồn tại"
                    isShowingError = true
                    return
                }
                guard let userData = AppManager.shared.currentUser else {
                    errorMessage = "Đã xảy ra lỗi. Vui lòng thử lại trong giây lát."
                    isShowingError = true
                    return
                }
                FirestoreManagerAdvance.shared.checkIfConnectionExists(for: userData.userId, email: "", name: fullName) { isExists in
                    if isExists{
                        errorMessage = "Bạn đã kết nối với người này."
                        isShowingError = true
                        return
                    }else{
                        userDataLoaded = user
                        showRelationshipView = true
                    }
                }
            })
        }
        
        
    }
    
    
    
}

#Preview {
    NewConnectionView(shareWithfamily: .constant(false))
}
