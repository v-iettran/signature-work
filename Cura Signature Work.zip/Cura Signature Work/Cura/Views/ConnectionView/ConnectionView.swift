//
//  ConnectionView.swift
//  Cura
//
//  Created by Viet Tran on 1/12/24.
//

import SwiftUI
import FirebaseAuth
import FirebaseCore
import FirebaseFirestore

struct Connection: Identifiable {
    let id = UUID()
    let name: String
    let relationship: String
    let email: String?
    let isCuraCode: Bool
    let status: ConnectionStatus
}

enum ConnectionStatus {
    case pending
    case accepted
    case rejected
}

struct ConnectionView: View {
    @EnvironmentObject var firestoreManager: FirestoreManager
    @State private var email = ""
    @State private var showError = false
    @State private var errorMessage = ""
    @State private var isLoading = false
    @State private var connections: [UserData] = []
    @State private var sharewithfamily = false
    @State private var showConnectionDetail = false

    @State private var allConnections: [Connections] = []
    
    @State private var riskStatuses: [String: String] = [:] // Store fetched risk statuses
       @State private var loadingStatuses: Set<String> = [] // Track loading states

    var body: some View {
        VStack {
            // ... your existing UI code ...
            Text("Kết nối với người thân")
                .font(
                Font.custom("Crimson Pro", size: 30)
                .weight(.bold)
                )
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                .padding([.top])
                .padding([.horizontal], 20)
                .frame(maxWidth: .infinity, alignment: .topLeading)
            
            ConnectHeaderView()
                .padding(20)
            
//            TextField("Enter email address", text: $email)
//                .textFieldStyle(RoundedBorderTextFieldStyle())
//                .autocapitalization(.none)
//                .keyboardType(.emailAddress)
//            
//            Button("Connect") {
//                connectWithUser()
//            }
//            .disabled(isLoading)
//            
//            if isLoading {
//                ProgressView()
//            }
            
            if allConnections.isEmpty {
                Text("Bạn chưa kết nối với ai.\n Vui lòng chọn \"Chia sẻ với người thân\" để bắt đầu.")
                    .font(Font.custom("Source Sans Pro", size: 16))
                    .foregroundColor(Color(red: 0.36, green: 0.41, blue: 0.52))
                    .frame(maxWidth: .infinity)
                    .multilineTextAlignment(.center)
                    .padding([.horizontal], 20)
                Spacer()
            }else{
                // Display connections
                List(allConnections, id: \.userId) { connection in
                    HStack{
                        Image("profile-icon")
                            .padding(12)
                            .frame(width: 49, height: 49, alignment: .center)
                            .background(
                                AngularGradient(
                                    stops: [
                                        Gradient.Stop(color: Color(red: 0, green: 0.8, blue: 0.96), location: 0.00),
                                        Gradient.Stop(color: Color(red: 1, green: 0.37, blue: 0.64), location: 0.45),
                                        Gradient.Stop(color: Color(red: 0.38, green: 0.46, blue: 0.68), location: 0.67),
                                        Gradient.Stop(color: Color(red: 1, green: 0.13, blue: 0), location: 0.89),
                                    ],
                                    center: UnitPoint(x: 0.5, y: 0.5),
                                    angle: Angle(degrees: 90)
                                )
                            )
                            .cornerRadius(24.5)
                        if let isAccepted = connection.accepted, isAccepted {
                            NavigationLink {
                                ConnectionDetailsView(connection: connection)
                            } label: {
                                VStack(alignment: .leading) {
                                    Text(connection.name)
                                        .font(.headline)
                                    if let riskStatus = riskStatuses[connection.userId] {
                                        Text("Rủi ro: \(riskStatus)")
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                    } else if loadingStatuses.contains(connection.userId) {
                                        ProgressView()
                                            .progressViewStyle(CircularProgressViewStyle())
                                    } else {
                                        Text("Risk Status: Fetching...")
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                    }
                                }
                                .onAppear {
                                    loadRiskStatus(for: connection.userId)
                                }
                            }

                            
                        }else{
                            
                            VStack(alignment: .leading) {
                                Text(connection.name)
                                    .font(.headline)
                                Text("Trạng thái: \(connection.requestStatus ?? "đang chờ phản hồi")")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                            
                        }
                        
                        
                    }
                    
                }
            }
           
            
            Button {
                sharewithfamily.toggle()
            } label: {
                Text("Chia sẻ với người thân")
                    .font(Font.custom("Source Sans Pro", size: 16))
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity) // Ensure button expands fully
                    .padding(.vertical, 15)
                    .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding()
        }
        .alert("Error", isPresented: $showError) {
            Button("OK") { }
        } message: {
            Text(errorMessage)
        }
        .fullScreenCover(isPresented: $sharewithfamily, content: {
            NavigationStack(root: {
                NewConnectionView(shareWithfamily: $sharewithfamily)

            }) 
        })
        .onAppear {
            loadConnections()
        }.onChange(of: sharewithfamily) { oldValue, newValue in
            if newValue == false {
                withAnimation {
                    self.loadConnections()
                }
            }
        }
        .navigationBarHidden(true)
        
    }
    
//    private func connectWithUser() {
//        isLoading = true
//        Task {
//            do {
//                try await firestoreManager.connectWithUser(email: email)
//                await loadConnections()
//                email = "" // Clear the input field
//            } catch {
//                errorMessage = error.localizedDescription
//                showError = true
//            }
//            isLoading = false
//        }
//    }
    
    private func loadConnections() {
        guard let userData = AppManager.shared.currentUser else {
            return
        }
        isLoading = true
        FirestoreManagerAdvance.shared.fetchConnections(for: userData.userId) { allconnection in
            self.allConnections = allconnection
            isLoading = false
            
        }
    }
    
    private func loadRiskStatus(for userId: String) {
        guard riskStatuses[userId] == nil, !loadingStatuses.contains(userId) else { return }
        
        loadingStatuses.insert(userId)
        
        FirestoreManagerAdvance.shared.fetchUserProfile(userId: userId) { profile in
            DispatchQueue.main.async {
                riskStatuses[userId] = profile?.riskStatus ?? "Unknown"
                loadingStatuses.remove(userId)
            }
        }
        
    }

}

class ConnectionManager {
    static func sendConnectionRequest(
        toEmail: String,
        fromUID: String,
        relationship: String,
        sharingOption: String,
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        let db = Firestore.firestore()
        let requestData:[String: Any]=[
           "toEmail":toEmail,
           "fromUID":fromUID,
           "relationship":relationship,
           "sharingOption":sharingOption,
           "status":"pending",
           "timestamp":Timestamp()
       ]
        
        db.collection("connectionRequests").addDocument(data: requestData) { error in
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.success(()))
            }
        }
    }
}


struct ConnectHeaderView: View {
    var body: some View {
        
        VStack(alignment: .leading, spacing: 10) {
            
            HStack{
                Spacer()
                Image("connection-header")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 80, height: 80)
                
                Spacer()
            }
                
            HStack{
                Spacer()
                Text("Cura Connect")
                    .font(
                        Font.custom("Crimson Pro", size: 32)
                            .weight(.bold)
                    )
                Spacer()
            }
           
        }
        .padding(12)
        .background(Color.lightBlue)
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.25), radius: 7.5, x: 0, y: 4)
    }
}




//struct RelationshipView: View {
//    @Environment(\.dismiss) private var dismiss
//    @State private var selectedRelationship : String?
//    let relationships = ["Husband", "Wife", "Son", "Daughter", "Mother", "Father", "Grandparent", "Other"]
//    
//    // Add these properties to receive data
//    let email : String
//    let fullName : String
//    
//    var body : some View {
//        VStack(alignment : .leading , spacing : 24) {
//            HStack{
//                Button(action : { dismiss() }) {
//                    Image("back-button").foregroundColor(Color(red : 0.14 , green : 0.18 , blue : 0.29)).imageScale(.large).frame(width : 44 , height : 44).background(Circle().fill(Color.white)).overlay(Circle().stroke(Color(red : 0.14 , green : 0.18 , blue : 0.29), lineWidth : 1)).shadow(color : .black.opacity(0.05), radius : 8 , y : 4 )
//                }
//
//                HStack{
//                    Spacer()
//                    Text("Relationship").font(Font.custom("Crimson Pro" , size : 24).weight(.bold)).foregroundColor(Color(red : 0.14 , green : 0.18 , blue : 0.29))
//                    Spacer()
//                }
//
//                 Color.clear.frame(width : 44 , height : 44 )
//             }
//
//             Text("What's your relationship?").font(.title).fontWeight(.bold)
//
//             ForEach(relationships,id:\.self){relationship in
//                 RelationshipButton(title : relationship,isSelected:selectedRelationship == relationship){
//                     selectedRelationship = relationship
//                 }
//             }
//
//             NavigationLink(destination : SharingView(email : email , fullName : fullName , relationship:selectedRelationship ?? "")) {
//                 HStack {
//                     Text("Next step").fontWeight(.semibold)
//                     Image(systemName:"arrow.right")
//                 }
//                 .foregroundColor(.white)
//                 .frame(maxWidth:.infinity)
//                 .frame(height :56)
//                 .background(Color(red :0.14 , green :0.18 , blue :0.29))
//                 .cornerRadius(12)
//             }
//         }
//         .padding(.horizontal ,23.5)
//         .background(.white)
//         .navigationBarBackButtonHidden(true)
//     }
//}

//struct SharingView: View {
//    @Environment(\.dismiss) private var dismiss
//    @State private var selectedOption: String?
//    @State private var showInviteSent = false
//    let options = ["My health status", "Screening schedule", "Both"]
//    
//    let email: String
//    let fullName: String
//    let relationship: String
//    
//    var body: some View {  // Added missing body property
//        VStack(alignment: .leading, spacing: 24) {
//            HStack {
//                Button(action: { dismiss() }) {
//                    Image("back-button")
//                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
//                        .imageScale(.large)
//                        .frame(width: 44, height: 44)
//                        .background(Circle().fill(Color.white))
//                        .overlay(
//                            Circle()
//                                .stroke(Color(red: 0.14, green: 0.18, blue: 0.29), lineWidth: 1)
//                        )
//                        .shadow(color: .black.opacity(0.05), radius: 8, y: 4)
//                }
//                
//                HStack {
//                    Spacer()
//                    Text("Sharing")
//                        .font(Font.custom("Crimson Pro", size: 24).weight(.bold))
//                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
//                    Spacer()
//                }
//                
//                Color.clear.frame(width: 44, height: 44)
//            }
//            
//            Text("I want to share")
//                .font(.title)
//                .fontWeight(.bold)
//            
//            ForEach(options, id: \.self) { option in
//                SharingOptionButton(
//                    option: option,
//                    isSelected: selectedOption == option
//                ) {
//                    if selectedOption == option {
//                        selectedOption = nil
//                    } else {
//                        selectedOption = option
//                    }
//                }
//            }
//            
//            Button(action: sendInvitation) {  // Moved inside body
//                HStack {
//                    Text("Send Invitation")
//                        .fontWeight(.semibold)
//                    Image(systemName: "arrow.right")
//                }
//                .foregroundColor(.white)
//                .frame(maxWidth: .infinity)
//                .frame(height: 56)
//                .background(Color(red: 0.14, green: 0.18, blue: 0.29))
//                .cornerRadius(12)
//            }
//            
//            Spacer()
//        }
//        .padding(.horizontal, 24)
//        .background(.white)
//        .navigationBarBackButtonHidden(true)
//        .sheet(isPresented: $showInviteSent) {
//            InviteSentView()
//        }
//    }
//    
//    func sendInvitation() {  // Moved outside body
//        guard let currentUserID = Auth.auth().currentUser?.uid,
//        let sharingOption = selectedOption else { return }
//        
//        ConnectionManager.sendConnectionRequest(
//            toEmail: email,
//            fromUID: currentUserID,
//            relationship: relationship,
//            sharingOption: sharingOption
//        ) { result in
//            switch result {
//            case .success:
//                showInviteSent = true
//            case .failure(let error):
//                print("Error sending invitation: \(error.localizedDescription)")
//            }
//        }
//    }
//}
struct RelationshipButton: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Text(title)
                    .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                Spacer()
                Image(systemName: isSelected ? "checkmark.square.fill" : "square")
                    .tint(.accentColor)
                    .frame(width: 20, height: 20)

                
            }
            .padding()
            .background(Color.white)
            .cornerRadius(12)
            .shadow(color: .black.opacity(0.05), radius: 8, y: 4)
        }
    }
}

struct SharingOptionButton: View {
    let option: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Text(option)
                    .font(
                    Font.custom("Source Sans Pro", size: 16)
                    .weight(.semibold)
                    )
                    .foregroundColor(isSelected ? .white : Color(red: 0.14, green: 0.18, blue: 0.29))
                Spacer()
                Image(isSelected ? "chosen-box" : "check-box-icon")
                    .resizable()
                    .frame(width: 20, height: 20)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(isSelected ? Color.blue : .white)
            .cornerRadius(12)
            .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(Color.gray.opacity(0.2), lineWidth: 1))
        }
    }
}

struct InviteSentView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var shareWithfamily: Bool

    var body: some View {
        VStack(spacing: 24) {
            Text("Đã gửi lời mời")
                .font(Font.custom("Crimson Pro", size: 32).weight(.bold))
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
            
            Text("Hãy nhờ người thân của bạn kiểm tra trung tâm thông báo hoặc trang kết nối để chấp nhận lời mời của bạn.")
                .font(Font.custom("Source Sans Pro", size: 16))
                .multilineTextAlignment(.center)
                .foregroundColor(Color(red: 0.36, green: 0.41, blue: 0.52))
            
            Spacer()
            
            Button(action: { shareWithfamily = false }) {
                Text("Quay lại")
                    .font(Font.custom("Source Sans Pro", size: 16).weight(.bold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 56)
                    .background(Color(red: 0.14, green: 0.18, blue: 0.29))
                    .cornerRadius(12)
            }
        }
        .padding(24)
        .background(.white)
        .navigationBarBackButtonHidden(true)
    }
}



struct ConnectionView_Previews: PreviewProvider {
    static var previews: some View {
        ConnectionView()
            .environmentObject(FirestoreManager())
    }
}
