//
//  KobiScoreCardView.swift
//  Cura
//
//  Created by Vivek Padaya on 19/02/25.
//

import SwiftUI

struct KobiScoreCardView: View {
    var kobiScore: Int {
        AppManager.shared.currentUser?.kobiScore ?? 0
    }
    var onClickHome: () -> Void

    @State var riskColor = Color.accentColor
    @State var riskText = "Low"
    
    var body: some View {
        VStack {
            
            Image(reactionIcon)
                .resizable()
                .frame(width: 120, height: 80)
                .foregroundStyle(backgroundColor)

            Spacer()
                .frame(height: 20)
            
            Text(getScoreDescription())
                .font(Font.custom("Source Sans Pro", size: 16))
                .multilineTextAlignment(.leading)
                .foregroundColor(Color(red: 0.36, green: 0.41, blue: 0.52))
                .frame(maxWidth: .infinity, alignment: .leading) // Allow full width


            Button(action: onClickHome) {
                
                HStack{
                    Text("Home")
                        .font(Font.custom("Source Sans Pro", size: 16).weight(.bold))
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .background(backgroundColor)
                        .cornerRadius(12)
                    
                  
                }
                
            }

            
        }
        .padding()
        .background(Color.white)
        .cornerRadius(12)
        .shadow(radius: 5)
        
    }
    
    var reactionIcon: String {
        let currentScore = kobiScore
        switch currentScore {
        case ..<25:
            return "message-happy-icon"
        case 25...75:
            return "message-mid-icon"
        default:
            return "message-sad-icon"
        }
    }
    
    var backgroundColor: Color {
        let currentScore = kobiScore
        switch currentScore {
        case ..<25:
            return Color(red: 0.25, green: 0.45, blue: 0.25)
        case 25...75:
            return Color(red: 0.9, green: 0.7, blue: 0.37)
        default:
            return Color(red: 0.47, green: 0, blue: 0)
        }
    }
    
//    var riskDescription: String {
//        let currentScore = kobiScore
//        switch currentScore {
//        case ..<40:
//            return "Over 30% of cancers can be prevented with healthy habits like eating veggies and staying active. Keep it up!"
//        case 40..<70:
//            return "Your risk is moderate. Keep an eye on your health and track any changes. Staying proactive is key!"
//        default:
//            return "Your risk is high. Schedule a cancer screening soon-early detection can save lives!"
//        }
//    }
//    
    
    func getScoreDescription() -> String {
        print("\n=== KobiScoreCard Debug ===")
        print("Current Score:", kobiScore)
        
        let highRiskMessages = [
            "Thời gian rất quan trọng. Đừng trì hoãn việc tầm soát ung thư thêm một ngày nào nữa.",
            "Nguy cơ của bạn là có thật. Hành động ngay để bảo vệ sức khỏe với việc tầm soát kịp thời.",
            "Mỗi khoảnh khắc đều quý giá. Tầm soát hôm nay có thể cứu sống bạn vào ngày mai.",
            "Đừng đánh cược với sức khỏe của bạn. Nguy cơ cao cần hành động ngay lập tức.",
            "Chờ đợi không phải là lựa chọn. Hãy đặt lịch tầm soát ung thư ngay bây giờ.",
            "Hãy đối mặt với nguy cơ của bạn. Tầm soát là biện pháp bảo vệ tốt nhất.",
            "Sức khỏe của bạn không thể chờ đợi. Hãy ưu tiên tầm soát để luôn chủ động trước các nguy cơ.",
            "Hãy tầm soát trước khi quá muộn. Đặt lịch tầm soát sớm là rất quan trọng.",
            "Nguy cơ cao đòi hỏi sự cảnh giác cao. Hãy đặt lịch tầm soát để an tâm hơn.",
            "Đừng để ung thư đánh úp bạn. Tầm soát kịp thời là lựa chọn an toàn nhất."
        ]
        
        let midRiskMessages = [
            "Đừng phó mặc sức khỏe của bạn cho may rủi. Hãy đặt lịch tầm soát ung thư ngay hôm nay.",
            "Phát hiện sớm là biện pháp bảo vệ tốt nhất. Đặt lịch tầm soát ngay bây giờ.",
            "Dành 30 phút cho một buổi tầm soát, nhận lại nhiều năm an tâm.",
            "Phiên bản tương lai của bạn sẽ biết ơn vì bạn đã đặt lịch tầm soát ung thư.",
            "Phát hiện sớm, điều trị dễ thành công. Hãy ưu tiên tầm soát sức khỏe.",
            "Hãy chủ động thay vì bị động. Tầm soát định kỳ giúp bạn luôn đi trước một bước.",
            "Kiến thức là sức mạnh. Hãy kiểm soát sức khỏe của bạn ngay hôm nay.",
            "Tầm soát: tuyến phòng thủ đầu tiên chống lại ung thư. Đừng bỏ qua bước quan trọng này.",
            "Phát hiện sớm những rủi ro tiềm ẩn. Tầm soát định kỳ giúp bạn hiểu rõ sức khỏe của mình.",
            "Sức khỏe của bạn xứng đáng được quan tâm. Hãy ưu tiên tầm soát và ưu tiên chính mình."
        ]
        
        let lowRiskMessages = [
            "Bạn đang đi đúng hướng: Hãy tiếp tục duy trì những thói quen lành mạnh của bạn!",
            "Làm tốt lắm: Lối sống của bạn đang giúp bạn đi đúng hướng. Hãy tiếp tục phát huy!",
            "Tin tuyệt vời: Những thói quen sức khỏe của bạn đang mang lại kết quả. Hãy tiếp tục duy trì nhé!",
            "Cứ tiếp tục nhé! Lối sống lành mạnh của bạn đang mang lại hiệu quả tuyệt vời. Hãy tiếp tục chăm sóc sức khỏe của mình.",
            "Bạn đang làm rất tốt: Duy trì những thói quen lành mạnh này sẽ tiếp tục mang lại lợi ích lâu dài cho sức khỏe của bạn.",
            "Tuyệt vời! Những lựa chọn lối sống của bạn đang giúp bạn duy trì sức khỏe tốt. Hãy tiếp tục cố gắng!",
            "Xuất sắc! Bạn đang đi đúng hướng. Hãy tiếp tục duy trì thói quen lành mạnh để bảo vệ sức khỏe của mình.",
            "Bạn đang ở trạng thái tốt: Những lựa chọn lành mạnh của bạn đang mang lại kết quả. Hãy duy trì điều đó!",
            "Tiến bộ đáng kinh ngạc! Hãy tiếp tục chú trọng đến sức khỏe của bạn, và bạn sẽ tiếp tục gặt hái những lợi ích.",
            "Cứ tiếp tục nhé: Những thói quen lành mạnh của bạn đang phát huy hiệu quả. Hãy kiên trì và tiếp tục cố gắng!"
        ]
        
        let message: String
        switch kobiScore {
        case 76...100:
            message = highRiskMessages.randomElement() ?? "Thời gian rất quan trọng..."
            print("Category: High Risk")
        case 25...75:
            message = midRiskMessages.randomElement() ?? "Đừng phó mặc sức khỏe..."
            print("Category: Medium Risk")
        case ..<25:
            message = lowRiskMessages.randomElement() ?? "Bạn đang đi đúng hướng..."
            print("Category: Low Risk")
        default:
            message = lowRiskMessages.randomElement() ?? "Bạn đang đi đúng hướng..."
            print("Category: Default (Low Risk)")
        }
        
        print("Selected Message:", message)
        print("=========================\n")
        return message
    }

    
}
