//
//  UserProfileView.swift
//  Cura
//
//  Created by Vivek Padaya on 11/02/25.
//

import SwiftUI
import FirebaseFirestore

struct UserProfileView: View {
    let user: UserProfile
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 32) {
                // Close Button
                HStack {
                    Spacer()
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title)
                            .foregroundColor(.gray)
                    }
                }
                
                // Title
                Text("Hồ sơ cá nhân")
                    .font(
                        Font.custom("Crimson Pro", size: 32)
                            .weight(.bold)
                    )
                    .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                
                // User Info
                VStack(alignment: .leading, spacing: 20) {
                    profileField(title: "Họ và tên", value: user.name ?? "N/A", icon: "person")
                    profileField(title: "Email", value: user.email ?? "N/A", icon: "envelope")
                    profileField(title: "Số điện thoại", value: user.phone ?? "N/A", icon: "phone")
                    profileField(title: "Ngày sinh", value: user.dateOfBirth ?? "N/A", icon: "calendar")
                    profileField(title: "Giới tính", value: user.sex ?? "N/A", icon: "person.fill")
                    profileField(title: "Chiều cao", value: user.height != nil ? "\(user.height!) cm" : "N/A", icon: "ruler")
                    profileField(title: "Cân nặng", value: user.weight != nil ? "\(user.weight!) kg" : "N/A", icon: "scalemass")
                    profileField(title: "Điểm rủi ro", value: user.riskStatus ?? "N/A", icon: "exclamationmark.triangle")
                    profileField(title: "Đã từng bị ung thư?", value: user.cancerBefore == true ? "Yes" : "No", icon: "cross.fill")
                }
            }
            .padding()
            .padding([.horizontal], 23.5)
        }
    }
    
    private func profileField(title: String, value: String, icon: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(Font.custom("Source Sans Pro", size: 16).weight(.bold))
            HStack {
                Image(systemName: icon)
                    .foregroundColor(.gray)
                Text(value)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(10)
            .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 4)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color(red: 0.51, green: 0.55, blue: 0.63), lineWidth: 0.2)
            )
        }
    }
}

struct UserProfileView_Previews: PreviewProvider {
    static var previews: some View {
        let sampleUser = UserProfile(from: [
            "userId": "12345",
            "name": "John Doe",
            "email": "johndoe@example.com",
            "phone": "123-456-7890",
            "dateOfBirth": "1990-01-01",
            "sex": "Male",
            "height": 180,
            "weight": 75,
            "riskStatus": "Low",
            "cancerBefore": false
        ])!
        
        UserProfileView(user: sampleUser)
    }
}
