//
//  ReportView.swift
//  Cura
//
//  Created by Viet Tran on 1/12/24.
//
import SwiftUI

struct ReportView: View {
    @State private var selectedMonth = "November"
    @State private var currentDate = Date()
    @State private var selectedDate = Date()

    // Mock data for assessments (replace with actual data)
    @State var submittedDates: Set<String> = []
    @State var missedDates: Set<String> = []
    
    @State var allAssessments = [Assessment]()
    
    
    var body: some View {
        VStack(alignment: .leading, spacing: 24) {
            // Header
            Text("Cập nhật sức khoẻ")
                .font(
                Font.custom("Crimson Pro", size: 30)
                .weight(.bold)
                )
                .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                .padding([.top])


            
            
            
            // Month selector
            headerView
           
            // Calendar grid
            // (You'll need to implement a custom calendar view here)
            
            dayLabelsView
            calendarGridView
            
            
            // Legend
            HStack(spacing: 16) {
                HStack(spacing: 8) {
                    Rectangle()
                        .fill(Color(red: 0.03, green: 0.23, blue: 0).opacity(0.5))
                        .frame(width: 16, height: 16)
                    Text("Đã hoàn thành")
                        .font(Font.custom("Source Sans Pro", size: 14))
                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                }
                
                HStack(spacing: 8) {
                    Rectangle()
                        .fill(Color(red: 0.86, green: 0, blue: 0).opacity(0.6))
                        .frame(width: 16, height: 16)
                    Text("Đã bỏ qua")
                        .font(Font.custom("Source Sans Pro", size: 14))
                        .foregroundColor(Color(red: 0.14, green: 0.18, blue: 0.29))
                }
            }

            ScrollView {
                
                
                // Today's Report
                VStack(alignment: .leading, spacing: 16) {
//                    if let dateSelected = selectedDate {
                        Text("\(translateDate(selectedDate)) - Cập nhật sức khoẻ")
                            .font(.title3)
                            .fontWeight(.bold)
//                    }else{
//                        Text("Report")
//                            .font(.title3)
//                            .fontWeight(.bold)
//                    }
                   
//                    if let selectedDate = selectedDate?.toString() {
//                        let filteredAssessments = allAssessments.filter { $0.date == selectedDate }
//                        
//                        if !filteredAssessments.isEmpty, let assessment = filteredAssessments.first {
//                            // Do something with the filtered data
//                            
//                            VStack(alignment: .leading, spacing: 16) {
//                                Text("Kobi score :\(String(assessment.kobiScore ?? 0))")
//                                    .font(.headline)
//                                
//                                VStack(alignment: .leading, spacing: 12) {
//                                    VStack(alignment: .leading, spacing: 4) {
//                                        Text("Sleep time")
//                                            .fontWeight(.semibold)
//                                        Text("\(String(assessment.sleepTime)) hrs")
//                                            .foregroundColor(.gray)
//                                    }
//                                    
//                                    VStack(alignment: .leading, spacing: 4) {
//                                        Text("Headache")
//                                            .fontWeight(.semibold)
//                                        Text("Temple Region")
//                                            .foregroundColor(.gray)
//                                    }
//                                    
//                                   
//                                }
//                            }
//                            .padding(16)
//                            .background(Color(red: 0.95, green: 0.96, blue: 0.98))
//                            .cornerRadius(12)
//                        }
//                    }
                    
//                    if let selectedDateStr = selectedDate.toString(){
                        let filteredAssessments = allAssessments.filter { $0.date.contains(selectedDate.toString()) }
                        if !filteredAssessments.isEmpty, let assessment = filteredAssessments.first {
                            
                            HStack{
                                VStack(alignment: .leading, spacing: 16) {
                                    Text("Điểm rủi ro: \(String(assessment.kobiScore ?? 0))")
                                                        .font(.headline)
                                    
                                    VStack(alignment: .leading, spacing: 12) {
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text("Thời gian ngủ")
                                                .fontWeight(.semibold)
                                            Text("\(String(assessment.sleepTime ?? 0)) tiếng")
                                                .foregroundColor(.gray)
                                        }
                                        
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text("Thời gian dành cho hàng xóm")
                                                .fontWeight(.semibold)
                                            Text("\(String(assessment.familyTime ?? 0)) tiếng")
                                                .foregroundColor(.gray)
                                        }
                                        
                                        
                                    }
                                }
                                Spacer()
                            }
                            .padding(16)
                            .background(Color(red: 0.95, green: 0.96, blue: 0.98))
                            .cornerRadius(12)
                            
                        }else{
                            Text("Chưa có dữ liệu.")
                        }

                        
//                    }
                    
                   
                }
            }
            
//            if let date = selectedDate, date.isBetween(startDate: Date.startOfWeek(), endDate: Date.endOfWeek()){
//                
//                if !self.submittedDates.contains(date.toString()){
//                    Button(action: {}) {
//                        Text("Do daily assessment")
//                            .fontWeight(.semibold)
//                            .foregroundColor(.white)
//                            .frame(maxWidth: .infinity)
//                            .frame(height: 56)
//                            .background(Color(red: 0.14, green: 0.18, blue: 0.29))
//                            .cornerRadius(12)
//                    }
//                }
//            }
           
        }
        .padding(.horizontal, 24)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .background(.white)
        .onAppear {
            self.loadData()
        }.onReceive(NotificationCenter.default.publisher(for: .newDataAdded)) { (output) in
            self.loadData()
        }
        
    }
    
    private func loadData() {
        guard let user = AppManager.shared.currentUser else { return }
        
        FirestoreManagerAdvance.shared.fetchAssessmentsFor3Month(for: user.userId, date: Date()) { assessments in
            
            self.allAssessments = assessments
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy"
            
            // Extract the dates from the Assessment objects
            let submittedDatesAll = Set(assessments.compactMap { ($0.date.getDateFromString())?.toString() })
            let lastDate = Date()
            guard let firstDateStr = submittedDatesAll.min(),
                  let lastDateStr = submittedDatesAll.max(),
                  let firstDate = dateFormatter.date(from: firstDateStr) else {
                print("No assessments submitted.")
                return
            }
            
            let allPossibleDates = Date.datesBetween(startDate: firstDate, endDate: lastDate)
                .map { $0 } // Convert Date objects to String
            
            let missedDatesAll = Set(allPossibleDates).subtracting(submittedDatesAll)
            
            print("✅ Submitted Dates:", submittedDatesAll)
            print("🚨 Missed Dates:", missedDatesAll)
            
            DispatchQueue.main.async {
                self.submittedDates = submittedDatesAll
                self.missedDates = missedDatesAll
                
            }
        }
    }
    

    private func translateMonthYear(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MM yyyy"
        let monthYear = formatter.string(from: date)
        let components = monthYear.components(separatedBy: " ")
        
        if components.count == 2 {
            let month = Int(components[0]) ?? 1
            let year = components[1]
            
            let vietnameseMonth = switch month {
                case 1: "Tháng 1"
                case 2: "Tháng 2"
                case 3: "Tháng 3"
                case 4: "Tháng 4"
                case 5: "Tháng 5"
                case 6: "Tháng 6"
                case 7: "Tháng 7"
                case 8: "Tháng 8"
                case 9: "Tháng 9"
                case 10: "Tháng 10"
                case 11: "Tháng 11"
                case 12: "Tháng 12"
                default: "Tháng 1"
            }
            
            return "\(vietnameseMonth) \(year)"
        }
        
        return monthYear
    }

    private var headerView: some View {
        HStack {
            Button(action: previousMonth) {
                Image(systemName: "chevron.left")
                    .font(.title2)
                    .padding()
            }
            .disabled(isAtLimit(previous: true))

            Spacer()

            Text(translateMonthYear(currentDate))
                .font(.title2)
                .bold()

            Spacer()

            Button(action: nextMonth) {
                Image(systemName: "chevron.right")
                    .font(.title2)
                    .padding()
            }
            .disabled(isAtLimit(previous: false))
        }
    }
    
    
    private var dayLabelsView: some View {
        let weekdays = ["CN", "T2", "T3", "T4", "T5", "T6", "T7"]
        
        return HStack {
            ForEach(weekdays, id: \.self) { day in
                Text(day)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
            }
        }
    }


    
    private var calendarGridView: some View {
        let days = currentDate.generateDaysInMonth()
        
        return LazyVGrid(columns: Array(repeating: GridItem(), count: 7)) {
            ForEach(Array(days.enumerated()), id: \.offset) { index, day in
                if let date = day {
                    let dateString = date.toString()
                    let isSubmitted = submittedDates.contains(dateString)
                    let isMissed = missedDates.contains(dateString)
                    let isToday = Calendar.current.isDate(date, inSameDayAs: Date())
                    let isSelected = Calendar.current.isDate(date, inSameDayAs: selectedDate)
                    let isFutureDate = date > Date()
                    
                    ZStack {
                        Rectangle()
                            .fill(
                                isSubmitted ? Color(red: 0.03, green: 0.23, blue: 0).opacity(0.5) :
                                isMissed ? Color(red: 0.86, green: 0, blue: 0).opacity(0.6) :
                                isToday ? Color.gray.opacity(0.3) :
                                isSelected ? Color.blue.opacity(0.7) : Color.clear
                            )
                            .frame(width: 30, height: 30)
                            .cornerRadius(5)
                            .opacity(isFutureDate ? 0.3 : 1.0)
                        
                        if isSelected && (isSubmitted || isMissed || isToday) {
                            RoundedRectangle(cornerRadius: 5)
                                .stroke(Color.blue, lineWidth: 2)
                                .frame(width: 32, height: 32)
                        }
                        
                        Text("\(date.getDay())")
                            .frame(width: 30, height: 30)
                            .foregroundColor(isFutureDate ? .gray : (isSubmitted || isMissed || isSelected ? .white : .black))
                    }
                    .onTapGesture {
                        if !isFutureDate {
                            selectedDate = date
                        }
                    }
                } else {
                    Color.clear
                        .frame(width: 30, height: 30)
                        .id(UUID()) // Give empty spaces unique IDs
                }
            }
        }
    }


    private func bottomBanner(date: Date) -> some View {
        Text("Selected Date: \(date.toString())")
            .font(.headline)
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.blue.opacity(0.8))
            .foregroundColor(.white)
            .cornerRadius(10)
            .padding(.top, 10)
    }
    
    private func previousMonth() {
        currentDate = Calendar.current.date(byAdding: .month, value: -1, to: currentDate) ?? currentDate
    }
    
    private func nextMonth() {
        currentDate = Calendar.current.date(byAdding: .month, value: 1, to: currentDate) ?? currentDate
    }
    
    // Change value to set previous months limit
    private func isAtLimit(previous: Bool) -> Bool {
        let sixMonthsAgo = Calendar.current.date(byAdding: .month, value: -2, to: Date())!
        return previous ? currentDate <= sixMonthsAgo : currentDate.isSameMonth(as: Date())
    }

    // Add this helper function to translate date
    private func translateDate(_ date: Date) -> String {
        if Calendar.current.isDate(date, inSameDayAs: Date()) {
            return "Hôm nay"
        } else {
            let day = Calendar.current.component(.day, from: date)
            let month = Calendar.current.component(.month, from: date)
            
            let vietnameseMonth = switch month {
                case 1: "tháng 1"
                case 2: "tháng 2"
                case 3: "tháng 3"
                case 4: "tháng 4"
                case 5: "tháng 5"
                case 6: "tháng 6"
                case 7: "tháng 7"
                case 8: "tháng 8"
                case 9: "tháng 9"
                case 10: "tháng 10"
                case 11: "tháng 11"
                case 12: "tháng 12"
                default: "tháng 1"
            }
            
            return "\(day) \(vietnameseMonth)"
        }
    }
}

struct ReportView_Previews: PreviewProvider {
    static var previews: some View {
        ReportView()
    }
}
