//  CuraApp.swift
//  Cura
//
//  Created by Nika Kiladze on 10/12/24.
//
import Foundation
import SwiftUI
import Firebase
import FirebaseCore
import FirebaseAuth
import FirebaseFirestore
import Messages
import FirebaseMessaging


@main
struct CuraApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    
    // Main app state managers
    @StateObject private var authManager = AuthManager()
    @StateObject private var firestoreManager = FirestoreManager()
    @State private var showQuestionnaire = false
    @StateObject private var appManager = AppManager.shared

    var body: some Scene {
        WindowGroup {
            Group {
                if appManager.currentUser != nil {
                    HomePage()
                        .environmentObject(authManager)
                        .environmentObject(firestoreManager)

                } else {
                    Begin()
                        .environmentObject(authManager)
                }
            }
            .onAppear {
                NotificationManager.shared.requestAuthorization()
            
            }
            .onReceive(NotificationCenter.default.publisher(for: .showQuestionnaire)) { _ in
                showQuestionnaire = true
            }
        }
    }
    
}

/// Handles app initialization and notifications
class AppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate, MessagingDelegate {
    func application(_ application: UIApplication,
                    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        FirebaseApp.configure()
        
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { (granted, error) in
            if granted {
                DispatchQueue.main.async {
                    UIApplication.shared.registerForRemoteNotifications()
                }
            } else {
                print("Permission for push notifications denied.")
            }
        }
        
        UNUserNotificationCenter.current().delegate = self
        Messaging.messaging().delegate = self
        

        return true
    }
    
    // Handle foreground notifications
    func userNotificationCenter(_ center: UNUserNotificationCenter, 
                              willPresent notification: UNNotification, 
                              withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound, .badge])
    }
    
    // Handle notification taps
//    func userNotificationCenter(_ center: UNUserNotificationCenter,
//                              didReceive response: UNNotificationResponse,
//                              withCompletionHandler completionHandler: @escaping () -> Void) {
//        if response.notification.request.content.userInfo["destination"] as? String == "questionnaire" {
//            NotificationCenter.default.post(name: .showQuestionnaire, object: nil)
//        }
//        completionHandler()
//    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler: @escaping () -> Void) {
        let userInfo = response.notification.request.content.userInfo
        if let pushType = userInfo["pushType"] as? String {
            DispatchQueue.main.async {
                NotificationCenter.default.post(name: .pushReceived, object: nil, userInfo: ["pushType": pushType])
            }
        }
        completionHandler()
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        Messaging.messaging().apnsToken = deviceToken
    }
    
    
    func messaging(_ messaging: Messaging, didReceiveRegistrationToken fcmToken: String?) {
        if let fcm = Messaging.messaging().fcmToken {
            print("fcm", fcm)
            guard var user = AppManager.shared.currentUser else {
                return
            }
            user.deviceToken = fcm
            FirestoreManagerAdvance.shared.updateUserProfile(user: user) { isSuccess in
                if isSuccess{
                    print("FCM Token Updated")
                }
            }
        }
    }
}

// Custom notification names
extension Notification.Name {
    static let showQuestionnaire = Notification.Name("showQuestionnaire")
}

// Example blank view to show when a user is authenticated
struct BlankView: View {
    var body: some View {
        VStack {
            Text("You are authenticated!")
                .font(.largeTitle)
                .padding()
            // Add additional authenticated user interface elements here
        }
    }
}
