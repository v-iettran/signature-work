//
//  String+Extensions.swift
//  Cura
//
//  Created by Vivek Padaya on 13/02/25.
//

import UIKit

class String_Extensions: NSObject {

}


extension Array where Element == Double {
    func average() -> Double {
        return self.isEmpty ? 0.0 : self.reduce(0, +) / Double(self.count)
    }
}

extension Array where Element == Int {
    func average() -> Double {
        return self.isEmpty ? 0.0 : Double(self.reduce(0, +)) / Double(self.count)
    }
}

extension Array where Element == String {
    func averageAsDouble() -> Double {
        let validNumbers = self.compactMap { Double($0) }
        return validNumbers.isEmpty ? 0.0 : validNumbers.reduce(0, +) / Double(validNumbers.count)
    }
}

extension String {
    func toDouble() -> Double? {
        return NumberFormatter().number(from: self)?.doubleValue
    }
}
