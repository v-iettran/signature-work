//
//  Date+Extension.swift
//  Cura
//
//  Created by Vivek Padaya on 11/02/25.
//

import UIKit

class Date_Extension: NSObject {

}

let generalStrFormate = "dd-MM-yyyy"

extension Date{
    
    func saveDateTimeFormate() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy HH:mm"
        return formatter.string(from: self)
    }
    
    func displayDateTimeFormate() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd MMM yyyy HH:mm"
        return formatter.string(from: self)
    }
    
    func displayDateFormate() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd MMM yyyy"
        return formatter.string(from: self)
    }
    
    func age() -> Int {
        let calendar = Calendar.current
        let ageComponents = calendar.dateComponents([.year], from: self, to: Date())
        return ageComponents.year ?? 0
    }
}

extension String {
    func getDateFromString() -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm"
        return dateFormatter.date(from: self)
    }
}


extension Date {
    static func startOfWeek() -> Date {
        let calendar = Calendar.current
        let now = Date()
        
        // Find the weekday component (1 = Sunday, 2 = Monday, etc.)
        let weekDay = calendar.component(.weekday, from: now)
        
        // Calculate how many days to subtract to reach Monday (assuming Monday is the start)
//        let daysToSubtract = (weekDay == 1 ? 6 : weekDay - 1)
        let daysToSubtract = weekDay - 1  // Since Sunday is 1

        // Get the start of the week date
        let startOfWeek = calendar.date(byAdding: .day, value: -daysToSubtract, to: now) ?? now
        
        // Normalize time to 00:00:00
        return calendar.startOfDay(for: startOfWeek)
    }

    static func endOfWeek() -> Date {
        let calendar = Calendar.current
        let startOfWeek = startOfWeek()
        return calendar.date(byAdding: .day, value: 6, to: startOfWeek) ?? startOfWeek
    }
    
    static func lastWeekRange() -> (Date, Date) {
        let startOfLastWeek = Calendar.current.date(byAdding: .weekOfYear, value: -1, to: startOfWeek()) ?? Date()
        let endOfLastWeek = Calendar.current.date(byAdding: .weekOfYear, value: -1, to: endOfWeek()) ?? Date()
        return (startOfLastWeek, endOfLastWeek)
    }
    
    static func monthRange(for date: Date) -> (Date, Date) {
        let calendar = Calendar.current
        let startOfMonth = calendar.date(from: calendar.dateComponents([.year, .month], from: date)) ?? date
        let endOfMonth = calendar.date(byAdding: DateComponents(month: 1, day: -1), to: startOfMonth) ?? startOfMonth
        return (startOfMonth, endOfMonth)
    }
    
    static func previousThreeMonthRange(from date: Date) -> (Date, Date) {
        let calendar = Calendar.current

        // Move back 3 months to get the start of that month
        let startOfPreviousThirdMonth = calendar.date(byAdding: DateComponents(month: -3), to: date) ?? date
        let startOfMonth = calendar.date(from: calendar.dateComponents([.year, .month], from: startOfPreviousThirdMonth)) ?? startOfPreviousThirdMonth

        // Get the last day of the current month (after moving back 3 months)
        let endOfMonth = calendar.date(byAdding: DateComponents(month: 3, day: -1), to: startOfMonth) ?? startOfMonth

        return (startOfMonth, endOfMonth)
    }
    
    static func datesBetween(startDate: Date, endDate: Date) -> [String] {
        var dates: [String] = []
        var currentDate = startDate
        let calendar = Calendar.current
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        
        while currentDate <= endDate {
            dates.append(dateFormatter.string(from: currentDate))
            currentDate = calendar.date(byAdding: .day, value: 1, to: currentDate)!
        }
        
        return dates
    }

        
}

extension Date {
    func isBetween(startDate: Date, endDate: Date) -> Bool {
        return (startDate...endDate).contains(self)
    }
}



extension Date {
    func toMonthYearString() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        return formatter.string(from: self)
    }
    
    func toString() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        return formatter.string(from: self)
    }
    
    func getDay() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "d"
        return formatter.string(from: self)
    }

    func isSameMonth(as date: Date) -> Bool {
        let calendar = Calendar.current
        return calendar.component(.year, from: self) == calendar.component(.year, from: date) &&
               calendar.component(.month, from: self) == calendar.component(.month, from: date)
    }

    func generateDaysInMonth() -> [Date?] {
        let calendar = Calendar.current
        guard let monthRange = calendar.range(of: .day, in: .month, for: self) else { return [] }
        
        let firstDay = calendar.date(from: calendar.dateComponents([.year, .month], from: self))!
        let weekday = calendar.component(.weekday, from: firstDay) - 1
        
        var days: [Date?] = Array(repeating: nil, count: weekday)
        for day in monthRange {
            days.append(calendar.date(byAdding: .day, value: day - 1, to: firstDay))
        }
        
        return days
    }
}
