//
//  Fonts+Extensions.swift
//  Cura
//
//  Created by Vivek Padaya on 15/02/25.
//

import UIKit
import SwiftUI

class Fonts_Extensions: NSObject {

}

extension Font {
    static func headline(_ size: CGFloat) -> Font { .custom("Lora-Bold", size: size) }
    static func bold(_ size: CGFloat) -> Font { .custom("Inter-Bold", size: size) }
    static func semiBold(_ size: CGFloat) -> Font { .custom("Inter-SemiBold", size: size) }
    static func regular(_ size: CGFloat) -> Font { .custom("Inter-Regular", size: size) }
    static func thin(_ size: CGFloat) -> Font { .custom("Inter-Thin", size: size) }
}
