//
//  FirestoreManagerAdvance.swift
//  Cura
//
//  Created by Vivek Padaya on 10/02/25.
//

import UIKit
import FirebaseFirestore
import FirebaseAuth
import SwiftUI


struct UserProfile: Codable {
    let userId: String
    var name: String?
    var cancerBefore: Bool?
    var dateOfBirth: String?
    var email: String?
    var phone: String?
    var height: Double?
    var sex: String?
    var weight: Double?
    var setup: Bool?
    var riskStatus: String?
    var kobiScore: Int?
    var createdAt: String?
    var questionnaireAnswers: [[String: AnyCodable]]?
    var avgSymptomScores: [String: Double]?
    var overallSymptomScore: Double?
    var deviceToken: String?

    enum CodingKeys: String, CodingKey {
        case userId
        case name
        case cancerBefore
        case dateOfBirth
        case email
        case phone
        case height
        case sex
        case weight
        case setup
        case riskStatus
        case kobiScore
        case createdAt
        case questionnaireAnswers
        case avgSymptomScores
        case overallSymptomScore
        case deviceToken
        
    }
    
    
    // Custom initializer to map Firestore dictionary manually
    init?(from dict: [String: Any]) {
        guard let userId = dict["userId"] as? String else { return nil }
        self.userId = userId
        self.name = dict["name"] as? String
        self.cancerBefore = dict["cancerBefore"] as? Bool
        self.dateOfBirth = dict["dateOfBirth"] as? String
        self.email = dict["email"] as? String
        self.phone = dict["phoneNumber"] as? String  // Match with dictionary key
        self.height = dict["height"] as? Double
        self.sex = dict["sex"] as? String
        self.weight = dict["weight"] as? Double
        self.setup = dict["setup"] as? Bool
        self.riskStatus = dict["riskStatus"] as? String
        self.kobiScore = dict["kobiScore"] as? Int
        self.createdAt = dict["createdAt"] as? String
        
        self.questionnaireAnswers = dict["questionnaireAnswers"] as? [[String: AnyCodable]]
        self.avgSymptomScores = dict["avgSymptomScores"] as? [String: Double]
        self.overallSymptomScore = dict["overallSymptomScore"] as? Double
        
        self.deviceToken = dict["deviceToken"] as? String


    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        userId = try container.decode(String.self, forKey: .userId)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        cancerBefore = try container.decodeIfPresent(Bool.self, forKey: .cancerBefore)
        dateOfBirth = try container.decodeIfPresent(String.self, forKey: .dateOfBirth)
        email = try container.decodeIfPresent(String.self, forKey: .email)
        phone = try container.decodeIfPresent(String.self, forKey: .phone)
        height = try container.decodeIfPresent(Double.self, forKey: .height)
        sex = try container.decodeIfPresent(String.self, forKey: .sex)
        weight = try container.decodeIfPresent(Double.self, forKey: .weight)
        setup = try container.decodeIfPresent(Bool.self, forKey: .setup)
        riskStatus = try container.decodeIfPresent(String.self, forKey: .riskStatus)
        kobiScore = try container.decodeIfPresent(Int.self, forKey: .kobiScore)
        createdAt = try container.decodeIfPresent(String.self, forKey: .createdAt)
        
        
        questionnaireAnswers = try container.decodeIfPresent([[String: AnyCodable]].self, forKey: .questionnaireAnswers)
        
        avgSymptomScores = try container.decodeIfPresent([String: Double].self, forKey: .avgSymptomScores)
        overallSymptomScore = try container.decodeIfPresent(Double.self, forKey: .overallSymptomScore)
        
        deviceToken = try container.decodeIfPresent(String.self, forKey: .deviceToken)

    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(userId, forKey: .userId)
        try container.encodeIfPresent(name, forKey: .name)
        try container.encodeIfPresent(cancerBefore, forKey: .cancerBefore)
        try container.encodeIfPresent(dateOfBirth, forKey: .dateOfBirth)
        try container.encodeIfPresent(email, forKey: .email)
        try container.encodeIfPresent(phone, forKey: .phone)
        try container.encodeIfPresent(height, forKey: .height)
        try container.encodeIfPresent(sex, forKey: .sex)
        try container.encodeIfPresent(weight, forKey: .weight)
        try container.encodeIfPresent(setup, forKey: .setup)
        try container.encodeIfPresent(riskStatus, forKey: .riskStatus)
        try container.encodeIfPresent(kobiScore, forKey: .kobiScore)
        try container.encodeIfPresent(createdAt, forKey: .createdAt)
        try container.encodeIfPresent(questionnaireAnswers, forKey: .questionnaireAnswers)
        
        try container.encodeIfPresent(avgSymptomScores, forKey: .avgSymptomScores)
        try container.encodeIfPresent(overallSymptomScore, forKey: .overallSymptomScore)
        
        try container.encodeIfPresent(deviceToken, forKey: .deviceToken)

    }
}

struct AnyCodable: Codable {
    let value: Any
    
    init(_ value: Any) {
        self.value = value
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        
        if let intValue = value as? Int {
            try container.encode(intValue)
        } else if let doubleValue = value as? Double {
            try container.encode(doubleValue)
        } else if let stringValue = value as? String {
            try container.encode(stringValue)
        } else if let boolValue = value as? Bool {
            try container.encode(boolValue)
        } else if let dictValue = value as? [String: Any] {
            try container.encode(dictValue.mapValues { AnyCodable($0) })
        } else {
            throw EncodingError.invalidValue(value, EncodingError.Context(codingPath: encoder.codingPath, debugDescription: "Unsupported type"))
        }
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        
        if let intValue = try? container.decode(Int.self) {
            value = intValue
        } else if let doubleValue = try? container.decode(Double.self) {
            value = doubleValue
        } else if let stringValue = try? container.decode(String.self) {
            value = stringValue
        } else if let boolValue = try? container.decode(Bool.self) {
            value = boolValue
        } else if let dictValue = try? container.decode([String: AnyCodable].self) {
            value = dictValue.mapValues { $0.value }
        } else {
            throw DecodingError.dataCorruptedError(in: container, debugDescription: "Unsupported type")
        }
    }
}


struct Connections: Codable {
    let userId: String
    var relationship: String?
    var name: String
    var email: String

    var riskStatus: String?
    var accepted: Bool?
    var isSent: Bool?
    var requestStatus: String?
    var showScreeingRequested: Bool?
}

struct Assessment: Codable {
    let date: String
    var alcohol: Int?
    var dateTimestamp : Timestamp?
    var exercise: Bool?
    var sleepTime: Double?
    var redMeat: Int?
    var familyTime: Double?
    var riskStatus: String?
    var kobiScore: Int?
}

class FirestoreManagerAdvance {
    static let shared = FirestoreManagerAdvance()
    private let db = Firestore.firestore()
    
    private init() {}
    
    
    func signInWithEmail(withEmail email: String,
                        password: String,
                        completion: @escaping (Error?) -> Void) {
        Auth.auth().signIn(withEmail: email, password: password) { [weak self] _, error in
            if let error = error {
                completion(error)
                return
            }
            completion(nil)
        }
    }
    
    /// Signs out current user
    func signOut(completion: @escaping (Error?) -> Void) {
        do {
            try Auth.auth().signOut()
            completion(nil)
        } catch let error {
            completion(error)
        }
    }
    
    /// Checks if email exists in Firebase Auth
    func checkEmailExists(email: String, completion: @escaping (Bool) -> Void) {
        Auth.auth().signIn(withEmail: email, password: "dummyPassword") { _, error in
            DispatchQueue.main.async {
                if let error = error as NSError? {
                    switch error.code {
                    case AuthErrorCode.userNotFound.rawValue:
                        completion(false) // Email does NOT exist
                    case AuthErrorCode.wrongPassword.rawValue, AuthErrorCode.invalidCredential.rawValue:
                        completion(true)  // Email exists, but wrong password
                    default:
                        completion(false) // Treat other errors as non-existent email
                    }
                } else {
                    completion(true) // Somehow logged in (shouldn't happen with wrong password)
                }
            }
        }
    }

    
    // MARK: - User Profile Methods
    
//    func createUserProfile(user: UserProfile, completion: @escaping (Bool) -> Void) {
//        do {
//            try db.collection("PersonalDetail").document(user.userId).setData(from: user)
//            completion(true)
//        } catch {
//            completion(false)
//        }
//    }
    
    func createAccount(withEmail email: String, password: String, fullName: String, phoneNumber: String, completion: @escaping (Result<Void, Error>) -> Void) {
        Auth.auth().createUser(withEmail: email, password: password) { [weak self] result, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let user = result?.user else {
                completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "User creation failed"])))
                return
            }
            
            
            
            let userData: [String: Any] = [
                "userId": user.uid,
                "name": fullName,
                "email": email.lowercased(),
                "phoneNumber": phoneNumber,
                "cancerBefore": false,
                "setup": false,
                "createdAt": FieldValue.serverTimestamp()
            ]
            
            
            self?.db.collection("PersonalDetail").document(user.uid).setData(userData) { error in
                if let error = error {
                    print("Firestore Error: \(error.localizedDescription)")
                    completion(.failure(error))
                } else {
                    print("User data successfully written to Firestore")
                    AppManager.shared.currentUser = UserProfile(from: userData)
                    completion(.success(()))
                }
            }
            
        }
    }
    
    
    func fetchUserProfile(userId: String, completion: @escaping (UserProfile?) -> Void) {
        db.collection("PersonalDetail").document(userId).getDocument { snapshot, error in
            guard let document = snapshot, document.exists,
                  let data = try? document.data(as: UserProfile.self) else {
                completion(nil)
                return
            }
            completion(data)
        }
    }
    
   
    
    func fetchUserProfileByEmail(email: String, completion: @escaping (UserProfile?) -> Void) {
        db.collection("PersonalDetail")
            .whereField("email", isEqualTo: email)  // Query by email
            .getDocuments { snapshot, error in
                guard let documents = snapshot?.documents, let document = documents.first else {
                    print("Error fetching user profile: \(error?.localizedDescription ?? "No document found")")
                    completion(nil)
                    return
                }
                
                do {
                    let userData = try document.data(as: UserProfile.self)
                    completion(userData)
                } catch {
                    print("Error decoding user profile: \(error.localizedDescription)")
                    completion(nil)
                }
            }
    }
    
    func fetchUserProfileByUsername(username: String, completion: @escaping (UserProfile?) -> Void) {
        let db = Firestore.firestore() // Ensure Firestore instance is initialized

        db.collection("PersonalDetail")
            .whereField("name", isEqualTo: username)  // Query by username
            .getDocuments { snapshot, error in
                guard let documents = snapshot?.documents, let document = documents.first else {
                    print("No user profile found for username: \(username). Error: \(error?.localizedDescription ?? "No document found")")
                    completion(nil)
                    return
                }
                
                do {
                    let userData = try document.data(as: UserProfile.self)
                    completion(userData)
                } catch {
                    print("Error decoding user profile: \(error.localizedDescription)")
                    completion(nil)
                }
            }
    }


    
    func updateUserProfile(user: UserProfile, completion: @escaping (Bool) -> Void) {
        do {
            try db.collection("PersonalDetail").document(user.userId).setData(from: user)
            completion(true)
        } catch {
            completion(false)
        }
    }
    
    
    
    
    func searchUser(query: String, completion: @escaping ([UserProfile]) -> Void) {
        db.collection("PersonalDetail")
            .whereField("name", isEqualTo: query)
            .getDocuments { snapshot, error in
                guard let documents = snapshot?.documents else {
                    completion([])
                    return
                }
                var users = documents.compactMap { try? $0.data(as: UserProfile.self) }
                
                self.db.collection("PersonalDetail")
                    .whereField("email", isEqualTo: query)
                    .getDocuments { emailSnapshot, emailError in
                        guard let emailDocuments = emailSnapshot?.documents else {
                            completion(users)
                            return
                        }
                        let emailUsers = emailDocuments.compactMap { try? $0.data(as: UserProfile.self) }
                        users.append(contentsOf: emailUsers)
                        completion(users)
                    }
            }
    }
    
    // MARK: - Connection Methods
    
    func sendConnectionRequest(from senderId: String, to receiverId: String, connection: Connections, completion: @escaping (Bool) -> Void) {
        let senderRef = db.collection("Connections").document(senderId).collection("List").document(receiverId)
        let receiverRef = db.collection("Connections").document(receiverId).collection("List").document(senderId)

        let senderData: [String: Any] = [
            "userId": receiverId,
            "name": connection.name,
            "email": connection.email,
            "accepted": false,
            "isSent": true,
            "relationship" : connection.relationship ?? "None",
            "requestStatus": "pending"
        ]

        let receiverData: [String: Any] = [
            "userId": senderId,
            "name": connection.name,
            "email": connection.email,
            "accepted": false,
            "isSent": false,
            "relationship" : connection.relationship ?? "None",
            "requestStatus": "pending"
        ]

        
        let batch = db.batch()
        batch.setData(senderData, forDocument: senderRef)
        batch.setData(receiverData, forDocument: receiverRef)

        batch.commit { error in
            completion(error == nil)
        }
    }

    
    func fetchPendingRequests(for userId: String, completion: @escaping ([Connections]) -> Void) {
        db.collection("Connections").document(userId).collection("List")
            .whereField("requestStatus", isEqualTo: "pending")
            .whereField("isSent", isEqualTo: false)
            .getDocuments { snapshot, error in
                guard let documents = snapshot?.documents else {
                    completion([])
                    return
                }
                let connections = documents.compactMap { try? $0.data(as: Connections.self) }
                completion(connections)
            }
    }

    func updateConnectionStatus(for userId: String, connectionId: String, accepted: Bool, completion: @escaping (Bool) -> Void) {
        let userRef = db.collection("Connections").document(userId).collection("List").document(connectionId)
        let connectionRef = db.collection("Connections").document(connectionId).collection("List").document(userId)

        let status = accepted ? "accepted" : "rejected"

        let batch = db.batch()
        batch.updateData(["accepted": accepted, "requestStatus": status], forDocument: userRef)
        batch.updateData(["accepted": accepted, "requestStatus": status], forDocument: connectionRef)

        batch.commit { error in
            completion(error == nil)
        }
    }
    
    func sendScreeingRequest(for userId: String, connectionId: String, completion: @escaping (Bool) -> Void) {
        let connectionRef = db.collection("Connections").document(connectionId).collection("List").document(userId)

        let batch = db.batch()
        batch.updateData(["showScreeingRequested": true], forDocument: connectionRef)
        batch.commit { error in
            completion(error == nil)
        }
    }
    
    func seenScreeingRequest(for userId: String, connectionId: String, completion: @escaping (Bool) -> Void) {
        let userRef = db.collection("Connections").document(userId).collection("List").document(connectionId)

        let batch = db.batch()
        batch.updateData(["showScreeingRequested": false], forDocument: userRef)

        batch.commit { error in
            completion(error == nil)
        }
    }


    func fetchConnections(for userId: String, completion: @escaping ([Connections]) -> Void) {
        db.collection("Connections").document(userId).collection("List").getDocuments { snapshot, error in
            guard let documents = snapshot?.documents else {
                completion([])
                return
            }
            let connections = documents.compactMap { try? $0.data(as: Connections.self) }
            completion(connections)
        }
    }
    
    func checkIfConnectionExists(for userId: String, email: String, name: String, completion: @escaping (Bool) -> Void) {
        db.collection("Connections").document(userId).collection("List")
            .whereField("email", isEqualTo: email)
            .getDocuments { snapshot, error in
                if let documents = snapshot?.documents, !documents.isEmpty {
                    completion(true) // Email already exists
                    return
                }
                
                self.db.collection("Connections").document(userId).collection("List")
                    .whereField("name", isEqualTo: name)
                    .getDocuments { snapshot, error in
                        if let documents = snapshot?.documents, !documents.isEmpty {
                            completion(true) // Name already exists
                        } else {
                            completion(false) // Neither exists
                        }
                    }
            }
    }

    
   
    
    // MARK: - Assessment Methods
    func fetchAssessments(for userId: String, completion: @escaping ([Assessment]) -> Void) {
        db.collection("AssessmentData").document(userId).collection("Dates").getDocuments { snapshot, error in
            guard let documents = snapshot?.documents else {
                completion([])
                return
            }
            let assessments = documents.compactMap { try? $0.data(as: Assessment.self) }
            completion(assessments)
        }
    }
    
    func fetchAssessments(for userId: String, from startDate: Date, to endDate: Date, completion: @escaping ([Assessment]) -> Void) {
        let startTimestamp = Timestamp(date: startDate)
        let endTimestamp = Timestamp(date: endDate)
        
        db.collection("AssessmentData")
            .document(userId)
            .collection("Dates")
            .whereField("dateTimestamp", isGreaterThanOrEqualTo: startTimestamp)
            .whereField("dateTimestamp", isLessThanOrEqualTo: endTimestamp)
            .getDocuments { snapshot, error in
                guard let documents = snapshot?.documents else {
                    completion([])
                    return
                }
                let assessments = documents.compactMap { try? $0.data(as: Assessment.self) }
                completion(assessments)
            }
    }
        
    
    func addAssessment(for userId: String, assessment: Assessment, completion: @escaping (Bool) -> Void) {
        do {
            try db.collection("AssessmentData").document(userId).collection("Dates").document(assessment.date).setData(from: assessment)
            completion(true)
        } catch {
            completion(false)
        }
    }
    
    func updateLastAssessment(for userId: String, newAssessment: Assessment, completion: @escaping (Bool) -> Void) {
        let assessmentsRef = db.collection("AssessmentData").document(userId).collection("Dates")
        
        // Get the latest assessment
        assessmentsRef.order(by: "date", descending: true).limit(to: 1).getDocuments { snapshot, error in
            guard let document = snapshot?.documents.first else {
                completion(false)
                return
            }
            
            let docID = document.documentID // Get last assessment's document ID
            
            do {
                try assessmentsRef.document(docID).setData(from: newAssessment, merge: true) // Update only changed fields
                completion(true)
            } catch {
                completion(false)
            }
        }
    }

    func updateLatestAssessmentRisk(for userId: String, riskStatus: String, kobiScore: Int, completion: @escaping (Bool) -> Void) {
        let assessmentsRef = db.collection("AssessmentData").document(userId).collection("Dates")
        
        // Fetch the latest assessment
        assessmentsRef.order(by: "date", descending: true).limit(to: 1).getDocuments { snapshot, error in
            guard let document = snapshot?.documents.first else {
                completion(false)
                return
            }
            
            let docID = document.documentID // Get last assessment's document ID
            
            // Update only riskStatus and kobiScore
            assessmentsRef.document(docID).updateData([
                "riskStatus": riskStatus,
                "kobiScore": kobiScore
            ]) { error in
                completion(error == nil)
            }
        }
    }

    
    
    func fetchCurrentWeekAssessments(for userId: String, completion: @escaping ([Assessment]) -> Void) {
        let start = Date.startOfWeek()
        let end = Date()
        self.fetchAssessments(for: userId, from: start, to: end, completion: completion)
    }
    
    func fetchLastWeekAssessments(for userId: String, completion: @escaping ([Assessment]) -> Void) {
        let (start, end) = Date.lastWeekRange()
        self.fetchAssessments(for: userId, from: start, to: end, completion: completion)
    }
    
    func fetchAssessmentsForMonth(for userId: String, date: Date, completion: @escaping ([Assessment]) -> Void) {
        let (start, end) = Date.monthRange(for: date)
        self.fetchAssessments(for: userId, from: start, to: end, completion: completion)
    }
    
    func fetchAssessmentsFor3Month(for userId: String, date: Date, completion: @escaping ([Assessment]) -> Void) {
        let (start, end) = Date.monthRange(for: date)
        self.fetchAssessments(for: userId, from: start, to: date, completion: completion)
    }
    
    func fetchAssessmentDatesForThreeMonths(for userId: String, date: Date, completion: @escaping ([String]) -> Void) {
        let (start, end) = Date.previousThreeMonthRange(from: date) // Use provided date

        db.collection("AssessmentData")
            .document(userId)
            .collection("Dates")
            .whereField("dateTimestamp", isGreaterThanOrEqualTo: Timestamp(date: start))
            .whereField("dateTimestamp", isLessThanOrEqualTo: Timestamp(date: date))
            .getDocuments { snapshot, error in
                guard let documents = snapshot?.documents else {
                    completion([])
                    return
                }
                
                // Extract only the "date" field from each document
                let dates = documents.compactMap { $0["date"] as? String }
                completion(dates)
            }
    }

}
