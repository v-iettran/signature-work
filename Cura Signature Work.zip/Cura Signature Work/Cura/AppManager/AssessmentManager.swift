//
//  AssessmentManager.swift
//  Cura
//
//  Created by Vivek Padaya on 13/02/25.
//

import SwiftUI
import CoreML
import Foundation

class AssessmentManager {
    
    private let model: CancerRiskPredictor

    private var means: [Double]?
    private var stds: [Double]?
    
    
    init() throws {
        let config = MLModelConfiguration()
        self.model = try CancerRiskPredictor(configuration: config)
        
        if let scalerURL = Bundle.main.url(forResource: "scaler_params", withExtension: "json"),
           let scalerData = try? Data(contentsOf: scalerURL),
           let params = try? JSONDecoder().decode([String: [Double]].self, from: scalerData) {
            self.means = params["means"]
            self.stds = params["stds"]
            print("Loaded scaler parameters:")
            print("Means:", self.means ?? [])
            print("STDs:", self.stds ?? [])
        } else {
            print("Failed to load scaler parameters")
        }
    }

    
    private func standardize(_ value: Double, featureIndex: Int) -> Double {
        guard let means = means,
              let stds = stds,
              featureIndex < means.count,
              featureIndex < stds.count else {
            return value
        }
        
        return (value - means[featureIndex]) / stds[featureIndex]
    }
    

    func fetchCurrentWeekRiskScore(completion: @escaping (Double, String) -> Void) {
        guard var userProfile = AppManager.shared.currentUser else {
            print("No current user available.")
            completion(0, "No User Data")
            return
        }
        
        FirestoreManagerAdvance.shared.fetchCurrentWeekAssessments(for: userProfile.userId) { assessments in
            // Get current day of week (1 = Sunday, 7 = Saturday)
            let calendar = Calendar.current
            let today = Date()
            var dayOfWeek = calendar.component(.weekday, from: today)
            if dayOfWeek == 1 { dayOfWeek = 7 } else { dayOfWeek -= 1 } // Convert to Monday = 1
            
            // Calculate normalized averages
            let normalizedData = self.calculateNormalizedWeeklyData(
                assessments: assessments,
                dayOfWeek: dayOfWeek
            )
            
            // Run prediction model with normalized data
            self.cancerPrediction(
                avgScore: userProfile.overallSymptomScore,
                redMeatWeekly: normalizedData.redMeat,
                bmi: self.calculateBMI(user: userProfile),
                age: Double(userProfile.dateOfBirth?.getDateFromString()?.age() ?? 0),
                haveCancerBefore: userProfile.cancerBefore == true ? 1.0 : 0.0,
                neighborHours: normalizedData.familyTime,
                gender: userProfile.sex == "Male" ? 1.0 : 0.0
            ) { riskScore, riskStatus in
                // Update user profile and complete
                userProfile.kobiScore = Int(riskScore)
                userProfile.riskStatus = riskStatus
                self.updateUserProfile(userProfile: userProfile) { _ in
                    completion(Double(riskScore), riskStatus)
                }
            }
        }
    }
    
    private func calculateNormalizedWeeklyData(assessments: [Assessment], dayOfWeek: Int) -> (redMeat: Double, familyTime: Double, alcohol: Double, sleep: Double, exercise: Double) {
        // Sum up all values
        let totalRedMeat = assessments.compactMap { Double($0.redMeat ?? 0) }.reduce(0, +)
        let totalFamilyTime = assessments.compactMap { $0.familyTime }.reduce(0, +)
        let totalAlcohol = assessments.compactMap { Double($0.alcohol ?? 0) }.reduce(0, +)
        let totalSleep = assessments.compactMap { $0.sleepTime }.reduce(0, +)
        let totalExercise = assessments.compactMap { $0.exercise == true ? 1.0 : 0.0 }.reduce(0, +)
        
        // Normalize by dividing by current day of week to get daily average
        let divisor = Double(dayOfWeek)
        
        return (
            redMeat: (totalRedMeat / divisor) * 7,      // Estimate weekly value
            familyTime: (totalFamilyTime / divisor) * 7, // Estimate weekly value
            alcohol: (totalAlcohol / divisor) * 7,       // Estimate weekly value
            sleep: totalSleep / divisor,                 // Keep as daily average
            exercise: (totalExercise / divisor) * 7      // Estimate weekly value
        )
    }
    
    func fetchUserFirstScore(completion: @escaping (Double, String) -> Void){
        
        // Get static values from user profile
        guard var userProfile = AppManager.shared.currentUser else {
            print("No current user available.")
            completion(0, "No User Data")
            return
        }
                
        
        let redMeatValues = self.getCategoryData(from: userProfile.questionnaireAnswers ?? [], for: .redmeat)
        let avgRedMeat = redMeatValues.average()
        
        let alcoholValues = self.getCategoryData(from: userProfile.questionnaireAnswers ?? [], for: .drink)
        let avgAlcohol = alcoholValues.average()
        
        let sleepValues = self.getCategoryData(from: userProfile.questionnaireAnswers ?? [], for: .sleep)
        let avgSleepTime = sleepValues.average()
        
        let familyTimeValues = self.getCategoryData(from: userProfile.questionnaireAnswers ?? [], for: .familyTime)
        let avgFamilyTime = familyTimeValues.average()
        
        
        var age = 0.0
        if let userAge = userProfile.dateOfBirth?.getDateFromString()?.age(){
            age = Double(userAge)
        }
        let gender = userProfile.sex == "Male" ? 1.0 : 0.0
        
        var haveCancerBefore: Double = 0
        if let isCancer = userProfile.cancerBefore {
            haveCancerBefore = isCancer ? 1.0 : 0.0
        }
        
        // Run prediction model
        self.cancerPrediction(
            avgScore: userProfile.overallSymptomScore,
            redMeatWeekly: avgRedMeat,
            bmi: self.calculateBMI(user: userProfile),
            age: age,
            haveCancerBefore: haveCancerBefore,
            neighborHours: avgSleepTime,
            gender: gender
        ) { riskScore, riskStatus in
            // Update the latest assessment and user profile
            
            userProfile.kobiScore = Int(riskScore)
            userProfile.riskStatus = riskStatus
            AppManager.shared.currentUser = userProfile
            
            self.updateUserProfile(userProfile: userProfile) { isSuccess in
                print("UserProfile is updated with score: \(riskScore) \(riskStatus)")
                completion(Double(riskScore), riskStatus)
            }
        }
    }
    
    
    func fetchWeekRiskScore(assessments:[Assessment], currentAssessment: Assessment, completion: @escaping (Double, String) -> Void) {
        print("\n=== START OF DAILY ASSESSMENT DEBUG ===")
        
        // Debug current assessment
        print("\nCurrent Assessment Details:")
        print("- Red Meat:", currentAssessment.redMeat ?? 0)
        print("- Family Time:", currentAssessment.familyTime ?? 0)
        print("- Sleep Time:", currentAssessment.sleepTime ?? 0)
        print("- Exercise:", currentAssessment.exercise ?? false)
        
        var newAssessmentData = assessments
        newAssessmentData.append(currentAssessment)
        
        // Declare variables
        var avgAlcohol: Double = 0.0
        var avgSleepTime: Double = 0.0
        var avgRedMeat: Double = 0.0
        var avgFamilyTime: Double = 0.0
        
        print("\nAll Assessments in Week:")
        for (index, assessment) in newAssessmentData.enumerated() {
            print("Assessment \(index + 1):")
            print("- Date:", assessment.date)
            print("- Red Meat:", assessment.redMeat ?? 0)
            print("- Family Time:", assessment.familyTime ?? 0)
            print("- Sleep Time:", assessment.sleepTime ?? 0)
            print("- Exercise:", assessment.exercise ?? false)
        }
        
        if !newAssessmentData.isEmpty {
            // Calculate weekly totals
            let totalRedMeat = newAssessmentData.map { Double($0.redMeat ?? 0) }.reduce(0, +)
            let totalFamilyTime = newAssessmentData.map { $0.familyTime ?? 0 }.reduce(0, +)
            
            print("\nCalculated Weekly Totals:")
            print("- Total Red Meat:", totalRedMeat)
            print("- Total Family Time:", totalFamilyTime)
            
            avgRedMeat = totalRedMeat
            avgFamilyTime = totalFamilyTime
            
            print("\nFinal Values for Model:")
            print("- avgRedMeat:", avgRedMeat)
            print("- avgFamilyTime:", avgFamilyTime)
            
            // Calculate other averages
            avgAlcohol = newAssessmentData.compactMap { $0.alcohol }.average()
            avgSleepTime = newAssessmentData.compactMap { $0.sleepTime }.average()
        }
        
        // Get static values from user profile
        guard var userProfile = AppManager.shared.currentUser else {
            print("No current user available.")
            completion(0, "No User Data")
            return
        }
        
        var tempAssessment = currentAssessment
        
        var age = 0.0
        if let userAge = userProfile.dateOfBirth?.getDateFromString()?.age(){
            age = Double(userAge)
        }
        let gender = userProfile.sex == "Male" ? 1.0 : 0.0
        
        var haveCancerBefore: Double = 0
        if let isCancer = userProfile.cancerBefore {
            haveCancerBefore = isCancer ? 1.0 : 0.0
        }
        
        // Run prediction model
        self.cancerPrediction(
            avgScore: userProfile.overallSymptomScore,
            redMeatWeekly: avgRedMeat,
            bmi: self.calculateBMI(user: userProfile),
            age: age,
            haveCancerBefore: haveCancerBefore,
            neighborHours: avgFamilyTime,
            gender: gender
        ) { riskScore, riskStatus in
            // Update the latest assessment and user profile

            tempAssessment.riskStatus = riskStatus
            tempAssessment.kobiScore = Int(riskScore)
            FirestoreManagerAdvance.shared.addAssessment(for: userProfile.userId, assessment: tempAssessment) { isSuccess in
                print("Assessment added")
            }
            
            userProfile.kobiScore = Int(riskScore)
            userProfile.riskStatus = riskStatus
            AppManager.shared.currentUser = userProfile
            
            self.updateUserProfile(userProfile: userProfile) { isSuccess in
                print("UserProfile is updated with score: \(riskScore) \(riskStatus)")
                completion(Double(riskScore), riskStatus)
            }
        }
        
        print("\n=== END OF DAILY ASSESSMENT DEBUG ===")
    }
    
    
    
    
    
    func calculateBMI(user: UserProfile) -> Double {
        let heightInMeters = (user.height ?? 0) / 100.0 // Convert cm to meters
        guard heightInMeters > 0 else { return 0.0 } // Prevent division by zero
        return (user.weight ?? 0) / (heightInMeters * heightInMeters)
    }
    
    func getCategoryData(from answersArray: [[String: AnyCodable]], for category: QueCategory) -> [Double] {
        var values = [Double]()
        
        for entry in answersArray {
            guard let categoryString = entry["category"]?.value as? String,
                  let entryCategory = QueCategory(rawValue: categoryString),
                  entryCategory == category else { continue }
            
            let answer = entry["answer"]?.value as? String ?? "0"
            let numericValue = Double(answer) ?? 0.0  // Convert answer to a number
            values.append(numericValue)
        }
        
        return values
    }
    
    
    private func cancerPrediction(
           avgScore: Double?,
           redMeatWeekly: Double?,
           bmi: Double,
           age: Double,
           haveCancerBefore: Double,
           neighborHours: Double?,
           gender: Double,
           completion: @escaping (Double, String) -> Void
       ) {
           do {
               let scaledInput = CancerRiskPredictorInput(
                   avg_score: standardize(avgScore ?? 0, featureIndex: 0),
                   red_meat_weekly: standardize(redMeatWeekly ?? 0, featureIndex: 1),
                   bmi: standardize(bmi, featureIndex: 2),
                   age: standardize(age, featureIndex: 3),
                   have_cancer_before: haveCancerBefore,
                   neighbor_hr: standardize(neighborHours ?? 0, featureIndex: 4),
                   gender: gender
               )
               
               let prediction = try model.prediction(input: scaledInput)
               
               // Print original input values
               print("\n=== Cancer Risk Prediction Test ===")
               print("Original Input values:")
               print("- Average Score: \(avgScore)")
               print("- Red Meat Weekly: \(redMeatWeekly)")
               print("- BMI: \(bmi)")
               print("- Age: \(age)")
               print("- Have Cancer Before: \(haveCancerBefore)")
               print("- Neighbor Hours: \(neighborHours)")
               print("- Gender: \(gender)")
               
               // Print scaled values
               print("\nScaled Input values:")
               print("- Average Score: \(scaledInput.avg_score)")
               print("- Red Meat Weekly: \(scaledInput.red_meat_weekly)")
               print("- BMI: \(scaledInput.bmi)")
               print("- Age: \(scaledInput.age)")
               print("- Neighbor Hours: \(scaledInput.neighbor_hr)")
               print("- Have Cancer Before: \(scaledInput.have_cancer_before) (categorical)")
               print("- Gender: \(scaledInput.gender) (categorical)")
               
               print("\nPrediction:")
               print("- Current Cancer: \(prediction.current_cancer)")
               
               // Get probability scores
               let probs = prediction.classProbability
               print("- Probability Scores:")
               for (label, probability) in probs {
                   print("  Class \(label): \(probability * 100)%")
               }
               
               let probability = probs[1] ?? 0
               
               let riskScore = probability * 100
               
               // Add debug prints
               print("\nScore Calculation Debug:")
               print("Raw probability:", probability)
               print("Risk score before rounding:", riskScore)
               
               // Round to nearest integer or keep decimal places
               let finalScore = riskScore.rounded()  // or use riskScore directly if you want decimals
               print("Final risk score:", finalScore)
               
               let riskStatus = getRiskLevel(score: finalScore)
               
               completion(finalScore, riskStatus)
               
           } catch {
               print("Prediction error: \(error.localizedDescription)")
               completion(0, "Unknown")
           }
       }
    
    
    
    
    
    private func getRiskLevel(score: Double) -> String {
        switch score {
        case 75...:
            return "Cao"
        case 25...:
            return "Trung bình"
        default:
            return "Thấp"
        }
    }

    
    private func updateUserProfile(userProfile: UserProfile, completion: @escaping (Bool) -> Void) {
        FirestoreManagerAdvance.shared.updateUserProfile(user: userProfile) { isUpdate in
            print("updated")
            completion(true)
        }
    }
    
}
