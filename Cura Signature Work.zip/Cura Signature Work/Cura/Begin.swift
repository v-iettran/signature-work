//
//  ContentView.swift
//  Cura
//
//  Created by Nika Kiladze on 10/12/24.
//

import SwiftUI

struct Begin: View {
    @State private var email = ""
    @EnvironmentObject var authManager: AuthManager
    @State private var isLoading = false
    @State private var navigateToSignIn = false
    @State private var navigateToSignUp = false
    @State private var showError = false
    @State private var errorMessage = ""
    @State private var showContinueButton = false
    @Namespace private var buttonTransition
    @State private var emailFieldOffset: CGFloat = 30
    @State private var emailFieldOpacity: Double = 0
    @State private var logoScale: CGFloat = 0.8
    @Namespace private var animation
    
    // Add these for page transitions
    @State private var slideTransition = AnyTransition.asymmetric(
        insertion: .move(edge: .trailing).combined(with: .opacity),
        removal: .move(edge: .leading).combined(with: .opacity)
    )
    
    var body: some View {
        NavigationStack {
            VStack {
                // Logo with animation
                Image("logo")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200, height: 100)
                    .padding(.top, 60)
                    .scaleEffect(logoScale)
                    .animation(.spring(response: 0.6, dampingFraction: 0.6), value: logoScale)
                
                Spacer()
                
                // Email Input Section with animations
                VStack(spacing: 8) {
                    TextField("Hãy điền email của bạn", text: $email)
                        .textFieldStyle(RoundedTextFieldStyle())
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .frame(height: 44) // Following Apple's minimum touch target size
                        .onChange(of: email) { _ in
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                                showContinueButton = !email.isEmpty
                            }
                        }
                }
                .padding(.horizontal, 24)
                .offset(y: emailFieldOffset)
                .opacity(emailFieldOpacity)
                
                // Restore previous continue button style with enhanced animation
                if showContinueButton {
                    Button(action: {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                            if isValidEmail(email) {
                                isLoading = true
                                authManager.checkEmailExists(email: email) { exists in
                                    DispatchQueue.main.async {
                                        isLoading = false
                                        withAnimation(.easeInOut(duration: 0.3)) {
                                            if exists {
                                                navigateToSignIn = true
                                            } else {
                                                navigateToSignUp = true
                                            }
                                        }
                                    }
                                }
                            } else {
                                showError = true
                                errorMessage = "Please enter a valid email"
                            }
                        }
                    }) {
                        HStack {
                            Text("Tiếp tục")
                                .font(
                                Font.custom("Source Sans Pro", size: 16)
                                .weight(.bold)
                                )
                                .foregroundColor(.white)
                            Image(systemName: "arrow.right")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(red: 0.15, green: 0.18, blue: 0.29))
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 16)
                    .matchedGeometryEffect(id: "continueButton", in: buttonTransition)
                }
                
                Spacer()
                Spacer()
                
                if isLoading {
                    ProgressView()
                        .transition(.opacity)
                }
            }
            .navigationDestination(isPresented: $navigateToSignIn) {
                SignInView(email: email)
                    .navigationTransition()
            }
            .navigationDestination(isPresented: $navigateToSignUp) {
                SignUpView(email: email)
                    .navigationTransition()
            }
            .alert("Error", isPresented: $showError) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage)
            }
        }
        .animation(.easeInOut(duration: 0.3), value: navigateToSignIn)
        .animation(.easeInOut(duration: 0.3), value: navigateToSignUp)
        .onAppear {
            // Animate elements when view appears
            withAnimation(.easeOut(duration: 0.6)) {
                emailFieldOffset = 0
                emailFieldOpacity = 1
                logoScale = 1
            }
        }
    }
    
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
}

struct RoundedTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding()
            .background(.white)
            .cornerRadius(10)
            .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 4)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .inset(by: 0.1)
                    .stroke(Color(red: 0.51, green: 0.55, blue: 0.63), lineWidth: 0.2)
            )
            // Improve touch feedback
            .pressEffect()
    }
}

// Add a custom ViewModifier for press animation
struct PressEffectModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .scaleEffect(0.98)
            .animation(.easeInOut(duration: 0.2), value: true)
    }
}

extension View {
    func pressEffect() -> some View {
        modifier(PressEffectModifier())
    }
}

#Preview {
    Begin()
        .environmentObject(AuthManager())
        .environmentObject(FirestoreManager())
}
