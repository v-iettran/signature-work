import SwiftUI

struct NavigationTransitionModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .transition(.asymmetric(
                insertion: .move(edge: .trailing).combined(with: .opacity),
                removal: .move(edge: .leading).combined(with: .opacity)
            ))
            .animation(.easeInOut(duration: 0.3), value: true)
    }
}

extension View {
    func navigationTransition() -> some View {
        self.modifier(NavigationTransitionModifier())
    }
} 