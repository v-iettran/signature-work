//
//  FirestoreTesting.swift
//  Cura
//
//  Created by Viet Tran on 26/1/25.
//

import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseAuth
import Network
import SystemConfiguration

/// Manager for testing Firestore operations
class FirestoreTestManager: ObservableObject {
    private let db = Firestore.firestore()
    
    // Add published property to track user data
    @Published var userData: [String: Any] = [:]
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    // Add this property
    private var isPreview: Bool {
        ProcessInfo.processInfo.environment["XCODE_RUNNING_FOR_PREVIEWS"] == "1"
    }
    
    // MARK: - Read Data
    func getUserData(userId: String) {
        db.collection("cura-users").document(userId).getDocument { [weak self] document, error in
            if let error = error {
                print("Error getting user data: \(error.localizedDescription)")
                return
            }
            
            if let document = document, document.exists {
                DispatchQueue.main.async {
                    self?.userData = document.data() ?? [:]
                }
            }
        }
    }
    
    // MARK: - Write Data
    func updateUserProfile(userId: String, data: [String: Any], completion: @escaping (Error?) -> Void) {
        db.collection("cura-users").document(userId).setData(data, merge: true) { error in
            completion(error)
        }
    }
    
    // MARK: - Update Specific Fields
    func updateUserField(userId: String, field: String, value: Any, completion: @escaping (Error?) -> Void) {
        db.collection("cura-users").document(userId).updateData([
            field: value
        ]) { error in
            completion(error)
        }
    }
    
    // MARK: - Delete Data
    func deleteUserData(userId: String, completion: @escaping (Error?) -> Void) {
        db.collection("cura-users").document(userId).delete { error in
            completion(error)
        }
    }
    
    // Add this method to list all documents
    func listAllDocuments() {
        if isPreview { return }
        print("\nChecking Firestore connection...")
        print("Current user: \(Auth.auth().currentUser?.uid ?? "No user")")
        
        // Add this to print Firebase config
        if let plist = Bundle.main.infoDictionary?["GoogleService-Info.plist"] as? [String: Any] {
            print("Project ID: \(plist["PROJECT_ID"] ?? "Not found")")
            print("Database URL: \(plist["DATABASE_URL"] ?? "Not found")")
        }
        
        db.collection("cura-users").getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error getting documents: \(error.localizedDescription)")
                print("Error details: \(error)")
                return
            }
            
            print("\n--- All Documents in cura-users ---")
            if let documents = querySnapshot?.documents {
                if documents.isEmpty {
                    print("No documents found in collection")
                    // Try to list all collections
                    self.db.collectionGroup("").getDocuments { (snapshot, error) in
                        if let error = error {
                            print("Error listing collections: \(error)")
                            return
                        }
                        print("Available collections:")
                        snapshot?.documents.forEach { doc in
                            print("Collection: \(doc.reference.parent.path)")
                        }
                    }
                } else {
                    for document in documents {
                        print("\nDocument ID: \(document.documentID)")
                        print("Document exists: \(document.exists)")
                        print("Document reference path: \(document.reference.path)")
                        print("Data: \(document.data())")
                        print("-------------------")
                    }
                }
            } else {
                print("QuerySnapshot is nil")
            }
        }
    }
    
    /// Listens for real-time updates to a user document
    func listenToUserChanges(userId: String) {
        isLoading = true
        
        // Check network connectivity first
        guard NetworkReachability.isConnected else {
            self.errorMessage = "No internet connection. Please check your network."
            self.isLoading = false
            return
        }
        
        db.collection("cura-users")
            .document(userId)
            .addSnapshotListener { [weak self] document, error in
                DispatchQueue.main.async {
                    self?.isLoading = false
                    
                    if let error = error {
                        self?.errorMessage = error.localizedDescription
                        print("Error: \(error.localizedDescription)")
                        return
                    }
                    
                    if let document = document, document.exists {
                        self?.userData = document.data() ?? [:]
                        print("Data received: \(document.data() ?? [:])")
                    } else {
                        self?.errorMessage = "Document not found"
                    }
                }
            }
    }
    
    /// Clears local cache
    func clearCache() {
        let settings = Firestore.firestore().settings
        settings.isPersistenceEnabled = false
        Firestore.firestore().settings = settings
        
        // Reset persistence
        settings.isPersistenceEnabled = true
        Firestore.firestore().settings = settings
    }
    
    // Add this new method
    func checkFirestoreSetup() {
        if isPreview { return }
        print("\n=== Firestore Connection Check ===")
        print("Current Auth User ID: \(Auth.auth().currentUser?.uid ?? "No user")")
        
        // Try to access the root collections we know about
        let knownCollections = ["cura-users"]
        
        for collectionId in knownCollections {
            print("\nChecking collection: \(collectionId)")
            db.collection(collectionId).getDocuments { (snapshot, error) in
                if let error = error {
                    print("Error accessing \(collectionId): \(error.localizedDescription)")
                    return
                }
                
                if let documents = snapshot?.documents {
                    print("Found \(documents.count) documents in \(collectionId)")
                    documents.forEach { doc in
                        print("  - Document ID: \(doc.documentID)")
                    }
                } else {
                    print("No documents found in \(collectionId)")
                }
            }
        }
        
        // Try to access the specific document we're interested in
        let docPath = "cura-users/Iti96ET8XCWHhoekfUDx"
        print("\nTrying to access document: \(docPath)")
        db.document(docPath).getDocument { (document, error) in
            if let error = error {
                print("Error accessing document: \(error.localizedDescription)")
                return
            }
            
            if let document = document, document.exists {
                print("Document exists!")
                print("Data: \(document.data() ?? [:])")
            } else {
                print("Document does not exist")
            }
        }
    }
}

/// View for testing Firestore operations
struct FirestoreTestView: View {
    @StateObject private var firestoreManager = FirestoreTestManager()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("User Profile Testing")
                .font(.title)
                .padding(.top)
            
            if firestoreManager.isLoading {
                ProgressView("Loading...")
            } else if let errorMessage = firestoreManager.errorMessage {
                ErrorView(message: errorMessage) {
                    firestoreManager.listenToUserChanges(userId: "Iti96ET8XCWHhoekfUDx")
                }
            } else {
                UserDataView(userData: firestoreManager.userData)
            }
        }
        .padding()
        .onAppear {
            firestoreManager.clearCache()
            firestoreManager.checkFirestoreSetup()
            firestoreManager.listAllDocuments()
            firestoreManager.listenToUserChanges(userId: "Iti96ET8XCWHhoekfUDx")
        }
    }
}

/// Displays user data in a formatted way
struct UserDataView: View {
    let userData: [String: Any]
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                Group {
                    // Basic Info
                    DataRow(title: "Email", value: userData["email"] as? String ?? "")
                    DataRow(title: "Name", value: userData["name"] as? String ?? "")
                    DataRow(title: "Birthday", value: userData["birthday"] as? String ?? "")
                    DataRow(title: "Cancer Before", 
                           value: (userData["cancer_before"] as? Bool)?.description ?? "")
                    
                    // Risk Assessment
                    if let riskData = userData["risk_timestamp"] as? [String: Any] {
                        VStack(alignment: .leading) {
                            Text("Risk Assessment:").bold()
                            Text("Risk: \((riskData["risk"] as? Int)?.description ?? "")")
                            Text("Time: \(riskData["time"] as? String ?? "")")
                        }
                    }
                }
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)
        }
    }
}

/// Displays error message with retry button
struct ErrorView: View {
    let message: String
    let retryAction: () -> Void
    
    var body: some View {
        VStack {
            Text("Error")
                .font(.headline)
                .foregroundColor(.red)
            Text(message)
                .foregroundColor(.red)
            Button("Retry", action: retryAction)
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
        }
        .padding()
    }
}

/// Helper view for displaying data rows
struct DataRow: View {
    let title: String
    let value: String
    
    var body: some View {
        HStack {
            Text(title).bold()
            Text(": ")
            Text(value)
        }
    }
}

// Add a simple network reachability check
struct NetworkReachability {
    static var isConnected: Bool {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)

        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }

        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        
        let isReachable = flags.contains(.reachable)
        let needsConnection = flags.contains(.connectionRequired)
        return isReachable && !needsConnection
    }
}

#Preview {
    FirestoreTestView()
        .environmentObject(AuthManager())
        .environmentObject(FirestoreManager())
}

