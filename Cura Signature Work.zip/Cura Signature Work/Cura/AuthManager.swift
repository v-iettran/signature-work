import Foundation
import SwiftUI
import Firebase
import FirebaseCore
import FirebaseAuth
import FirebaseFirestore

//class CuraViewModel: ObservableObject {
//    @Published var cura = CuraDatabase.empty
//    
//}

/// Manages all authentication-related operations
class AuthManager: ObservableObject {
    @Published var isAuthenticated = false
    
    var isUserAuthenticated :Bool {
        set{
            UserDefaults.standard.set(newValue, forKey: "ISLOGIN")
        }
        get{
            return UserDefaults.standard.bool(forKey: "ISLOGIN")
        }
    }
    
    private var authStateListener: AuthStateDidChangeListenerHandle?
    
    init() {
//        setupAuthStateListener()
    }
    
    deinit {
        if let handle = authStateListener {
            Auth.auth().removeStateDidChangeListener(handle)
        }
    }
    
    /// Sets up Firebase Auth state listener
//    private func setupAuthStateListener() {
//        authStateListener = Auth.auth().addStateDidChangeListener { [weak self] _, user in
//            self?.isAuthenticated = user != nil
//        }
//    }
    
    /// Creates a new user account and corresponding Firestore document
    func createAccount(withEmail email: String, 
                      password: String, 
                      fullName: String,
                      phoneNumber: String,
                      completion: @escaping (Result<Void, Error>) -> Void) {
        // Create Firebase Auth user
        Auth.auth().createUser(withEmail: email, password: password) { [weak self] result, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let user = result?.user else {
                completion(.failure(NSError(domain: "", code: -1, 
                    userInfo: [NSLocalizedDescriptionKey: "User creation failed"])))
                return
            }
            
            // Set display name
            let changeRequest = user.createProfileChangeRequest()
            changeRequest.displayName = fullName
            
            changeRequest.commitChanges { error in
                if let error = error {
                    completion(.failure(error))
                    return
                }
                
                // Create Firestore document with initial user data
//                let userData: [String: Any] = [
//                    "name": fullName,
//                    "email": email,
//                    "phoneNumber": phoneNumber,
//                    "birthday": "",
//                    "cancer_before": false,
//                    "connections": [],
//                    "risk_timestamp": [
//                        "risk": 0,
//                        "time": Date().description
//                    ],
//                    "createdAt": FieldValue.serverTimestamp()
//                ]
//                
//                // Save to Firestore using UID as document ID
//                Firestore.firestore()
//                    .collection("cura-users")
//                    .document(user.uid)
//                    .setData(userData) { error in
//                        if let error = error {
//                            print("Firestore error: \(error.localizedDescription)")
//                            completion(.failure(error))
//                        } else {
//                            self?.isAuthenticated = true
//                            completion(.success(()))
//                        }
//                    }
                let userData: [String: Any] = [
                    "userId": user.uid,
                    "name": fullName,
                    "email": email.lowercased(),
                    "phoneNumber": phoneNumber,
                    "cancerBefore": false,
                    "setup": false,
                    "createdAt": FieldValue.serverTimestamp()
                ]
                
                Firestore.firestore().collection("PersonalDetail").document(user.uid).setData(userData) { error in
                    if let error = error {
                        completion(.failure(error))
                    } else {
                        self?.isAuthenticated = true
                        completion(.success(()))
                    }
                }

            }
        }
    }
    
    /// Signs in existing user
    func signInWithEmail(withEmail email: String, 
                        password: String, 
                        completion: @escaping (Error?) -> Void) {
        Auth.auth().signIn(withEmail: email, password: password) { [weak self] _, error in
            if let error = error {
                completion(error)
                return
            }
            FirestoreManagerAdvance.shared.fetchUserProfileByEmail(email: email) { user in
                AppManager.shared.currentUser = user
                self?.isAuthenticated = true
                completion(nil)

            }
        }
    }
    
    /// Signs out current user
    func signOut(completion: @escaping (Error?) -> Void) {
        do {
            try Auth.auth().signOut()
            completion(nil)
        } catch let error {
            completion(error)
        }
    }
    
    /// Checks if email exists in Firebase Auth
//    func checkEmailExists(email: String, completion: @escaping (Bool) -> Void) {
//        Auth.auth().fetchSignInMethods(forEmail: email) { signInMethods, error in
//            DispatchQueue.main.async {
//                if let error = error {
//                    print("Email check error: \(error.localizedDescription)")
//                    completion(false)
//                    return
//                }
//                let exists = signInMethods != nil && !(signInMethods?.isEmpty ?? true)
//                completion(exists)
//            }
//        }
//    }
    
    func checkEmailExists(email: String, completion: @escaping (Bool) -> Void) {
        Auth.auth().signIn(withEmail: email, password: "dummyPassword") { _, error in
            DispatchQueue.main.async {
                if let error = error as NSError? {
                    switch error.code {
                    case AuthErrorCode.userNotFound.rawValue:
                        completion(false) // Email does NOT exist
                    case AuthErrorCode.wrongPassword.rawValue, AuthErrorCode.invalidCredential.rawValue:
                        completion(true)  // Email exists, but wrong password
                    default:
                        completion(false) // Treat other errors as non-existent email
                    }
                } else {
                    completion(true) // Somehow logged in (shouldn't happen with wrong password)
                }
            }
        }
    }

}

// MARK: - Placeholder FBUser and FBFirestore for Demo

struct FBUser {
    static func dataDict(uid: String, name: String, email: String) -> [String: Any] {
        return ["uid": uid, "name": name, "email": email]
    }
}

struct FBFirestore {
    static func mergeFBUser(_ data: [String: Any], uid: String, completion: @escaping (Result<Void, Error>) -> Void) {
        // Simulate database write success
        completion(.success(()))
    }
}
