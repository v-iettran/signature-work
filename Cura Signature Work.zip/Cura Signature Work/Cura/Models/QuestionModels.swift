//
//  QuestionModels.swift
//  Cura
//
//  Created by Vivek Padaya on 12/02/25.
//

import UIKit
import SwiftUI
import FirebaseCore


enum QueCategory : String{
    case breast = "Breast"
    case liver = "Liver"
    case drink = "Drink"
    case redmeat = "RedMeat"
    case sleep = "Sleep"
    case familyTime = "FamilyTime"
    case exercise = "Exercise"
    case cancer = "Cancer"
}

enum QuestionType: String {
    case stepper = "Stepper"
    case options = "Options"
}

struct Question {
    let text: String
    let options: [String]
    let type : QuestionType
    let stepperName: String
    let category: QueCategory
}

class FirstQuestionnaireViewModel: ObservableObject {
    @Published var currentQuestionIndex = 0
    @Published var answers: [String?]
    @Published var showingSubmissionAlert = false
    @State var currentRiskScore = 0

    let questions = [
        Question(
            text: "Bạn có nhận thấy bất kỳ khối u hoặc sưng nào xung quanh vú, ngực hoặc vùng dưới cánh tay không?",
            options: ["Có", "Không"], type: .options, stepperName: "", category: .breast
        ),
        Question(
            text: "Bạn có nhận thấy bất kỳ thay đổi nào về kích thước hoặc hình dạng ở một hoặc cả hai bên vú không?",
            options: ["Có", "Không"], type: .options, stepperName: "", category: .breast
        ),
        Question(
            text: "Bạn có nhận thấy da ở vú bị lõm hoặc dày lên không?",
            options: ["Có", "Không"], type: .options, stepperName: "", category: .breast
        ),
        Question(
            text: "Bạn có nhận thấy dịch tiết từ núm vú, bao gồm cả máu không?",
            options: ["Có", "Không"], type: .options, stepperName: "", category: .breast
        ),
        Question(
            text: "Bạn có cảm thấy đau dai dẳng ở vú hoặc núm vú không?",
            options: ["Có", "Không"], type: .options, stepperName: "", category: .breast
        ),
        Question(
            text: "Bạn có nhận thấy một khối cứng ngay bên dưới xương sườn phải không?",
            options: ["Có", "Không"], type: .options, stepperName: "", category: .liver
        ),
        Question(
            text: "Bạn có cảm thấy khó chịu hoặc đau ở vùng bụng trên bên phải không?",
            options: ["Có", "Không"], type: .options, stepperName: "", category: .liver
        ),
        Question(
            text: "Bạn có nhận thấy da hoặc phần trắng của mắt bị vàng không?",
            options: ["Có", "Không"], type: .options, stepperName: "", category: .liver
        ),
        Question(
            text: "Gần đây bạn có bị sụt cân không rõ nguyên nhân không?",
            options: ["Có", "Không"], type: .options, stepperName: "", category: .liver
        ),
        Question(
            text: "Gần đây bạn có cảm thấy mệt mỏi hoặc suy nhược bất thường không?",
            options: ["Có", "Không"], type: .options, stepperName: "", category: .liver
        ),
        Question(
            text: "Bạn đã từng/đang bị ung thư chưa?",
            options: ["Có", "Không"], type: .options, stepperName: "", category: .cancer
        ),
        Question(
            text: "Trung bình mỗi tuần bạn sử dụng rượu bia bao nhiêu lần?",
            options: [], type: .stepper, stepperName: "lần", category: .drink
        ),
        Question(
            text: "Trung bình mỗi tuần bạn tập thể dục bao nhiêu lần",
            options: [], type: .stepper, stepperName: "lần", category: .exercise
        ),
        Question(
            text: "Trung bình mỗi tuần bạn ăn bao nhiêu bữa có thịt đỏ",
            options: [], type: .stepper, stepperName: "lần", category: .redmeat
        ),
        Question(
            text: "Trung bình mỗi ngày bạn ngủ bao nhiêu tiếng",
            options: [], type: .stepper, stepperName: "tiếng", category: .sleep
        ),
        Question(
            text: "Trung bình mỗi tuần bạn dành bao nhiêu tiếng tiếp xúc với hàng xóm?",
            options: [], type: .stepper, stepperName: "tiếng", category: .familyTime
        )
    ]
    
    
    init() {
        answers = Array(repeating: nil, count: questions.count)
    }
    
    var progress: Double {
        Double(currentQuestionIndex + 1) / Double(questions.count)
    }
    
    var isLastQuestion: Bool {
        currentQuestionIndex == questions.count - 1
    }
    
    func nextQuestion() {
        withAnimation {
            currentQuestionIndex = min(currentQuestionIndex + 1, questions.count - 1)
        }
    }
    
    func previousQuestion() {
        withAnimation {
            currentQuestionIndex = max(currentQuestionIndex - 1, 0)
        }
    }
    
    var isAnswerProvided: Bool {
        guard currentQuestionIndex < answers.count else { return false }
        let answer = answers[currentQuestionIndex]
        
        if let stringAnswer = answer {
            return !stringAnswer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
        else{
            return false
        }
    }
    
    func submitQuestionnaire() {
        var answersArray: [[String: AnyCodable]] = []
        var categoryScores: [String: [Double]] = [:]
        
        var hasCancerBefore = false
        
        for (index, answer) in answers.enumerated() {
            let question = questions[index]
            
            // Convert "Có" to 1 and "Không" to 0
            let numericValue: Double
            if answer == "Có" {
                numericValue = 1.0
            } else if answer == "Không" {
                numericValue = 0.0
            } else {
                // If answer is invalid (nil or unexpected), skip this question
                numericValue = answer?.toDouble() ?? 0.0
            }
            
            if question.category == .cancer {
                if answer == "Có" {
                    hasCancerBefore = true
                }
            }
            
            let entry: [String: AnyCodable] = [
                "question": AnyCodable(question.text),
                "answer": AnyCodable(answer ?? ""),
                "category": AnyCodable(question.category.rawValue)
            ]
            answersArray.append(entry)
            
            // Only track scores for breast and liver categories
            if question.category == .breast || question.category == .liver {
                categoryScores[question.category.rawValue, default: []].append(numericValue)
            }
        }
        
        // Compute Average Scores for Breast & Liver
        var avgSymptomScores: [String: Double] = [:]
        for category in ["Breast", "Liver"] {
            if let scores = categoryScores[category], !scores.isEmpty {
                avgSymptomScores[category] = scores.reduce(0, +)
            } else {
                avgSymptomScores[category] = 0.0
            }
        }
        
        // Compute Overall Symptom Score (Only from Breast & Liver)
        let validScores = avgSymptomScores.values.filter { $0 > 0 }
        let overallSymptomScore = validScores.isEmpty ? 0 : (validScores.reduce(0, +) / Double(validScores.count))
        
        // Update Firestore
        guard var userdata = AppManager.shared.currentUser else {
            return
        }
        userdata.cancerBefore = hasCancerBefore
        userdata.questionnaireAnswers = answersArray
        userdata.avgSymptomScores = avgSymptomScores
        userdata.overallSymptomScore = overallSymptomScore
        
        FirestoreManagerAdvance.shared.updateUserProfile(user: userdata) { isSuccess in
            if !isSuccess {
                print("Error updating user profile")
            } else {
                print("User profile successfully updated with questionnaire data.")
                AppManager.shared.currentUser = userdata
                AppManager.shared.firstAssessmentDate = Date()
                do {
                    try AssessmentManager().fetchUserFirstScore { score, status in
                        self.currentRiskScore = Int(score)
                        NotificationCenter.default.post(name: .newDataAdded,
                                                        object: nil, userInfo: [:])
                        self.showingSubmissionAlert = true
                    }
                }
                catch {
                    print(error.localizedDescription)
                    self.showingSubmissionAlert = true
                }
            }
        }
    }
}



class DailyQuestionnaireViewModel: ObservableObject {
    @Published var currentQuestionIndex = 0
    @Published var answers: [String?]
    @Published var showingSubmissionAlert = false
    
    @State var assessments: [Assessment] = []
    @State var currentRiskScore = 0
    
    private var userProfile: UserProfile? {
        AppManager.shared.currentUser
    }
    
    let questions = [
    
        Question(
            text: "Hôm nay bạn đã uống rượu bia bao nhiêu lần?",
            options: [], type: .stepper, stepperName: "lần", category: .drink
        ),
        Question(
            text: "Hôm nay bao ăn bao nhiêu bữa có thịt đỏ?",
            options: [], type: .stepper, stepperName: "lần", category: .redmeat
        ),
        Question(
            text: "Hôm nay bạn có tập thể dục không?",
            options: ["Có", "Không"], type: .options, stepperName: "", category: .exercise
        ),

        Question(
            text: "Hôm nay bạn ngủ bao nhiêu tiếng?",
            options: [], type: .stepper, stepperName: "tiếng", category: .sleep
        ),
        Question(
            text: "Hôm nay bạn dành bao nhiêu tiếng cho hàng xóm xung quanh?",
            options: [], type: .stepper, stepperName: "tiếng", category: .familyTime
        )
    ]
    
    
    init() {
        answers = Array(repeating: nil, count: questions.count)
    }
    
    var progress: Double {
        Double(currentQuestionIndex + 1) / Double(questions.count)
    }
    
    var isLastQuestion: Bool {
        currentQuestionIndex == questions.count - 1
    }
    
    func nextQuestion() {
        withAnimation {
            currentQuestionIndex = min(currentQuestionIndex + 1, questions.count - 1)
        }
    }
    
    func previousQuestion() {
        withAnimation {
            currentQuestionIndex = max(currentQuestionIndex - 1, 0)
        }
    }
    
    
    func submitQuestionnaire() {
        var assessment = Assessment(date: Date().saveDateTimeFormate())
        assessment.dateTimestamp = Timestamp(date: Date())
        
        // Store raw values for the day
        for (index, answer) in answers.enumerated() {
            let question = questions[index]
            
            switch question.category {
            case .drink:
                assessment.alcohol = Int(answer?.toDouble() ?? 0)
            case .sleep:
                assessment.sleepTime = answer?.toDouble() ?? 0
            case .exercise:
                assessment.exercise = answer == "Có"
            case .familyTime:
                assessment.familyTime = answer?.toDouble() ?? 0
            case .redmeat:
                assessment.redMeat = Int(answer?.toDouble() ?? 0)
            default:
                break
            }
        }
        
        // Use the userProfile property here
        guard let userId = userProfile?.userId else { return }
        
        
        do{
            try AssessmentManager().fetchWeekRiskScore(assessments: assessments, currentAssessment: assessment) { riskScore, riskStatus in
                print("Updated")
                self.currentRiskScore = Int(riskScore)
                NotificationCenter.default.post(name: .newDataAdded,
                                                object: nil, userInfo: [:])
                self.showingSubmissionAlert = true
            }
        }catch{
            print(error.localizedDescription)
            self.showingSubmissionAlert = true

        }
        
        // Save assessment and update risk score
//        FirestoreManagerAdvance.shared.addAssessment(for: userId, assessment: assessment) { _ in
//            try? AssessmentManager().fetchCurrentWeekRiskScore { score, status in
//                self.currentRiskScore = Int(score)
//                NotificationCenter.default.post(name: .newDataAdded, object: nil)
//                self.showingSubmissionAlert = true
//            }
//        }
    }
    
    var isAnswerProvided: Bool {
        guard currentQuestionIndex < answers.count else { return false }
        let answer = answers[currentQuestionIndex]
        
        if let stringAnswer = answer {
            return !stringAnswer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        } else{
            return false
        }
    }
}

