import Foundation
import FirebaseFirestore
import FirebaseAuth

struct UserData: Codable, Identifiable {
    let id: String  // User's UID from Firebase Auth
    var name: String
    var email: String
    var dateOfBirth: Date
    var height: Double
    var weight: Double
    var sex: String
    var connections: [String]  // Array of connected user IDs
    var lastQuestionnaireDate: Date?
    var lastSymptomCheck: Date?
    var preferredAssessmentTime: Date?
    
    // Risk assessment data
    var riskScores: [RiskScore]
    var symptoms: [Symptom]
    
    static func from(_ user: User) -> UserData {
        UserData(
            id: user.uid,
            name: user.displayName ?? "User",
            email: user.email ?? "",
            dateOfBirth: Date(),
            height: 0,
            weight: 0,
            sex: "",
            connections: [],
            preferredAssessmentTime: nil,
            riskScores: [],
            symptoms: []
        )
    }
}

struct RiskScore: Codable, Identifiable {
    let id: String = UUID().uuidString
    let date: Date
    let score: Int
    let factors: [String: Int]  // Risk factors and their scores
}

struct Symptom: Codable, Identifiable {
    let id: String = UUID().uuidString
    let date: Date
    let type: String
    let severity: Int  // 1-10
    let location: String?
    let duration: Int  // Days
    let notes: String?
} 